# Artifact: *Same Gauge, Different Numbers*

**Paper:** "[Experiment, Analysis, and Benchmark] Same Record, Different Numbers: Copy Fidelity, Discovery, and Leakage in Transformation-Aware Time-Series Data Lakes" (ICDE 2027 EAB submission).

**Contents:** every script, frozen plan, fetch procedure and released label set needed to reproduce the paper's tables and figures. No third-party discharge data are redistributed: `fetch/` downloads them from their publishers and verifies the published checksums.

## Layout
| Path | Contents |
|---|---|
| `plans/` | Pre-registered plans, frozen **before** the corresponding data were read: `PLAN_G0.md` (literature gate), `PLAN_G1_G4.md` (E1, E3, E4 and the original attribution plan), `PLAN_G4_AMENDMENT.md` (E2 attribution, frozen before the downloads), `PLAN_E3_VERIFY.md`, `PLAN_E4_SPLITS.md` and `PLAN_E4_FIXEDTEST.md` (review rounds; checksums in `FROZEN_2026-10-20.md5`), `PLAN_E5_WEATHER.md` (second lake, frozen before any station series was downloaded; `FROZEN_2026-11-06.md5`) and `PLAN_R3_EXTENSIONS.md` (X1 learned matcher, X2 extreme flows, X3 version evidence, X4 synthetic lineage; `FROZEN_2026-11-07.md5`). Also each gate's report as written at the time (`G*_REPORT.md`). |
| `fetch/` | `fetch_all.py` (Zenodo inputs, MD5-verified, plus extraction), `fetch_nwis_vtnh.py` (USGS, pilot only), `fetch_ana.py` + `ana_stations.txt` (Brazil roots for E2), `fetch_r3_e5.py` (E5 station metadata, CAMELS-BR v1.2 and DWD logs for X3) |
| `src/` | Analysis scripts (below). `_paths.py` reads the data root from the `REPUB_ROOT` environment variable. |
| `out/` | Outputs of our runs, i.e. the numbers in the paper: summaries, per-pair and per-day results (identifiers and derived statistics only) |
| `labels/` | Released labels; see `labels/LABELS.md`. Includes the E3 benchmark with ground-truth caveat flags. |
| `paper/` | LaTeX sources. The `make_*.py` scripts (step 8) regenerate every table, figure and in-text number from `out/`; Fig. 1 is a TikZ schematic (`fig_lineage_v2.tex`). |
| `cache/g2_meta.pkl` | Station metadata used by E3 (names and coordinates from the public attribute files) |

## Requirements
- Python 3.12 with the packages in `requirements.txt`.
- About 60 GB of download and 80 GB of disk after extraction.
- A CUDA GPU only for the optional LSTM run (we used an 8 GB NVIDIA P104-100; peak use was below 1 GB).
- RAM: 32 GB recommended; E3 memory-maps a 2.7 GB array.

## Data layout and fetching
```
set REPUB_ROOT=D:\repub_data        (Windows)   |   export REPUB_ROOT=/data/repub   (Linux/macOS)
python fetch/fetch_all.py           # dry run: lists files and sizes
python fetch/fetch_all.py --yes     # downloads ~51 GB from Zenodo, verifies MD5, extracts
python fetch/fetch_nwis_vtnh.py --yes
```

| Source | Zenodo record / service | File | MD5 |
|---|---|---|---|
| Caravan v1.6 | 15529786 | Caravan-nc.tar.gz | ad3a7767db059f218380e9cce5f72452 |
| GRDC-Caravan v0.6 (CC-BY-4.0) | 15349031 | GRDC_Caravan_extension_csv.zip | 2689c2bff8807f53c3de127827a3cd16 |
| LamaH-CE daily | 5153305 | 2_LamaH-CE_daily.tar.gz | 69fd2733e969513403f923ecc5eaa3dc |
| LamaH-CE daily + hourly | 5153305 | 1_LamaH-CE_daily_hourly.tar.gz | 121b2292b288ef1c2ef4d96250be77ac |
| GlobalRiverWSE (Fang et al. 2025) | 17130396 | Result datasets.zip | 7052ea54f5f150b636596a5a50194adb |
| CAMELS-BR v1.1 streamflow | 3964745 | 02_CAMELS_BR_streamflow_m3s.zip | 599b96f48ec78e25751cf1cc691a22bb |
| USGS NWIS dv, VT + NH, 2009–2023 | waterservices.usgs.gov | `{VT,NH}_dv_2009_2023.rdb` | ours: b47ea86d… / 053a857d… (see script) |
| ANA HidroSerieHistorica, 105 stations | telemetriaws1.ana.gov.br | `<code>.xml` | 210 MB in our run |
| E5 metadata: GHCN-Daily station and mingle lists, ECA&D non-blended info and blended source tables, DWD kl and CLIMAT station lists | NCEI, ECA&D (KNMI), DWD open data | `fetch/fetch_r3_e5.py` | ours, in the script |
| E5 station series: GHCN-Daily by station, DWD kl historical, ECA&D non-blended/blended zips (read remotely by range requests) | NCEI, DWD, ECA&D | `src/e5_fetch.py` (frozen 350 MB budget) | not fixed (live services) |
| CAMELS-BR v1.2 streamflow (X3) | 15025488 | 02_CAMELS_BR_streamflow_all_catchments.zip | 01ac209ad3ca9a36f7f2510a6601a0a2 |
| DWD CDC change and error logs (X3) | opendata.dwd.de | `Change_log_CDC_ftp.txt`, `Error_log_CDC_ftp.txt` | ours, in the script (live files) |
| HydroBASINS v1c (optional; land outline of the map figure only) | hydrosheds.org | `data/HydroBASINS/hybas_{af,ar,as,au,eu,gr,na,sa,si}_lev01-12_v1c.zip` | not checked; without it the map has no background |

**Live services.** NWIS and ANA serve *current* values. Values revised after our downloads (NWIS 2026-10-16, ANA 2026-10-19) can change the pilot and E2 counts slightly. The scripts report checksum differences rather than failing.

## Reproduction order
Run from the artifact root with `REPUB_ROOT` set. Wall times are for our machine (12-core desktop, HDD data disk).

| Step | Command | Produces (paper item) | Time |
|---|---|---|---|
| 1 | `python -I src/g1.py` | `out/g1/*`: E1, Tables II and IV, Fig. 2, duplicate share (Fig. 1 is a schematic) | ~40 min |
| 1b | `python -I src/g1x_magnitude.py` | `out/g1/g1x_magnitude.csv`: E1 magnitude numbers (Sec. V text) | ~10 min |
| 2 | `python src/g2_cache.py` | `cache/g2_series.npy` + metadata (one-off, 12 processes) | ~25 min |
| 3 | `python -I src/g2.py US` (and `EU`, `BR`, `AU`, in parallel) | per-region rows | ~60 min |
| 3b | `python -I src/g2_summary.py`, then `python -I src/g2x_sensitivity.py` | E3, Tables VI–VII, Fig. 5, sub-km sensitivity | <5 min |
| 3c | `python -I src/qstep_check.py` (needs the step-2 cache) | `out/g1/qstep_check.csv`: quantisation-step check (Sec. III, descriptive) | <2 min |
| 4 | `python -I src/g3.py` | E4 natural exposure (Table IX, Fig. 6a) and validation shift | ~60 min |
| 4b | `python -I src/g3_lstm.py` (GPU) | E4 controlled injection, Fig. 6b–c (`smoke` argument for a 10-minute test) | ~35 min |
| 5 | `python fetch/fetch_ana.py --yes` | ANA roots for E2 | ~10 min |
| 6 | `python -I src/g4.py`, then `python -I src/g4x_checks.py` | E2, Table V, Figs. 3–4 (L2 window and placebo, BR breakdown) | ~70 min |
| 6c | `python -I src/g4x_pergauge.py` | `out/g4/g4x_pergauge.*`: per-gauge window shares (descriptive) | ~5 min |
| 7 | `python -I src/build_labels.py` | `labels/` | <2 min |
| 7c | `python -I src/e3_verify.py` (needs `labels/` from step 7; queries the NWIS site service, < 5 MB) | E3 verification per `plans/PLAN_E3_VERIFY.md` (Table VIII): `out/e3verify/*`, `labels/e3_verification.csv`, `labels/e3_spotcheck_sample.csv` | ~5 min |
| 7d | `python src/e4_splits.py` (GPU) | random vs lineage-aware splits per `plans/PLAN_E4_SPLITS.md`: `out/e4splits/*` | ~2 h |
| 7e | `python src/e4_fixedtest.py` (GPU; needs 7d) | fixed test set with matched controls per `plans/PLAN_E4_FIXEDTEST.md`: `out/e4fixed/*` | ~1 h |
| 7b | `python -I src/g1x_tolerance.py` | `out/g1/g1x_tolerance_*.csv`: tolerance sensitivity (descriptive; Table III) | ~2 h |
| 7f | `python -I src/e4_fixedtest_records.py` | `out/e4fixed/records.csv`: per-record differences for Fig. 6c | <2 min |
| 9 | `python fetch/fetch_r3_e5.py --yes`, then `python -I src/e5_select.py`, `python -I src/e5_fetch.py`, `python -I src/e5_run.py`, `python -I src/e5_summarise.py` | E5 per `plans/PLAN_E5_WEATHER.md`: `out/e5/*` (Table X) | not timed |
| 10a | `python -I src/x1_features.py US` (and `EU`, `BR`, `AU`; needs steps 2–3), then `python -I src/x1_learned.py` (needs 7c) | X1 learned matcher: `out/x1/*` (Tables VI, VIII; E3 text) | not timed |
| 10b | `python src/e4_extremes.py` (GPU; needs 7d–7e), then `python -I src/x2_eval.py` | X2 extreme flows: `out/e4extremes/*` (E4 text) | not timed |
| 10c | `python -I src/x3_versions.py` (needs step 6 and step 9's fetch) | X3 version evidence: `out/x3/*` (E2 text) | not timed |
| 10d | `python -I src/x4_synth.py` (needs LamaH hourly and the E5 DWD series) | X4 synthetic lineage: `out/x4/*` (E2 text) | not timed |
| 8 | `cd paper; python -I make_tables.py; python -I make_tables2.py; python -I make_figures3.py; python -I make_figures4.py; python -I make_figures5.py; python -I make_tables4.py; python -I make_tables5.py; python -I make_numbers8.py; python -I make_tables6.py; python -I make_tables7.py; python -I make_numbers11.py; python -I make_tables8.py; python -I make_numbers13.py; python -I make_numbers14.py; python -I make_numbers15.py; python -I make_tables9.py; python -I make_figures6.py; python -I make_figures7.py; latexmk -pdf main.tex` (run after steps 9–10; `make_figures7.py` redraws Figs. 2–6 in their final, common style) | all tables, figures, in-text numbers (`numbers*.tex`), PDF | ~20 min |

`src/pilot_republish.py`, `src/pilot2.py` and `src/g1x_8y_vs_30y.py` reproduce the excluded exploratory pilot (Sec. III) and the 8y-vs-30y archive check.

**Resuming.** `e4_splits.py`, `e4_fixedtest.py` and `g3_lstm.py` skip models whose results are already in their `nse.json`. `e4_extremes.py` retrains the 15 fixed-test models (their prediction arrays, about 225 MB, are not shipped) and stops if any NSE differs from the stored value by more than 1e-6; the X1 feature tables (about 58 MB) are likewise regenerated by step 10a. To retrain from scratch, move the shipped `out/e4splits/nse.json` (and `out/e4fixed/nse.json`) aside first. `e3_verify.py` reuses the shipped `out/e3verify/nwis_sites.json`; pass `--refetch` to query NWIS again.

## Verification we performed
A clean clone with a fresh environment reproduced the v8 experiment outputs, including the retrained LSTM models and compiled paper. See `VERIFICATION.md` for the step-by-step result and the six defects that run exposed and that are fixed here. That run covered steps 1–8 as of the paper's v8; steps 9–10 (E5 and X1–X4, added 2026-11-07) have been run in our working copy, with the full newer pipeline still awaiting a clean-clone run. For this package, the paper was built from the archived sources and the shipped outputs regenerated the E5 table, the two E3 tables including X1, and the E5 and X1–X4 numerical macros.
- **Seeds:** E3 negatives use seed 0; E4 leakage splits use seeds 0–9; injection LSTM seeds 0–2 per condition; split and fixed-test-set experiments use seeds 1–5 (class sample seed 0). Results do not depend on Python's hash seed.

## Pre-registration discipline
Each `PLAN_*.md` was frozen before the data it governs were read. Implementation details that a plan left open are fixed in the header docstring of the corresponding script, also before running. Results not covered by a frozen rule are labelled descriptive in the reports and the paper. The original USGS-targeted attribution plan (in `PLAN_G1_G4.md`) was suspended, not run. The reason is recorded in `PLAN_G4_AMENDMENT.md`.

## Licences
This artifact's code (`src/`, `fetch/`, `tools/`, `paper/*.py`) is released under the MIT licence (`LICENSE`). The labels (`labels/`) and derived results (`out/`) are released under CC BY 4.0 (`labels/LICENSE.md`).

Third-party data keep their own licences, and the artifact does not redistribute them:
- Caravan sub-datasets: per-country licences;
- GRDC-Caravan: CC-BY-4.0;
- data obtained directly from the GRDC portal: restricted;
- LamaH-CE, CAMELS-BR, GlobalRiverWSE: as stated on their Zenodo records;
- NWIS: public domain;
- ANA: per ANA terms;
- ECA&D: non-commercial research and education only (the artifact ships only station identifiers and derived statistics);
- GHCN-Daily: public domain (NOAA); DWD open data: CC BY 4.0;
- CAMELS-BR v1.2: as stated on its Zenodo record.
