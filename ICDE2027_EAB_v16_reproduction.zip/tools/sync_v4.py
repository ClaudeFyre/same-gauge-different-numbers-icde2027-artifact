"""Sync v4 (2026-10-27): review round 2 (E4 fixed test set, per-gauge window check, q-step check), determinism fixes
regenerated outputs, paper v7. g2.py, g3.py and e3_verify.py were fixed directly in the artifact (and mirrored in the pilot)."""
import shutil
from pathlib import Path
SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot'); ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact')
HDR = "import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))\nfrom _paths import ROOT, ART\n"

def insert_hdr(s):
    lines = s.split('\n'); i = 0
    if lines[0].startswith('"""'):
        i = next(k for k in range(len(lines)) if (k == 0 and lines[0].count('"""') == 2) or (k > 0 and '"""' in lines[k])) + 1
    lines.insert(i, HDR.rstrip()); return '\n'.join(lines)

def port(t):
    t = t.replace("sys.path.insert(0, 'E:/HydroResearch/icde_probe/republish_pilot')", "sys.path.insert(0, str(ART / 'src'))")
    t = t.replace("ROOT = Path(r'E:\\HydroResearch'); CAR = L.CAR", "CAR = L.CAR")
    t = t.replace("ROOT / 'icde_probe/republish_pilot/out/", "ART / 'out/")
    t = t.replace("open('E:/HydroResearch/icde_probe/republish_pilot/g4.py', encoding='utf-8')", "open(ART / 'src/g4.py', encoding='utf-8')")
    t = t.replace("exec(compile(s.split('rows, unstable = [], []')[0], 'g4', 'exec'))", "exec(compile(s.split('rows, unstable = [], []')[0], 'g4', 'exec'), globals())")
    t = t.replace("P = Path(r'E:\\HydroResearch\\icde_probe\\republish_pilot')", "P = ART")
    return t

for f in ['e4_fixedtest.py', 'g4x_pergauge.py', 'qstep_check.py']:
    out = port(insert_hdr((SRC / f).read_text(encoding='utf-8')))
    (ART / 'src' / f).write_text(out, encoding='utf-8')
    print(f, 'remaining:', [l.strip() for l in out.split('\n') if 'HydroResearch' in l] or 'none')

PHDR = "import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))\nfrom _paths import ROOT as _R, ART as _A\n"
for f in ['make_tables8.py', 'make_numbers13.py', 'make_numbers14.py', 'make_tables2.py']:
    s = (SRC / 'paper' / f).read_text(encoding='utf-8')
    if f == 'make_tables2.py':   # artifact version is already ported; carry over only the caption change
        a = (ART / 'paper' / f).read_text(encoding='utf-8')
        old = r"No rule reaches precision 0.99 in any class, so recall at precision $\ge$0.99 is 0 throughout."
        new = r"Only M3 reaches precision 0.99, in one class and at 1\% recall (48 matches, none false)."
        if old in a: (ART / 'paper' / f).write_text(a.replace(old, new), encoding='utf-8')   # no-op once re-ported (sync_v5)
        continue
    s = s.replace("P = Path(r'E:\\HydroResearch\\icde_probe\\republish_pilot'); O = P / 'paper'", PHDR + "P = _A; O = P / 'paper'")
    (ART / 'paper' / f).write_text(s, encoding='utf-8')
    print(f, 'remaining:', [l.strip() for l in s.split('\n') if 'HydroResearch' in l] or 'none')

for f in ['PLAN_E4_FIXEDTEST.md', 'E4_FIXEDTEST_REPORT.md', 'FROZEN_2026-10-20.md5']:
    shutil.copy2(SRC / f, ART / 'plans' / f)
# outputs (canonical, deterministic reruns)
for d, keep in [('e4fixed', {'.json'}), ('e3verify', {'.json', '.csv'}), ('g3', {'.json', '.csv'}), ('g2', {'.json', '.parquet'})]:
    (ART / 'out' / d).mkdir(parents=True, exist_ok=True)
    for f in (SRC / 'out' / d).iterdir():
        if f.suffix in keep: shutil.copy2(f, ART / 'out' / d / f.name)
for f in ['g4/g4x_pergauge.json', 'g4/g4x_pergauge.csv', 'g1/qstep_check.csv']:
    if (SRC / 'out' / f).exists(): shutil.copy2(SRC / 'out' / f, ART / 'out' / f)
shutil.copy2(SRC / 'out/e3verify/verify_pairs.csv', ART / 'labels/e3_verification.csv')
shutil.copy2(SRC / 'out/e3verify/spotcheck_sample.csv', ART / 'labels/e3_spotcheck_sample.csv')
for sub in ['sections', 'tables', 'fig']:
    for f in (SRC / 'paper' / sub).iterdir():
        if f.suffix in {'.tex', '.pdf'}: shutil.copy2(f, ART / 'paper' / sub / f.name)
for f in (SRC / 'paper').glob('numbers*.tex'): shutil.copy2(f, ART / 'paper' / f.name)
for f in ['main.tex', 'refs.bib', 'fig_lineage.tex']:
    if (SRC / 'paper' / f).exists(): shutil.copy2(SRC / 'paper' / f, ART / 'paper' / f)
shutil.copy2(SRC / 'paper/main.pdf', ART / 'paper/main.pdf')
rel = ART / 'paper/sections/release.tex'
if rel.exists(): rel.unlink()   # removed from the paper in v3
print('synced')
