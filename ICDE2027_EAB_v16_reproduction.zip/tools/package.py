"""Create the distributable zip of the artifact (excludes the large series cache, LaTeX intermediates and this tools/ folder's port script)."""
import zipfile, hashlib
from pathlib import Path

ART = Path(__file__).resolve().parents[1]
OUT = ART.parent / 'republish_artifact.zip'
SKIP_DIRS = {'__pycache__'}
SKIP_FILES = {'g2_series.npy', 'port_scripts.py'}
SKIP_EXT = {'.aux', '.log', '.out', '.blg', '.fdb_latexmk', '.fls', '.synctex.gz', '.part'}
n = 0
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ART.rglob('*')):
        if p.is_dir() or set(p.parts) & SKIP_DIRS or p.name in SKIP_FILES or p.suffix in SKIP_EXT: continue
        if 'data_root' in p.parts: continue
        z.write(p, Path('republish_artifact') / p.relative_to(ART)); n += 1
h = hashlib.md5(OUT.read_bytes()).hexdigest()
print(f'{OUT} files={n} bytes={OUT.stat().st_size:,} md5={h}')
