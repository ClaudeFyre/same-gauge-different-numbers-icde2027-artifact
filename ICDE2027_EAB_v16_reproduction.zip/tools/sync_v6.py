"""Sync v6 (2026-11-07): second lake (E5), extensions X1-X4 (PLAN_R3_EXTENSIONS), paper v15.
Ports the pilot scripts to the artifact's path convention (ROOT = data root, ART = artifact root), copies plans, the
small derived outputs (no third-party values; LSTM prediction arrays and X1 feature tables are regenerated, not shipped),
and the paper sources."""
import re, shutil
from pathlib import Path
SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot'); ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact')
HDR = "import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))\nfrom _paths import ROOT, ART\n"
PHDR = "import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))\nfrom _paths import ROOT as _R, ART as _A\n"

def insert_hdr(s, hdr):
    lines = s.split('\n'); i = 0
    if lines[0].startswith('"""'):
        i = next(k for k in range(len(lines)) if (k == 0 and lines[0].count('"""') == 2) or (k > 0 and '"""' in lines[k])) + 1
    lines.insert(i, hdr.rstrip()); return '\n'.join(lines)

def port(t):
    t = t.replace("sys.path.insert(0, 'E:/HydroResearch/icde_probe/republish_pilot')", "sys.path.insert(0, str(ART / 'src'))")
    t = t.replace("ROOT = Path(r'E:\\HydroResearch'); CAR = L.CAR", "CAR = L.CAR")
    t = t.replace("ROOT = Path(r'E:\\HydroResearch'); P = ROOT / 'icde_probe/republish_pilot'", "P = ART")
    t = t.replace("R = Path(r'E:\\HydroResearch'); P = R / 'icde_probe/republish_pilot'", "R = ROOT; P = ART")
    t = t.replace("R0 = Path(r'E:\\HydroResearch'); P = R0 / 'icde_probe/republish_pilot'", "R0 = ROOT; P = ART")
    t = t.replace("ROOT / 'icde_probe/republish_pilot/out/", "ART / 'out/")
    t = re.sub(r"Path\(r'E:\\HydroResearch\\icde_probe\\republish_pilot\\out\\(\w+)'\)", r"(ART / 'out/\1')", t)
    t = t.replace("Path(r'E:\\HydroResearch\\icde_probe\\republish_pilot')", "ART")
    t = re.sub(r"Path\(r'E:\\HydroResearch\\data\\([^']*)'\)", lambda m: "(ROOT / 'data/" + m.group(1).replace('\\', '/') + "')", t)
    t = t.replace("open(P / 'g2.py'", "open(P / 'src/g2.py'").replace("str(P / 'g2.py')", "str(P / 'src/g2.py')")
    # x4: locate LamaH hourly files the same way g4.py does (fetch layout may nest one directory deeper)
    t = t.replace("HOURLY = R0 / 'data/LamaH-CE/extracted_hourly/D_gauges/2_timeseries/hourly'",
                  "HOURLY = Path(sorted(glob.glob(str(R0 / 'data/LamaH-CE/extracted_hourly/**/D_gauges/2_timeseries/hourly'), recursive=True))[0])")
    return t

SCRIPTS = ['e4_extremes.py', 'e4_fixedtest_records.py', 'x2_eval.py', 'x1_features.py', 'x1_learned.py', 'x3_versions.py',
           'x4_synth.py', 'e5_select.py', 'e5_remotezip.py', 'e5_fetch.py', 'e5_run.py', 'e5_summarise.py']
for f in SCRIPTS:
    out = port(insert_hdr((SRC / f).read_text(encoding='utf-8'), HDR))
    left = [l.strip() for l in out.split('\n') if 'HydroResearch' in l]
    assert not left, (f, left)
    (ART / 'src' / f).write_text(out, encoding='utf-8')
print('src ported:', len(SCRIPTS))

def optional_land(f, s):
    """HydroBASINS is an optional input (README): without it the map is drawn without a land outline."""
    def rep(a, b):
        nonlocal s
        assert s.count(a) == 1, (f, a[:60]); s = s.replace(a, b)
    if f == 'make_figures3.py':
        rep("import geopandas as gpd\nland = []\nfor reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']:\n"
            "    z = R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip'\n"
            "    land.append(gpd.read_file(f'zip://{z}!hybas_{reg}_lev01_v1c.shp'))\n"
            "land = pd.concat(land).geometry.simplify(0.2)\n",
            "# Land outline from HydroBASINS level 1 (optional input, see README); without it the map is drawn without background.\n"
            "HB = [R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip' for reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']]\n"
            "land = None\nif all(z.exists() for z in HB):\n    import geopandas as gpd\n"
            "    land = pd.concat([gpd.read_file(f'zip://{z}!' + z.name.replace('_lev01-12_v1c.zip', '_lev01_v1c.shp')) for z in HB]).geometry.simplify(0.2)\n"
            "else:\n    print('HydroBASINS not found under REPUB_ROOT/data/HydroBASINS: map drawn without land outline')\n")
        rep("land.plot(ax=ax, color='#eeeeee', edgecolor='#d0d0d0', linewidth=0.2)",
            "if land is not None: land.plot(ax=ax, color='#eeeeee', edgecolor='#d0d0d0', linewidth=0.2)")
    if f == 'make_figures6.py':
        rep("import geopandas as gpd, zipfile\n", "import zipfile\n")
        rep("land = []\nfor reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']:\n"
            "    z = R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip'\n"
            "    land.append(gpd.read_file(f'zip://{z}!hybas_{reg}_lev01_v1c.shp'))\n"
            "land = pd.concat(land).geometry\n",
            "# HydroBASINS level 1 land outline: optional input (README); without it the map has no background.\n"
            "HB = [R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip' for reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']]\n"
            "land = None\nif all(z.exists() for z in HB):\n    import geopandas as gpd\n"
            "    land = pd.concat([gpd.read_file(f'zip://{z}!' + z.name.replace('_lev01-12_v1c.zip', '_lev01_v1c.shp')) for z in HB]).geometry\n"
            "else:\n    print('HydroBASINS not found under REPUB_ROOT/data/HydroBASINS: map drawn without land outline')\n")
        rep("land.simplify(0.2).plot(ax=ax,", "if land is not None: land.simplify(0.2).plot(ax=ax,")
        rep("land.clip_by_rect(5, 43, 22, 52).simplify(0.01).plot(ax=ins,", "if land is not None: land.clip_by_rect(5, 43, 22, 52).simplify(0.01).plot(ax=ins,")
    return s

# paper scripts
for f in ['make_tables9.py', 'make_numbers15.py']:
    s = (SRC / 'paper' / f).read_text(encoding='utf-8')
    a = "P = Path(r'E:\\HydroResearch\\icde_probe\\republish_pilot'); O = P / 'paper'"
    assert s.count(a) == 1, f
    s = s.replace(a, PHDR + "P = _A; O = P / 'paper'")
    assert 'HydroResearch' not in s, f
    (ART / 'paper' / f).write_text(s, encoding='utf-8')
for f in ['make_figures3.py', 'make_figures6.py']:
    s = (SRC / 'paper' / f).read_text(encoding='utf-8')
    a = "R = Path(r'E:\\HydroResearch'); P = R / 'icde_probe/republish_pilot'; O = P / 'paper'; OUT = P / 'out'"
    assert s.count(a) == 1, f
    s = s.replace(a, "import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))\n"
                     "from _paths import ROOT as R, ART as P\nO = P / 'paper'; OUT = P / 'out'")
    s = s.replace("open(P / 'g4.py'", "open(P / 'src/g4.py'").replace("str(P / 'g4.py')", "str(P / 'src/g4.py')")
    s = s.replace("G = {}; exec(compile(g4src", "G = {'__file__': str(P / 'src/g4.py')}; exec(compile(g4src")
    s = s.replace("R / 'icde_probe/republish_artifact/labels/", "P / 'labels/")
    assert 'HydroResearch' not in s and 'republish_' not in s, (f, [l for l in s.splitlines() if 'republish_' in l or 'HydroResearch' in l])
    s = optional_land(f, s)
    (ART / 'paper' / f).write_text(s, encoding='utf-8')
print('paper scripts ported')

# plans and reports
for f in ['PLAN_E5_WEATHER.md', 'E5_WEATHER_REPORT.md', 'FROZEN_2026-11-06.md5',
          'PLAN_R3_EXTENSIONS.md', 'R3_EXTENSIONS_REPORT.md', 'FROZEN_2026-11-07.md5']:
    shutil.copy2(SRC / f, ART / 'plans' / f)

# outputs: derived statistics and identifiers only
SKIP = {'features_AU.parquet', 'features_BR.parquet', 'features_EU.parquet', 'features_US.parquet'}
for d in ['e5', 'x1', 'x3', 'x4', 'e4extremes']:
    (ART / 'out' / d).mkdir(parents=True, exist_ok=True)
    for f in (SRC / 'out' / d).iterdir():
        if f.is_file() and f.suffix != '.npz' and f.name not in SKIP and f.stat().st_size > 0:
            shutil.copy2(f, ART / 'out' / d / f.name)
shutil.copy2(SRC / 'out/e4fixed/records.csv', ART / 'out/e4fixed/records.csv')

# paper sources and build
inputs = set(re.findall(r'\\input\{sections/(\w+)\}', (SRC / 'paper/main.tex').read_text(encoding='utf-8')))
for f in (SRC / 'paper/sections').glob('*.tex'):
    if f.stem in inputs: shutil.copy2(f, ART / 'paper/sections' / f.name)
for sub, suf in [('tables', {'.tex'}), ('fig', {'.pdf'})]:
    for f in (SRC / 'paper' / sub).iterdir():
        if f.suffix in suf: shutil.copy2(f, ART / 'paper' / sub / f.name)
for f in (SRC / 'paper').glob('numbers*.tex'): shutil.copy2(f, ART / 'paper' / f.name)
for f in ['main.tex', 'refs.bib', 'fig_lineage_v2.tex', 'main.pdf', 'main.bbl']:
    shutil.copy2(SRC / 'paper' / f, ART / 'paper' / f)
print('synced')
