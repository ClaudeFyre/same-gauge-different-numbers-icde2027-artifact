"""Sync v5 (2026-10-27): paper scripts that drifted from the working copy, found by the clean-clone build.
make_tables2.py: re-ported from the working copy (v4 Table IV layout and Fig. 4); make_figures3/4.py: exec sites get __file__,
label-table wording carried over."""
from pathlib import Path
SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot\paper'); ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact\paper')

def rep(s, a, b):
    assert a in s, a[:70]; return s.replace(a, b)

s = (SRC / 'make_tables2.py').read_text(encoding='utf-8')
s = rep(s, "R = Path(r'E:\\HydroResearch'); P = R / 'icde_probe/republish_pilot'; O = P / 'paper'; OUT = P / 'out'",
        "import sys, os; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))\nfrom _paths import ROOT as R, ART as P\nO = P / 'paper'; OUT = P / 'out'")
assert 'HydroResearch' not in s
(ART / 'make_tables2.py').write_text(s, encoding='utf-8')

s = (ART / 'make_figures3.py').read_text(encoding='utf-8')
s = rep(s, "G = {}; exec(compile(g4src.split('rows, unstable = [], []')[0], 'g4', 'exec'), G)",
        "G = {'__file__': str(P / 'src/g4.py')}; exec(compile(g4src.split('rows, unstable = [], []')[0], 'g4', 'exec'), G)")
(ART / 'make_figures3.py').write_text(s, encoding='utf-8')

s = (ART / 'make_figures4.py').read_text(encoding='utf-8')
s = rep(s, "G = {}; exec(compile(src, 'g1', 'exec'), G)", "G = {'__file__': str(P / 'src/g1.py')}; exec(compile(src, 'g1', 'exec'), G)")
s = rep(s, "'keyed copy pairs with scale constant, stability, divergent and shift-explained days'",
        "'compared keyed copy pairs ($\\\\geq$365 overlapping days) with scale constant, stability, divergent and shift-explained days'")
(ART / 'make_figures4.py').write_text(s, encoding='utf-8')
print('ok')
