"""Sync the expanded paper (2026-10-19, v2) and its new analysis/figure scripts into the artifact, porting absolute paths."""
import re, shutil
from pathlib import Path
SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot'); ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact')

# 1) paper sources and generated assets
for sub in ['sections', 'tables', 'fig']:
    d = ART / 'paper' / sub; d.mkdir(parents=True, exist_ok=True)
    for f in (SRC / 'paper' / sub).iterdir():
        if f.suffix in {'.tex', '.pdf'}: shutil.copy2(f, d / f.name)
for f in ['main.tex', 'refs.bib'] + [f'numbers{s}.tex' for s in ['', '2', '3', '4', '5', '6', '7']]:
    shutil.copy2(SRC / 'paper' / f, ART / 'paper' / f)

# 2) paper scripts with portable paths
HDR = "import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))\nfrom _paths import ROOT as R, ART as P\n"
for f in ['make_figures3.py', 'make_figures4.py', 'make_figures5.py', 'make_tables4.py', 'make_tables5.py', 'fix_bib_unicode.py']:
    s = (SRC / 'paper' / f).read_text(encoding='utf-8')
    s = re.sub(r"R = Path\(r'E:\\HydroResearch'\); P = R / 'icde_probe/republish_pilot'; O = P / 'paper'; OUT = P / 'out'",
               lambda m: HDR + "O = P / 'paper'; OUT = P / 'out'", s)
    s = re.sub(r"R = Path\(r'E:\\HydroResearch'\); O = R / 'icde_probe/republish_pilot/paper'", lambda m: HDR + "O = P / 'paper'", s)
    s = re.sub(r"P = Path\(r'E:\\HydroResearch\\icde_probe\\republish_pilot'\); O = P / 'paper'", lambda m: HDR + "O = P / 'paper'", s)
    s = s.replace("R / 'icde_probe/republish_artifact/labels'", "P / 'labels'")
    s = s.replace("open(P / 'g4.py'", "open(P / 'src/g4.py'").replace("open(P / 'g1.py'", "open(P / 'src/g1.py'")
    s = s.replace("sys.path.insert(0, str(R / 'catalog'))\nfrom index_global_wse_2026_10_16 import stream_array",
                  "sys.path.insert(0, str(P / 'src'))\nfrom _stream import stream_array")
    (ART / 'paper' / f).write_text(s, encoding='utf-8')
    left = [l.strip() for l in s.split('\n') if re.search(r"E:[\\/]|HydroResearch", l)]
    print(f, 'remaining:', left or 'none')

# 3) tolerance analysis script (src/)
s = (SRC / 'g1x_tolerance.py').read_text(encoding='utf-8')
s = s.replace("open('E:/HydroResearch/icde_probe/republish_pilot/g1.py'", "open(ART / 'src/g1.py'")
s = s.replace('import json\n', "import json, sys, os\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nfrom _paths import ROOT, ART\n", 1)
(ART / 'src' / 'g1x_tolerance.py').write_text(s, encoding='utf-8')
print('g1x_tolerance remaining:', [l for l in s.split('\n') if 'HydroResearch' in l] or 'none')

# 4) new outputs
for f in ['g1x_tolerance_summary.csv', 'g1x_tolerance_pairs.csv']:
    shutil.copy2(SRC / 'out/g1' / f, ART / 'out/g1' / f)
print('synced')
