"""One-off: copy analysis scripts from the working directory into the artifact and replace machine-specific paths.
Run from anywhere; prints every remaining machine-specific reference for manual review."""
import re, shutil
from pathlib import Path

SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot')
ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact')
FILES = ['g1.py', 'g1x_magnitude.py', 'g1x_8y_vs_30y.py', 'g2.py', 'g2_cache.py', 'g2_load.py', 'g2_summary.py',
         'g3.py', 'g3_lstm.py', 'g4.py', 'g4x_checks.py', 'pilot_republish.py', 'pilot2.py']
(ART / 'src').mkdir(parents=True, exist_ok=True)

HEADER = "from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root\n"
RULES = [
    # artifact-internal locations (outputs, cache, sibling scripts)
    (r"ROOT / 'icde_probe/republish_pilot/", "ART / '"),
    (r"r'E:\\HydroResearch\\icde_probe\\republish_pilot\\out\\g1\\g1_pairs.csv'", "str(ART / 'out/g1/g1_pairs.csv')"),
    (r"open\('E:/HydroResearch/icde_probe/republish_pilot/g1.py'", "open(ART / 'src/g1.py'"),
    (r"'E:/HydroResearch/icde_probe/republish_pilot/g1.py'", "ART / 'src/g1.py'"),
    (r"sys.path.insert\(0, 'E:/HydroResearch/icde_probe/republish_pilot'\)", "sys.path.insert(0, str(ART / 'src'))"),
    (r"open\('g1.py'", "open(ART / 'src/g1.py'"),
    (r"open\('g2.py'", "open(ART / 'src/g2.py'"),
    (r"open\('g4.py'", "open(ART / 'src/g4.py'"),
    # data root
    (r"Path\(r'E:\\HydroResearch'\)", "ROOT"),
    (r"r'E:\\HydroResearch\\icde_probe\\raw\\nwis_states\\vt_nh_long.parquet'", "ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet'"),
    (r"r'E:\\HydroResearch\\data\\Expansion_2026-10-16\\GlobalRiverWSE_17130396\\Result datasets.zip'", "ROOT / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip'"),
    (r"r'E:\\HydroResearch\\data\\Expansion_2026-10-19\\ANA'", "ROOT / 'data/Expansion_2026-10-19/ANA'"),
    # stream_array helper now lives in the artifact
    (r"sys.path.insert\(0, str\(ROOT / 'catalog'\)\)\n", ""),
    (r"sys.path.insert\(0, r'E:\\HydroResearch\\catalog'\)\n", ""),
    (r"from index_global_wse_2026_10_16 import stream_array", "from _stream import stream_array"),
]
for f in FILES:
    s = (SRC / f).read_text(encoding='utf-8')
    for a, b in RULES:
        s = re.sub(a, lambda m, b=b: b, s)
    # insert the paths import after the module docstring / first import line
    lines = s.split('\n'); i = 0
    if lines[0].startswith('"""'):
        i = next(k for k in range(len(lines)) if k > 0 and lines[k].rstrip().endswith('"""')) + 1 if not lines[0].rstrip().endswith('"""') or lines[0].strip() == '"""' else 1
    lines.insert(i, "import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\n" + HEADER.rstrip())
    s = '\n'.join(lines)
    s = s.replace("ROOT = ROOT\n", "")
    (ART / 'src' / f).write_text(s, encoding='utf-8')
    left = [l.strip() for l in s.split('\n') if re.search(r"E:[\\/]|HydroResearch", l)]
    print(f, 'remaining:', left if left else 'none')
