"""Sync v3 (2026-10-20): review-driven analyses (E1 all-pairs bounds, E3 verification, E4 splits), plans, outputs, paper."""
import re, shutil
from pathlib import Path
SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot'); ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact')
HDR = "import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))\nfrom _paths import ROOT, ART\n"

def port(text):
    t = text
    t = t.replace("sys.path.insert(0, 'E:/HydroResearch/icde_probe/republish_pilot')", "sys.path.insert(0, str(ART / 'src'))")
    t = t.replace("ROOT = Path(r'E:\\HydroResearch')", "")
    t = t.replace("R = Path(r'E:\\HydroResearch'); P = R / 'icde_probe/republish_pilot'", "R = ROOT; P = ART")
    t = t.replace("ROOT / 'icde_probe/republish_pilot/out/", "ART / 'out/")
    t = t.replace("R / 'icde_probe/republish_artifact/labels/", "ART / 'labels/")
    return t

(ART / 'src').mkdir(exist_ok=True)
for f in ['e3_verify.py', 'e4_splits.py', 'e4s_load.py']:
    s = (SRC / f).read_text(encoding='utf-8')
    lines = s.split('\n'); i = 0
    if lines[0].startswith('"""'):
        i = next(k for k in range(len(lines)) if (k == 0 and lines[0].count('"""') == 2) or (k > 0 and '"""' in lines[k])) + 1
    lines.insert(i, HDR.rstrip())
    out = port('\n'.join(lines))
    (ART / 'src' / f).write_text(out, encoding='utf-8')
    print(f, 'remaining:', [l.strip() for l in out.split('\n') if 'HydroResearch' in l] or 'none')

PHDR = "import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))\nfrom _paths import ROOT as _R, ART as _A\n"
for f in ['make_numbers8.py', 'make_tables6.py', 'make_tables7.py', 'make_numbers11.py']:
    s = (SRC / 'paper' / f).read_text(encoding='utf-8')
    s = s.replace("P = Path(r'E:\\HydroResearch\\icde_probe\\republish_pilot'); O = P / 'paper'", PHDR + "P = _A; O = P / 'paper'")
    (ART / 'paper' / f).write_text(s, encoding='utf-8')
    print(f, 'remaining:', [l.strip() for l in s.split('\n') if 'HydroResearch' in l] or 'none')

# plans + checksum record
for f in ['PLAN_E3_VERIFY.md', 'PLAN_E4_SPLITS.md', 'FROZEN_2026-10-20.md5']:
    shutil.copy2(SRC / f, ART / 'plans' / f)
# outputs
for d in ['e3verify', 'e4splits']:
    (ART / 'out' / d).mkdir(parents=True, exist_ok=True)
    for f in (SRC / 'out' / d).iterdir():
        if f.suffix in {'.json', '.csv'} and f.name != 'valid.json': shutil.copy2(f, ART / 'out' / d / f.name)
# verification labels
shutil.copy2(SRC / 'out/e3verify/verify_pairs.csv', ART / 'labels/e3_verification.csv')
shutil.copy2(SRC / 'out/e3verify/spotcheck_sample.csv', ART / 'labels/e3_spotcheck_sample.csv')
# paper sources and generated assets
for sub in ['sections', 'tables', 'fig']:
    for f in (SRC / 'paper' / sub).iterdir():
        if f.suffix in {'.tex', '.pdf'}: shutil.copy2(f, ART / 'paper' / sub / f.name)
for f in (SRC / 'paper').glob('numbers*.tex'): shutil.copy2(f, ART / 'paper' / f.name)
for f in ['main.tex', 'refs.bib']: shutil.copy2(SRC / 'paper' / f, ART / 'paper' / f)
rel = ART / 'paper/sections/release.tex'
if rel.exists(): rel.unlink()
print('synced')
