"""Sync v7 (2026-11-08): paper v16 figures (one palette across all figures, E3 as recall/precision grids).
Ports paper/make_figures7.py to the artifact's path convention and copies the redrawn figures and changed paper sources."""
import re, shutil
from pathlib import Path
SRC = Path(r'E:\HydroResearch\icde_probe\republish_pilot'); ART = Path(r'E:\HydroResearch\icde_probe\republish_artifact')

s = (SRC / 'paper/make_figures7.py').read_text(encoding='utf-8')
def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]; s = s.replace(a, b)
rep("R = Path(r'E:\\HydroResearch'); P = R / 'icde_probe/republish_pilot'; O = P / 'paper'; OUT = P / 'out'",
    "import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))\n"
    "from _paths import ROOT as R, ART as P\nO = P / 'paper'; OUT = P / 'out'")
s = s.replace("open(P / 'g4.py'", "open(P / 'src/g4.py'").replace("str(P / 'g4.py')", "str(P / 'src/g4.py')")
assert 'HydroResearch' not in s and 'republish_' not in s
# HydroBASINS land outline is an optional input (README), as in make_figures6.py
rep("import geopandas as gpd, zipfile\n", "import zipfile\n")
rep("land = []\nfor reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']:\n"
    "    z = R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip'\n"
    "    land.append(gpd.read_file(f'zip://{z}!hybas_{reg}_lev01_v1c.shp'))\n"
    "land = pd.concat(land).geometry\n",
    "# HydroBASINS level 1 land outline: optional input (README); without it the map has no background.\n"
    "HB = [R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip' for reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']]\n"
    "land = None\nif all(z.exists() for z in HB):\n    import geopandas as gpd\n"
    "    land = pd.concat([gpd.read_file(f'zip://{z}!' + z.name.replace('_lev01-12_v1c.zip', '_lev01_v1c.shp')) for z in HB]).geometry\n"
    "else:\n    print('HydroBASINS not found under REPUB_ROOT/data/HydroBASINS: map drawn without land outline')\n")
rep("land.simplify(0.2).plot(ax=ax,", "if land is not None: land.simplify(0.2).plot(ax=ax,")
rep("land.clip_by_rect(5, 43, 22, 52).simplify(0.01).plot(ax=ins,", "if land is not None: land.clip_by_rect(5, 43, 22, 52).simplify(0.01).plot(ax=ins,")
s = s.replace("Run after make_figures3.py, make_tables2.py and make_figures6.py", "Run last in README step 8, after make_figures3.py, make_tables2.py and make_figures6.py")
(ART / 'paper/make_figures7.py').write_text(s, encoding='utf-8')
print('make_figures7.py ported')

inputs = set(re.findall(r'\\input\{sections/(\w+)\}', (SRC / 'paper/main.tex').read_text(encoding='utf-8')))
for f in (SRC / 'paper/sections').glob('*.tex'):
    if f.stem in inputs: shutil.copy2(f, ART / 'paper/sections' / f.name)
for f in (SRC / 'paper/fig').iterdir():
    if f.suffix == '.pdf': shutil.copy2(f, ART / 'paper/fig' / f.name)
for f in ['main.tex', 'fig_lineage_v2.tex', 'main.pdf', 'main.bbl']:
    shutil.copy2(SRC / 'paper' / f, ART / 'paper' / f)

r = (ART / 'README.md').read_text(encoding='utf-8')
a = "python -I make_figures6.py; latexmk -pdf main.tex` (run after steps 9–10; `make_figures6.py` redraws Figs. 2 and 4–6 in their final form)"
assert r.count(a) == 1
r = r.replace(a, "python -I make_figures6.py; python -I make_figures7.py; latexmk -pdf main.tex` (run after steps 9–10; `make_figures7.py` redraws Figs. 2–6 in their final, common style)")
(ART / 'README.md').write_text(r, encoding='utf-8')
print('synced')
