# Verification of this artifact

## Clean-clone reproduction (2026-10-26/27)

`git clone` of this repository into a new folder, a fresh Python 3.12.9 virtual environment installed from `requirements.txt`
(pyarrow resolved to 26.0.0 and python-dateutil to 3.0.0, newer than in our working environment), and every step of the README
run in order with `REPUB_ROOT` pointing to our data copies (checksums as in README). No data were re-downloaded: the ANA files
were already present (step 5 would only rewrite its manifest), and `e3_verify.py` used the shipped NWIS site list. Models were
retrained from scratch: shipped `nse.json` files were moved aside first.

| Step | Script | Result |
|---|---|---|
| 1, 1b | `g1.py`, `g1x_magnitude.py` | `out/g1/*` **identical** (E1, Table II/III) |
| 2, 3, 3b | `g2_cache.py`, `g2.py` ×4, `g2_summary.py`, `g2x_sensitivity.py` | positives and all class-c1 decisions **identical**; perturbed negatives (c3, c5) differed, see defect 3; after the fix, two runs with different hash seeds are **byte-identical** |
| 3c | `qstep_check.py` | **identical** |
| 4 | `g3.py` | headline (5,341 affected records, median gain 0.511) identical; P2-only counts differed, see defect 2; after the fix, runs with hash seeds 1 and 7 are **byte-identical** |
| 4b | `g3_lstm.py` (GPU, retrained) | per-basin NSE **identical** (3 seeds × 2 conditions) |
| 6, 6c | `g4.py`, `g4x_checks.py`, `g4x_pergauge.py` | summaries **identical**; per-day tables identical up to row order (244,441 days; 42,971 BR rows) |
| 7 | `build_labels.py` | label contents **identical** up to row order (9,844 copy pairs; 224,253 discovery pairs; 244,441 causes) |
| 7b | `g1x_tolerance.py` | **identical** |
| 7c | `e3_verify.py` | decisions **identical** (81 R2 / 350 R3 / 150 R4); bounds follow the corrected E3 negatives |
| 7d | `e4_splits.py` (GPU, retrained, 10 models) | per-basin NSE **identical** (max abs. difference 0.0); summary identical |
| 7e | `e4_fixedtest.py` (GPU, retrained, 10 models) | per-basin NSE **identical** (max abs. difference 0.0) |
| 8 | all `paper/make_*.py` + `latexmk` | tables and `numbers*.tex` **identical**; figures pixel-identical at 100 dpi (PDF metadata differs); compiled paper text-identical to our draft |

GPU results were obtained on the same NVIDIA P104-100 as the originals; other GPUs or driver versions may give small numeric differences.

## Defects found and fixed by this run

1. **`__file__` lost in `exec`-based reuse** (`g1x_tolerance.py`, `g2_cache.py`, `g4.py`, `g4x_checks.py`, `paper/make_figures3.py`,
   `paper/make_figures4.py`): the ported path header failed when another script's source was executed in a fresh namespace.
   Fixed by passing `__file__`. No change to results.
2. **Hash-seed-dependent tie-breaking in `g3.py`**: when a test basin had several copy partners with the same overlap length,
   iteration over a Python `set` decided the winner. Now sorted. Effect: P2-only affected records 4,463 → 4,488, share of test
   basins 10.30% → 10.36% (paper: 10.3 → 10.4); all-pairs results unchanged.
3. **Hash-seed-dependent perturbation seeds in `g2.py`**: negatives were listed from a `set`, and each negative's perturbation
   seed (c3 window, c5 jitter) is its list index. Now sorted. Effect on the paper: Table V and the E3 bounds change in the third
   decimal for c3/c5; in c3, exact equality (M3) now makes 48 matches with no false one (precision 1.00 at 1.2% recall; previously
   2 false, 0.96). The pre-registered E3 gate (which also requires a recall gain of 0.10) still fails; the paper's wording was
   corrected from "no rule reaches 0.99" to "only M3, in one class and at 1% recall".
4. **Silent NWIS failures in `e3_verify.py`**: transient errors were swallowed (100 of 344 sites returned in one run). The script
   now reuses the shipped site list unless `--refetch` is given and aborts on a failed batch.
5. **Resuming hid retraining**: `e4_splits.py`, `e4_fixedtest.py` and `g3_lstm.py` skip models already in `nse.json`; the README
   now says so.
6. **Stale paper scripts and inputs**: `paper/make_tables2.py` lagged behind the paper (old Table IV layout), `paper/main.bbl` was
   stale, `build_labels.py` dropped the E3 section of `LABELS.md`, the map figure needed an undocumented HydroBASINS input and
   `geopandas`. All fixed; HydroBASINS is documented as optional.

## Earlier checks (2026-10-19)
- Fast loader: `src/g2_load.py` vs the xarray reader on sample Caravan files gives identical values.
- E2 consistency: divergent days re-derived inside `src/g4.py` equal E1's per-chain counts (153,797 / 47,673 / 42,971).

The scripts differ from our working copies only in path configuration (`src/_paths.py`, `src/_stream.py`) and the fixes above;
`tools/port_scripts.py` and `tools/sync_v*.py` document every substitution.
