# G4 — attribution report (2026-10-19)

Rules: `PLAN_G4_AMENDMENT.md`, frozen before any G4 data were read or downloaded. Implementation details were fixed in the `g4.py` header before running.
Raw outputs (`out/g4/`): `g4_days.parquet` (one row per divergent day with its cause), `g4_br_status.parquet`, `g4_unstable_pairs.csv`, `g4_summary.json`, `g4_raw.pkl`; robustness checks in `g4x_checks.json`.

## Data actually used
- **ANA HidroSerieHistorica:** 105 of 105 stations, 0 errors, **210 MB**. This was above the ~170 MB estimate and below the 220 MB stop.
- **CAMELS-BR v1.1 streamflow m³/s:** 135.3 MB, md5 matches Zenodo.
- **LamaH-CE hourly runoff + gap records:** extracted locally, 6.2 GB, 882 hourly files.
- **Determinism:** divergent-day counts reproduce G1 exactly (P3 153,797; P2-lamah 47,673; BR 42,971).
- **B3 not applied.** Two official ANA manuals give conflicting status-code meanings (HIDRO 1.2: 2 estimated / 3 doubtful; SRDH: 3 estimated / 4 doubtful), so per the frozen rule the codes are reported raw only.

## Verdicts (frozen rules)
| Chain | Divergent days | Explained | Localized | Verdict | Main cause |
|---|---:|---:|---:|---|---|
| **LamaH-P3** (Caravan lamah vs LamaH-CE) | 153,797 | **86.8%** | 0.7% | **EXPLAINED** | L2 aggregation/day boundary (133,554 days) |
| **LamaH-P2** (GRDC-Caravan vs Caravan lamah) | 47,673 | **76.3%** | 20.6% | **EXPLAINED** | L2 aggregation/day boundary (36,317); GRDC differs from both LamaH products (9,658) |
| **BR** (GRDC-Caravan vs Caravan camelsbr) | 42,971 | 0.01% | **83.1%** | **LOCALIZED** | B5: the CAMELS-BR/Caravan branch disagrees with today's ANA while GRDC agrees (30,287); the reverse (5,393); unattributed 7,280 |

Pooled over all three chains (no verdict, because P3 dominates): explained 69.5%, localized 19.1%.

## What the causes mean (with robustness checks; descriptive, no verdict changes)

**LamaH: a one-hour day-boundary shift.**
- On a fixed sample of 25 P3 gauges (19,970 divergent days), Caravan's value equals the LamaH hourly mean over **[D−1h, D+23h)** on **80.7%** of divergent days.
- The other frozen windows give 0.6% (calendar day), 0.6% (07–07) and 3.5% (previous 07–07).
- **Placebo windows outside the frozen set** give 1.3% (+12 h), 2.9% (+3 d) and 2.4% (−3 d). So L2 is specific, not a smooth-hydrograph coincidence.
- **Interpretation (unverified):** Caravan's LamaH streamflow is aggregated on a day boundary one hour off LamaH-CE's own daily product, consistent with UTC vs CET day boundaries. Divergence then appears whenever flow changes quickly within the day, which explains why it is spread evenly over all years (G1: flat ~5%).
- **LamaH interpolation (L1)** explains almost nothing (78 days).
- **The scale-unstable P3 pairs (602) are not drifting:** median rolling-k max/min 1.005, and none fits a single change point. They were most plausibly excluded from G1 by the ratio spread that this same boundary shift creates. So G1's P3 rate (5.1% on 257 gauges) likely *understates* how many gauges are affected.

**LamaH-P2: GRDC differs from both LamaH products on ~20% of divergent days.**
- On these days the national-agency → GRDC branch disagrees with LamaH-CE and Caravan alike. The cause is not identified (no anonymous re-fetch exists: eHYD returns 404, GKD is form-only).

**BR: localized to the CAMELS-BR branch, cause consistent with ANA revising data after CAMELS-BR was built (not verifiable).**
- B1 almost never fires (8 days), so Caravan reproduces CAMELS-BR faithfully. The divergence enters at **ANA → CAMELS-BR** (CAMELS-BR differs from today's ANA while GRDC matches it) on 70% of divergent days.
- **It is not a raw-vs-checked effect:** B2 = 3 days. ANA returns very few level-1 (raw) rows for these stations, and CAMELS-BR flags 80% of the B5 days as ANA-consistency-checked, against 91% over all days of the same gauges.
- **It is strongest in old data:** 81% of divergent days before 2000 and 78% in 2000–09 fall to the CAMELS-BR branch, vs ~56% after 2010. In the later years "unattributed" grows to 30–34%.
- The pattern is consistent with ANA re-issuing historical series (e.g. revised rating curves) after CAMELS-BR's 2020 snapshot, with GRDC holding a later vintage. Without dated ANA vintages this stays **unverified**, as the plan requires.
- **The scale-unstable BR pairs (94) drift for real:** median rolling-k max/min 1.23, p90 2.67, and none fits a single change point. These are multi-step or gradual changes, not unit or area constants.
- **ANA raw status codes on divergent days:** 1 → 36,486; 2 → 5,104; others < 400. Meanings are not asserted (see B3).

## What G4 means for the paper
| Chain | Claim allowed |
|---|---|
| LamaH (both pairs) | **Measured and explained:** a 1-hour aggregation-boundary difference between Caravan and LamaH-CE produces divergence on ~5% of days across >90% of gauges, demonstrated against the hourly source with a placebo control |
| BR | **Measured and localized:** the divergence enters between ANA and CAMELS-BR, not inside Caravan; cause consistent with source-side revision, not verified |
| GRDC branch, central Europe | Measured, cause open |

Taken with G1–G3:
- **K1 (fidelity census)** now has a measured rate, a localization, and an explanation for the largest chain.
- **K4 (leakage)** stands.
- **K3 (method)** was dropped at G2.
- **K2 (benchmark)** gains labelled causes per divergent day.

## Limits
1. The L2 explanation identifies a *window* that reproduces the copy. Which software step did it, and whether the cause is a UTC/CET boundary, is not documented by either publisher.
2. "B5 localized" relies on today's ANA as the root. A root that was itself revised can only order the copies by vintage, not prove which is "correct".
3. The BR results cover the 105 scale-stable pairs only; the 94 unstable pairs are descriptive.
