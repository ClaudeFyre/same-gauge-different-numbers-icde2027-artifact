# PLAN_G4_AMENDMENT — attribution of divergence in the Brazil and LamaH chains
Frozen 2026-10-19, before any G4 data are read or downloaded. Amends the G4 section of `PLAN_G1_G4.md`. All other gates stay unchanged.
Status: **DRAFT FROZEN — awaiting user approval** (downloads > 100 MB; see §5).

## 0. Why amend
- The original G4 targeted USGS divergence (VT/NH first). G1 showed USGS chains are faithful: the VT/NH pair is 0% under the frozen τ, and P5 is 0.06%. The original G4 has nothing to attribute, so it is **suspended**, not run.
- The divergent chains (G1) are:
  - P2 GRDC-Caravan vs Caravan camelsbr (BR): 105 stable pairs, 42,971 divergent days
  - P2 GRDC-Caravan vs Caravan lamah: 119 stable pairs, 47,673 divergent days
  - P3 Caravan lamah vs LamaH-CE: 257 stable pairs, 153,797 divergent days
- "Divergent day", τ, k and "stable" keep their G1 definitions exactly. The divergent-day set is the one already stored by G1 (re-derived deterministically from `g1.py`). It is not recomputed with any new parameters.

## 1. Lineage graphs (assumed from publisher documentation; stated as assumptions)
- **BR:** ANA → CAMELS-BR v1.1 (m³/s) → Caravan camelsbr (mm/d). Separately: ANA → GRDC → GRDC-Caravan (mm/d) → GlobalRiverWSE-GRDC.
- **LamaH:** national agencies (AT HZB / DE / CZ …) → LamaH-CE hourly → LamaH-CE daily → Caravan lamah. Separately: agencies → GRDC → GRDC-Caravan.
- **Not independent:** GlobalRiverWSE-GRDC is downstream of GRDC (G1 P4: 0.14%), so it never counts as an independent vote.

## 2. Sources
| Source | Role | Access | Size |
|---|---|---|---|
| Caravan v1.6 (camelsbr, lamah), GRDC-Caravan | the diverging copies | local | — |
| LamaH-CE daily + `gaps/` (interpolated steps; documented max gap 6) | LamaH-side generation record | local (`icde_probe/raw/lamah`) | — |
| LamaH-CE hourly, `D_gauges` runoff only | aggregation / day-boundary test | local tar `1_LamaH-CE_daily_hourly.tar.gz` (14.8 GB), selective extraction | a few GB on disk |
| **ANA HidroSerieHistorica** (`telemetriaws1.ana.gov.br`, anonymous, HTTP 200 verified today) | BR root: daily Q with `NivelConsistencia` (1 = raw, 2 = consistency-checked) and per-day status | download, ~1.6 MB/station (1980–2023 measured) | **~170 MB** for the 105 stable BR gauges |
| **CAMELS-BR v1.1** `02_CAMELS_BR_streamflow_m3s.zip` (Zenodo 3964745) | intermediate node between ANA and Caravan | download | **135.3 MB** |
| Austria eHYD | AT root | **not re-fetchable**: every known anonymous URL pattern returned 404; not guessed further | — |
| GKD Bayern | DE root | web form only; **not used** (no form submission) | — |
| GRDC portal | GRDC root | registration required; not used | — |

The ANA status codes are read per ANA's published convention: 0 blank, 1 real, 2 estimated, 3 doubtful, 4 dry gauge. Their meanings are confirmed from ANA documentation before use. If they cannot be confirmed, the codes are reported raw.

## 3. Tests per divergent day (applied in this order; the first that applies wins)
Matching against a third series always uses that series' own k (median ratio over its full overlap with the copy) and the G1 τ.

**LamaH chains (P3, then P2-lamah):**
- **L1 Interpolation:** the day contains a LamaH `gaps/` timestep (interpolated in LamaH) → *cause: gap interpolation*.
- **L2 Aggregation / day boundary:** the copy matches the LamaH **hourly** mean for the same day under an alternative aggregation (UTC day vs local-standard-time day; 00–24 vs 07–07), while LamaH daily does not → *cause: aggregation/day-boundary*.
- **L3 Scale segment:** the two-segment k model applies. One change point is chosen to minimise the pooled IQR of a/(k_i·b). It applies if both segments have IQR ≤ 0.01, |k1/k2 − 1| ≥ 0.02 and each segment is ≥ 365 days; days whose divergence disappears under the segment's k → *cause: scale/area change*.
- **L4 Third-copy localization (not explanation):** for P3, compare with GRDC-Caravan where it exists.
  - GRDC ≈ LamaH daily → *localized: LamaH-CE → Caravan edge*
  - GRDC ≈ Caravan → *localized: agency → LamaH-CE edge*
  - neither → *unresolved*

  For P2-lamah, the same logic with LamaH daily as the third series. Note it is not independent of Caravan lamah, so this test can only separate "GRDC differs from both LamaH products" from the rest.

**BR chain (P2-BR):**
- **B1 CAMELS-BR conversion:** Caravan camelsbr vs CAMELS-BR m³/s on that day. Mismatch (CAMELS-BR ≈ GRDC-Caravan) → *localized: CAMELS-BR → Caravan edge*. Match → the divergence predates Caravan; continue.
- **B2 Consistency level:** compare GRDC-Caravan and CAMELS-BR with ANA level 1 and level 2. One copy matches level 1 and the other level 2 → *cause: raw-vs-consistency-checked version*.
- **B3 Estimated/doubtful day:** the ANA status for that day is "estimated" or "doubtful", and at least one copy is NaN-free where ANA marks it estimated → *cause: estimated value handled differently*. Reported with the code meaning confirmed.
- **B4 Scale segment:** as L3.
- **B5 Root localization:** exactly one copy matches ANA (either level) → *localized: the edge into the other copy*. Neither matches → *unattributed (consistent with a revision after both copies were made; not verifiable without vintages)*.

## 4. Outcome rules (fixed now)
- **Explained** = causes L1, L2, L3, B2, B3, B4.
- **Localized** = L4, B1, B5 with an edge named. These say *where* the divergence entered, not *why*.
- **Unresolved / unattributed** = the rest.
- Verdict **per chain** (BR; LamaH-P3; LamaH-P2):
  - **EXPLAINED** if Explained ≥ 50% of divergent days
  - **LOCALIZED** if Explained < 50% but Explained + Localized ≥ 50%
  - otherwise **OPEN**
- **Paper claim per chain:** EXPLAINED → "measured and explained"; LOCALIZED → "measured and localized to a lineage edge"; OPEN → "measured, cause open". No chain's verdict is extended to another chain.
- **Pooled number** (all three chains) is reported for transparency but carries no verdict, because P3 dominates the pooled day count.
- **Unstable pairs** (BR 94, LamaH-P2 65, P3 602): descriptive only. Report the rolling-k drift (365-day windows), the share with a single change point under the L3 rule, and the ANA level/status mix for BR. No verdict.
- Not allowed: changing τ, the order of tests, the definition of matching, or adding tests after results are seen. A surprising pattern becomes a *new* plan, frozen separately.

## 5. Requires user approval before running
1. **Download ~305 MB in total** over the metered VPN:
   - ANA: 105 stations × ~1.6 MB ≈ 170 MB, sequential requests with a 1 s pause between stations;
   - CAMELS-BR streamflow m³/s: 135.3 MB, one file from Zenodo.
2. **Selective local extraction** of LamaH-CE hourly runoff: local only, a few GB on E: (320 GB free).

If (1) is declined, the BR chain is reported as OPEN by construction and only the LamaH tests run (local data only).
