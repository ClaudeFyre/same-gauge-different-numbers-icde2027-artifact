# G0 literature gate — report (2026-10-18)

Rules: `PLAN_G0.md`, frozen before searching and quoted here unchanged in substance. Verdicts: KILLED / NARROWED / OPEN. **PASS** = K1 not KILLED and at least one of K3/K4 not KILLED. **NARROW-PASS** = K1 NARROWED but K3 or K4 OPEN. **STOP** otherwise.

## 1. Nearest neighbours and verification depth

| Work | What it does (as verified) | Depth |
|---|---|---|
| **GRDC-Caravan** (Färber et al., ESSD 17:4613, 2025) and its review file (AR1) | Reports **1,589 duplicates** between Caravan core and the extension: 202 CAMELS-BR, 944 HYSETS, 69 CAMELS-US, 191 CAMELS-AUS, 183 LamaH-CE. They were kept on purpose because they add 13.8 years on average. Duplicates are not flagged in the data, but the `nat_id` attribute lets users find them. A reviewer asked for a technical validation; the authors **declined further dataset analysis and validation** as out of scope. No value-level comparison of the duplicated series. | Full text and review response |
| **GSIM Part 1** (Do et al., ESSD 10:765, 2018) | Merges 12 archives. Step 2 replaces 3,197 GRDB/EWA gauges with national records. Step 3 finds duplicate candidates from metadata (Jaro–Winkler on river/station names plus distance, average < 0.25) and classifies them by overlap and R²: < 0.90 different, > 0.99 identical, otherwise visual check. **It keeps the longer record**; 846 removed (2.8%). No analysis of how the values of identical pairs differ, no transformation recovery, no source re-fetch. | Full method section |
| Gudmundsson & Seneviratne 2016; ISTI land-surface databank (Rennie et al. 2014, temperature) | Duplicate resolution and station merging in climate archives. ISTI releases merge variants to reflect "structural uncertainty". | Abstract / secondary |
| Clerc-Schwarzenbach et al., HESS 28:4219 (2024) | Caravan forcing vs the original CAMELS forcing: calibration degrades, mainly through precipitation. **Forcing, not streamflow copies.** | Abstract |
| Caravan CAMELS-US update (Zenodo 18061922) | Re-pulls USGS data through 2023 and converts cfs to mm/d by area. One basin is no longer served and the old data was kept. No fidelity comparison. | Record page summary |
| Economic real-time data (Croushore & Stark; Philadelphia Fed vintages) | Revisions of published statistics are studied systematically through vintages. **The concept that published values get revised is known.** | Abstract |
| Dong et al. VLDB 2009/2010 (copy detection) | Already full-text checked in `explore/CONTRIBUTION_DECISION.md`: categorical values or cross-object shared errors, semi-gold truth | Full (earlier) |
| R2D2 (SIGMOD 2024), Gen-T (table reclamation, 2024), Correlation Sketches / QCR (SIGMOD 2021 / ICDE 2022), LakeBench, QJoin, Explain-Da-V (PVLDB 16) | Table containment by schema graph, min-max and content pruning; reconstructing a table from lake tables; join-correlation search; benchmarks for join/union; string-transformation joins; explaining the differences between two *given* versions. None of them targets numeric time-series copies under unit scaling, rounding and partial divergence, where the pairing is unknown. | Abstract only |
| Leakage in large-sample hydrology | No study found that quantifies score inflation from duplicate gauges across Caravan-family datasets. REFORMS covers duplicate leakage in general. | Abstract |

Not found despite targeted searches: any value-level comparison of CAMELS/Caravan streamflow against re-downloaded NWIS; any study of how big USGS approved-data revisions are; any GitHub or issue-tracker duplicate list for the Caravan core (CAMELS-US vs HYSETS).

## 2. Verdict per claim

| Claim | Verdict | Remaining difference |
|---|---|---|
| **K1 census** | **NARROWED** | Duplicate *detection* in hydrology archives is established (GSIM, ISTI), and so is the idea that published values get revised (economics vintages). What remains is the **value-level fidelity of republished copies measured against re-fetched originals**: how often, by how much and why the copies diverge. GRDC-Caravan explicitly left this out, GSIM resolved it by keeping the longer record, and no fidelity study was found. Must not claim "duplicates exist" or "data get revised" as findings. |
| **K2 benchmark** | **NARROWED** (pending) | No lineage-labelled numeric time-series benchmark was found. The nearest neighbours (LakeBench etc.) were read at abstract level only, so the rules do not allow OPEN. |
| **K3 ID-free discovery** | **NARROWED** | GSIM's metadata + R² rule is a strong, simple baseline in hydrology. The method claim survives only where metadata are missing or wrong (e.g. CausalRivers' swapped axes, anonymised or renamed IDs) or where transformations defeat R²-based matching. Depends on G2. |
| **K4 leakage** | **NARROWED** | GRDC-Caravan duplicates are documented and can be mapped through `nat_id`. What remains: (a) inflation for users who combine sets without that mapping, which no study has quantified; (b) repository pairs **without** any mapping (GlobalRiverWSE archive, CausalRivers vs Caravan-DE/CAMELS-DE, LamaH standalone vs Caravan lamah_ vs GRDC); (c) validation metrics that shift when a divergent copy is used as truth. |

## 3. Gate outcome
K1 is not KILLED, and K3 and K4 are not KILLED → **PASS** under the literal frozen rule.

Note on the rules: the PASS and NARROW-PASS conditions overlap. Every claim came back NARROWED, so in substance this is a **pass with rewritten claims**, and the frozen rule is not reinterpreted.

## 4. Consequences for the route (applied to PLAN_G1_G4.md)
1. The **centre of the paper moves to K1**: fidelity and divergence of copies against the source, and attribution of causes. Leakage (K4) becomes supporting evidence. Discovery (K3) is kept only if G2 finds a class where the GSIM-style baseline fails.
2. **Required baseline:** a reimplementation of the GSIM duplicate rule, documented in a peer-reviewed paper, which gives a defensible "existing method" without licence problems.
3. Wording bans: "first to find duplicates", "data revisions matter" as a finding, and "new dedup method" unless G2 supports it.
4. GRDC-Caravan's `nat_id` file gives a free, publisher-provided truth table for 1,589 pairs, which strengthens G1.

## Sources
- [GRDC-Caravan, ESSD 2025](https://essd.copernicus.org/articles/17/4613/2025/) · [review response AR1](https://essd.copernicus.org/preprints/essd-2024-427/essd-2024-427-AR1.pdf)
- [GSIM Part 1, ESSD 2018](https://essd.copernicus.org/articles/10/765/2018/) · [GSIM Part 2](https://essd.copernicus.org/articles/10/787/2018/)
- [Clerc-Schwarzenbach et al., HESS 2024](https://hess.copernicus.org/articles/28/4219/2024/)
- [Caravan CAMELS-US update](https://zenodo.org/records/18061922)
- [ISTI databank technical report](https://www.ncei.noaa.gov/pub/data/globaldatabank/monthly/stage3/ISTI_Databank_Technical_Report_v1.1.0.pdf)
- [Croushore & Stark real-time data](https://www.philadelphiafed.org/-/media/frbp/assets/working-papers/1999/wp99-21.pdf)
- [R2D2](https://arxiv.org/abs/2312.13427) · [Gen-T](https://arxiv.org/abs/2403.14128) · [Correlation Sketches](https://arxiv.org/abs/2104.03353) · [Explain-Da-V](https://www.vldb.org/pvldb/vol16/p1587-shraga.pdf) · [LakeBench](https://www.vldb.org/pvldb/vol17/p1925-chai.pdf) · [QJoin](https://arxiv.org/abs/2512.02444)
- [REFORMS](https://arxiv.org/abs/2308.07832)
