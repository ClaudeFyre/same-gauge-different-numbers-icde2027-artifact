# PLAN_R3_EXTENSIONS — four review-driven extensions (DRAFT for author review, not frozen)

Status: frozen 2026-11-07 after author approval ("ok"), before any of its analyses ran and before the CAMELS-BR v1.2 and DWD log
downloads (md5 in FROZEN_2026-11-07.md5); each part keeps its own pre-set reading, and all results are reported whatever their direction.
Implementation details left open here are fixed in script headers before running.

---------------------------------------------------------------------------------------------------------------------------
## X1. E3 — a learned matcher on the same benchmark
**Question.** Does a supervised matcher trained on value and metadata features reach the 0.99 precision target where the five
rules do not?
- **Data.** The E3 benchmark exactly as released (`labels/discovery_pairs.csv`: 7,706 positives, 216,547 negatives; classes
  c1–c6), with the perturbations of `g2.py` (same seeds; sorted negatives). No lineage key or identifier is a feature.
- **Features** (per pair and class, on the aligned overlap after perturbation): log overlap days; log |k|; IQR of a/(kb);
  share of days within τ (the M4 statistic, continuous); R²; share of exactly equal days after grid rounding (M3 statistic);
  share of days explained by a ±1-day shift; ratio of quantisation steps; log distance (km); |log area ratio|; Jaro–Winkler
  distance of station and of river names (missing → NaN); repository-pair category.
- **Model.** scikit-learn `HistGradientBoostingClassifier` (max_iter 300, learning_rate 0.1, random_state 0), trained on classes
  c1–c5 pooled; c6 scored only (as in Table VI).
- **Evaluation.** Leave-one-region-out over US, EU, BR, AU: train on three regions, test on the fourth, so no gauge or nearby
  gauge appears in both. The decision threshold is fixed inside the training regions (inner leave-one-region-out) as the lowest
  score with precision ≥ 0.99 on the inner predictions, then applied unchanged to the test region. Reported per class, pooled over
  the four test regions: precision/recall (a new column "ML" in Table VI), and precision bounds after the E3 verification (a new
  column in Table VIII).
- **Pre-set reading.** The original method criterion of PLAN_G1_G4 with the matcher as candidate: in at least one class the best of
  M0–M2 has recall < 0.90 at precision ≥ 0.99 **and** the matcher adds ≥ 0.10 recall at precision ≥ 0.99 (original labels).
  Reading "learned matcher passes" or "fails". Reported additionally under the verified upper bound.
- **Error analysis (descriptive).** Errors of the matcher and of M4 are split into (i) *transformation-induced misses*: positives lost
  under c2/c3/c5 or in c4, and (ii) *proximity-induced false matches*: negatives within 50 km, further split by the E3 verification
  into confirmed copies (key failures), confirmed distinct stations, and unresolved.

---------------------------------------------------------------------------------------------------------------------------
## X2. E4 — does leakage matter more for extremes than for NSE?
**Question.** Do copies in training improve scores on high flows more than on NSE, so that peak-flow evaluation is inflated?
- **Models.** Retrain, with the frozen code and seeds, W = R1–R5 (PLAN_E4_SPLITS) and M1–M5, U1–U5 (PLAN_E4_FIXEDTEST), now saving
  daily test predictions. Retraining was bit-identical in the clean-clone run; if any per-basin NSE differs from the stored value by
  more than 1e-6, we stop and report instead of continuing.
- **Metrics per test basin** (1991–2009 days with observations): FHV, the percent bias of the top 2% of the flow-duration curve
  (Yilmaz et al. 2008); AMAX, the median over calendar years with ≥ 300 observed days of |p_max − o_max| / o_max; and, descriptive,
  NSE on days with observed flow ≥ the basin's 90th percentile.
- **Primary.** Per affected (basin, seed) record, Δ = |FHV_M| − |FHV_W| (positive: copies reduce peak bias); median with a 10,000-draw
  basin bootstrap CI (seed 0). **Material** if the median ≥ 5 percentage points and the CI excludes 0.
- **Secondary.** Δ_AMAX defined the same way (material if median ≥ 0.05 and CI excludes 0); negative control on unaffected records;
  pooled: per seed, median |FHV| over all test basins W minus M, mean over seeds with a t-interval (4 d.f.); sensitivity with U.

---------------------------------------------------------------------------------------------------------------------------
## X3. Version evidence for the localised edges
**V1 (ANA insertion dates; local data, no download).** ANA's HidroSerieHistorica records carry an insertion date (`DataIns`) per
monthly record. For the 105 Brazilian stations, per station: share of months with DataIns after 2020-03-13 (CAMELS-BR v1.0) among
months containing ≥ 1 divergent day attributed to the ANA→CAMELS-BR edge, minus the same share among months with no divergent day.
Reading: **"divergent months were re-inserted later"** if the median per-station difference is > 0 with a two-sided sign test
p < 0.05 over stations with both month types; otherwise **"uninformative"** (e.g., bulk re-insertion).
**V2 (CAMELS-BR v1.2, 2025; download 153 MB, needs approval).** `02_CAMELS_BR_streamflow_all_catchments.zip` from Zenodo record
15025488. For the 105 stations, on the CAMELS-BR-edge divergent days of E2: share of days on which v1.2 agrees with ANA's current
series within τ (Sec. III, k fitted per station on v1.2 vs ANA), and the same share on non-divergent days (control).
Reading: **"dated revision evidence"** if ≥ 50% of the CAMELS-BR-edge divergent days agree with ANA in v1.2 while ≥ 95% of control
days still agree; **"no evidence"** if < 20%; otherwise "partial".
**V3 (DWD logs; 110 KB).** `Change_log_CDC_ftp.txt` and `Error_log_CDC_ftp.txt`. Descriptive only: entries naming daily climate
data (kl) or any of the 150 E5 stations, with dates; share of E5 RR edge-divergent days that fall in a logged correction period.

---------------------------------------------------------------------------------------------------------------------------
## X4. Synthetic lineage — can the attribution protocol recover planted causes?
**Question.** With known ground truth, how often does the E1+E2 protocol (i) stay silent on benign transformations, (ii) place a
planted divergence on the correct edge, and (iii) name the correct transformation?
- **Roots.** 100 LamaH-CE hourly series (daily means formed in UTC, as LamaH) and 100 DWD daily RR series from E5, drawn with seed 0.
- **Graph per chain.** root → A → B and root → C (independent sibling), i.e. the shape of the GRDC branch in E2.
- **One planted cause per chain** (uniform over applicable types, seed 0), on one uniformly chosen edge:
  T0 benign: unit scale (k = 0.0283168, cfs → m³/s, or k = 86.4/area, m³/s → mm/d) plus re-rounding to a coarser decimal grid (must not diverge);
  T1 time window shifted by −1 h (LamaH roots only); T2 linear interpolation of random gaps of 1–6 days covering 2% of days;
  T3 rating revision: scale factor 1.05–1.30 after a random date (segment change); T4 version replacement: the upstream series is
  revised after copying (the copy keeps the old values; the revision is T3 applied to the parent only after the copy edge);
  T5 transmission errors: 0.5% of days multiplied by a random factor 0.5–1.5.
- **Protocol run unchanged**: E1 tolerance and divergent days on every pair; E2 tests in frozen order (window means, interpolation
  records, two-segment scale, third-copy localisation).
- **Outcomes.** False-divergence rate on T0; edge-localisation accuracy (correct edge among root→A, A→B, root→C) for T1–T5;
  explanation accuracy (named type correct) for the types the protocol can name (T1–T3); confusion matrix of named vs planted type.
- **Pre-set reading.** Protocol **"validated"** if the false-divergence rate on T0 ≤ 0.5%, localisation accuracy ≥ 90% for T1–T5 and
  naming precision ≥ 90% for T1–T3; otherwise each failing criterion is reported as a limitation.

---------------------------------------------------------------------------------------------------------------------------
## Cost and paper integration
GPU ≈ 2 h (X2). CPU ≈ 2–3 h (X1 features, X4). Download 153 MB (X3 V2, needs approval) + 110 KB.
Paper: no new tables or figures; X1 adds a column to Tables VI and VIII and two sentences; X2 adds two sentences to E4; X3 adds two sentences to E2 and one to E5; X4 needs ≈ 0.25 page of text in E2, recovered
by further tightening prose.
