# PLAN_G0 — literature gate for the republication route (frozen 2026-10-18, before any search)

## Claims under test
- K1 Census: cross-repository duplication + divergence of republished hydrological time series, measured against re-fetched originals.
- K2 Benchmark: lineage-labelled pairs/segments (copy / transformed copy / divergent segment / correlated non-copy) with transformation truth.
- K3 Evaluation: existing ID-free copy-discovery and divergence-localization methods on transformed numeric copies.
- K4 Consequence: train/test leakage from duplicated gauges across Caravan-family datasets; validation-metric shift from divergent copies.

## Search scope (stop when all rows are covered; no open-ended expansion)
Hydrology: Caravan / GRDC-Caravan / Caravan extensions duplicate handling; CAMELS vs NWIS fidelity or version audits; USGS provisional→approved revision studies; GRDC data-quality / duplicate-station studies; benchmark leakage in large-sample hydrology.
DB/data: Explain-Da-V, Auto-Pipeline (version/transform explanation); Dong et al. copy detection; time-series join/correlation discovery and sketches in data lakes; dataset/table dedup and near-duplicate dataset detection; data-version divergence / provenance inference without metadata.

## Verdict rules per claim (decided now)
- KILLED: a found work does the same thing on the same object class (hydrological republished series, or generic numeric time-series copies with transformations) with source-referenced truth.
- NARROWED: a found work covers part (e.g. duplicate list exists but no divergence/fidelity; or method exists but evaluated without transformations/truth). Claim is rewritten to the remaining difference.
- OPEN: no work found after covering scope.
Verification depth must be stated per item (abstract / full text). A claim can be "OPEN" only if its nearest neighbours were read beyond the abstract.

## Gate outcome (decided now)
- PASS: K1 not KILLED and at least one of K3/K4 not KILLED.
- NARROW-PASS: K1 NARROWED but K4 or K3 OPEN → proceed with rewritten claims.
- STOP: K1 KILLED and K4 KILLED, or all four KILLED/NARROWED to nothing distinctive.
No later change to these rules; the report must quote them.
