# G1 — prevalence report (2026-10-18)

Rules: `PLAN_G1_G4.md`, frozen before any G1 data were read. Script `g1.py`, raw outputs in `out/g1/` (`g1_summary.json`, `g1_pairs.csv`, `g1_run.log`).
Data: Caravan v1.6 (local, 7 subsets, 16,299 basins); GRDC-Caravan CSV (5,356 basins); standalone LamaH-CE daily; GlobalRiverWSE 30y Q file. One choice was made at run time and before results: the 30y archive file was used for P4/P5, as it gives the longest overlap. The 8y file later proved identical on all common days (see §4).

## 1. Verdict: **PASS** on both frozen legs
- **Divergence leg:** 3 counting pairs ≥ 1.0% (rule: ≥ 2).
- **Duplicate leg:** 1,828 of 5,356 GRDC-Caravan basins have a `nat_id` duplicate in Caravan core, which is **8.4% of the 21,655 combined basins** (rule: ≥ 2%).

## 2. Per pair (stable pairs only in rates; τ = max(2%, 2×rounding half-steps))

| Pair (a vs b) | Keyed | Compared | Scale-unstable | Overlap days | Divergence rate | Shift-explained share | Gauges ≥1% | Top-10% gauges' share |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| P1 hysets vs camels (same USGS id) | 641 | 640 | 60 | 7.07M | 0.37% | 4.5% | 11.4% | 84% |
| P2 GRDC-Caravan vs camels | 72 | 72 | 19 | 0.66M | 0.06% | 3.0% | 3.8% | 97% |
| P2 GRDC-Caravan vs hysets | 949 | 949 | 375 | 9.47M | 0.06% | 21.9% | 3.1% | 98% |
| P2 GRDC-Caravan vs camelsaus | 490 | 489 | 252 | 4.31M | 0.47% | 23.8% | 11.0% | 80% |
| **P2 GRDC-Caravan vs camelsbr** | 202 | 199 | 94 | 1.38M | **3.12%** | 37.5% | **56%** | 40% |
| **P2 GRDC-Caravan vs lamah** | 184 | 184 | 65 | 1.51M | **3.16%** | 10.4% | **50%** | 35% |
| **P3 Caravan lamah vs LamaH-CE** | 859 | 859 | **602** | 2.99M | **5.14%** | 8.8% | **92%** | 25% |
| P4 GWSE-GRDC vs GRDC-Caravan | 3,979 | 3,977 | 2,052 | 27.7M | 0.14% | 18.5% | 2.8% | 100% |
| P5 GWSE-USGS vs Caravan US (no VT/NH) | 2,478 | 2,475 | 1,294 | 14.7M | 0.06% | 16.7% | 1.7% | 100% |
| P6 Caravan-DE vs CausalRivers | — | — | — | — | skipped: no lineage key (as pre-specified) | | | |

Key counts reproduce the publisher's own duplicate list (GRDC-Caravan paper: BR 202, US 69, HYSETS 944, LamaH 183). CAMELS-AUS is higher (490 vs 191) because local Caravan v1.6 carries 561 CAMELS-AUS basins, a newer core than the paper's.

## 3. Descriptive follow-ups (not gate criteria)

**Two regimes.**
- The USGS-based chains (P1, P2-US, P5) and the GRDC↔archive chain (P4) are faithful: ≤ 0.4%, with divergence confined to a few gauges.
- The Brazilian and Central-European chains diverge **broadly**: 50–92% of gauges reach ≥ 1%.

**Magnitude** (`g1x_magnitude.csv`). Divergent days are not a low-flow rounding artifact: only 18%, 4% and 3% of them fall in the lowest flow decile.
- **BR:** large, median 8.1%; 44% of divergent days > 10%, 12% > 50%.
- **LamaH chains:** small, median 3.1–3.5% (P3: only 3.7% of divergent days > 10%).

**By year.**
- BR rises from ~2% before 2010 to 7% in 2015 and 13% in 2018.
- GRDC-vs-lamah jumps in the final overlap years (6% in 2015, 67% in 2018, on few days).
- P3 stays flat at ~5% in every year from 1985 to 2015.

**Readings, unverified.** Recent-year growth suggests different vintages or revisions. A flat rate across all years in P3 suggests a systematic processing difference between Caravan's LamaH and the standalone release. LamaH quality flag `ckhs`: 4.7% (flag 0) vs 5.2% (flag 1), no meaningful difference.

## 4. Correction to the route's motivating pilot (important)
- Under the frozen τ, the pilot pair (GWSE 8y vs NWIS VT/NH) has **0 divergent days** on 88 stable gauges (8 unstable).
- The "4.4% of days differ > 2%" cited in `ROUTE_ICDE_2026-10-18.md` was **entirely an artifact** of the pilot's naive 2% tolerance applied to values rounded to 0.01 m³/s.
- Also exploratory: Caravan vs current NWIS on VT/NH shows 0.17%; the GWSE 8y and 30y files are identical on all 8,580 common gauges.
- The route document has been corrected. The motivation now rests on the G1 numbers above.

## 5. Caveats that bound the claim
1. **The scale-stability filter removed many pairs:** 70% in P3, about 52% in P4/P5, about 47–51% in P2-AUS/BR. The unstable pairs have IQR(a/kb) of 0.016–0.13, so the transformation between copies is not a single constant there. These pairs are **excluded, not counted as divergent**. The rates above therefore describe constant-scale copies only, and P3's 5.1% rests on 257 gauges. What the unstable pairs are (area changes, gaps, mixed sources, rating-curve differences) is unknown, and they are a natural G4 target.
2. The 2% bar is close to the LamaH-chain magnitudes, so those rates are sensitive to τ by construction. The rule stays frozen, and this is reported, not tuned.
3. The duplicate leg reproduces a share the publisher documents (via `nat_id`). It shows that the leakage *opportunity* is large, not that anyone leaked. G3 tests the consequence.
4. A lineage key is truth for *identity*, not for *which copy is correct*. Divergence says the copies disagree; G4 has to say why.

## 6. What this means for the route
- K1 now has a real basis: two non-US repository chains where a documented, intentionally kept duplicate set disagrees on 3–5% of days, broadly across gauges. In Brazil the disagreements are large.
- US chains are a faithful control group.
- The VT/NH-first plan for G4 in PLAN_G1_G4 assumed USGS divergence, and **that divergence has disappeared**. Under the frozen G4 text, the USGS cause tests now have almost nothing to attribute. The diverging chains (BR via ANA, LamaH via Austrian/German agencies) need source re-fetch from agencies that are not covered in the current plan. ANA was 401 in the inventory.
- Next gates per plan: G2 ∥ G3. G4 needs a **plan amendment**, written before it runs, to name re-fetchable sources for BR/LamaH, or to restrict G4 to the files we already hold (Caravan vs GRDC vs LamaH three-way voting on which copy is the outlier).
