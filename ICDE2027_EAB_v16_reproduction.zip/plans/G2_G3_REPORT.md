# G2 and G3 — report (2026-10-18/19)

Rules: `PLAN_G1_G4.md`, frozen before G1. The implementation choices that the plan left open were written into the script headers (`g2.py`, `g3.py`) before running.
Raw outputs: `out/g2/` (`g2_rows.parquet`, `g2_summary.json`, per-region logs) and `out/g3/` (`g3_summary.json`, `g3_leakage_rows.csv`, `g3_validation_rows.csv`).

Execution note: the first G2 runs were slow because ~17k netCDF files were reloaded on every run. The final run uses a one-time parallel cache (`g2_cache.py` / `g2_load.py`). The fast loader was checked to give values identical to the xarray path on sample files, and the cache holds the same 24,672 series as the earlier run. The four regions ran in parallel and were merged by `g2_summary.py`, which reuses the scoring code verbatim.

## G2 — ID-free discovery: **no method contribution** (measurement only)
Pool: 7,706 positives (c1 3,826; c4 183; c6 unstable 3,697) across US / EU / BR / AU; 216,547 negatives, of which 16,547 are hard.

Pooled results, as precision / recall (recall at p ≥ 0.99 is **0 for every rule in every class**, because no rule reaches precision 0.99):

| Class | M0 coords+area | M1 R²>0.99 | M2 GSIM rule | M3 exact hash | M4 quantization floor |
|---|---|---|---|---|---|
| c1 scaling only | .966 / .956 | .926 / .992 | .940 / .986 | .959 / .012 | .957 / **1.000** |
| c2 + coarse rounding | .966 / .956 | .929 / .992 | .940 / .986 | — / 0 | .943 / .533 |
| c3 + partial window | .966 / .956 | .937 / .988 | .947 / .982 | .960 / .013 | .959 / .994 |
| c4 divergent copies (≥5%) | .567 / .929 | .350 / .896 | .421 / .962 | — / 0 | .412 / .661 |
| c5 metadata degraded | .942 / **.183** | .926 / .992 | .907 / **.497** | .959 / .012 | .957 / 1.000 |
| c6 scale-unstable (report only) | .965 / .958 | .916 / .902 | .935 / .937 | .913 / .006 | .944 / .786 |

**Frozen verdict:** no class has the best of M0–M2 below 0.90 recall at p ≥ 0.99 together with M3/M4 improving it by ≥ 0.10. → **Drop the method contribution (K3).**

What the table still shows (descriptive):
- **Strict equality (M3) is useless on real republished data.** Recall is ~1% even for clean copies.
- **Metadata degradation breaks the metadata-based rules** (c5: M0 0.18, M2 0.50). Value-based rules hold up (M1 0.99, M4 1.00), but at precision 0.93–0.96.
- **Coarse re-rounding hurts the quantization-floor test** (M4 0.53 in c2). The correlation-based rules are robust to it.
- **Divergent copies (c4) are the hardest class for every rule** (precision 0.35–0.57).

**Why precision caps near 0.96 (post-hoc diagnosis, not a verdict input).** I inspected the 173 c1 false positives of M4. 135 are hard negatives and 38 easy; the median distance is 3.7 km. Two groups dominate:
1. **Unlabelled true copies.** These are pairs under 1 km apart whose lineage keys failed to match because of ID formats: GRDC `nat_id` vs CAMELS-AUS (`14214.1` vs `314214`), Austrian HZB vs LamaH numbering, and GlobalRiverWSE GRDC stations the archive never mapped to their USGS IDs. 187 negatives lie within 1 km.
   - Excluding them post hoc (`g2x_sensitivity_excl_1km_negatives.json`): M4 reaches 0.972 precision at recall 1.0, M1 0.945, M2 0.969. M0 becomes 1.0 trivially, since it requires ≤ 1 km. Still nothing reaches 0.99.
2. **Distinct gauges with near-identical series** (different USGS numbers 10–25 km apart, e.g. 08200700 / 08202700, found in two repository pairs). These look like derived or transferred records *between different gauges*. That is K1-type material, not a method failure, and it is unverified.

So the lineage-key truth is itself incomplete by a few percent. That caps any method's measurable precision, and it is a finding in its own right for the benchmark (K2).

## G3 — consequences: **K4 kept** (leakage passes, validation shift fails)

**Leakage** (10 splits, 5,341 affected basin-splits): **pass**.

| Scope | Affected share of test basins | Median NSE, copy predictor | Median NSE, nearest non-copy neighbour | Median gain |
|---|---:|---:|---:|---:|
| All known copy pairs (P1 + P2) | **12.3%** | 0.9999 | 0.456 | **+0.51** |
| GRDC-Caravan ↔ core only (P2) | 10.3% | 0.9999 | 0.426 | +0.55 |

Interpretation limits:
- The copy predictor is an *upper bound* on what leaked information is worth, not what a trained model would score. The optional LSTM run (P104, hidden=64, layers=2) is now unlocked by the frozen rule and would measure that.
- The 12.3% exceeds the 8.4% from G1 because P1 duplicates *inside* the Caravan core (HYSETS vs CAMELS-US, same USGS number) also count.

**Validation shift:** **fail**. 2,813 VS records on 433 gauges: median |ΔKGE| = 0.0005, and only 1.6% of gauges are above 0.05 (threshold 5%). This is consistent with G1: the archive's copies of GRDC/USGS data are faithful (P4 0.14%, P5 0.06%).

## Combined state of the route after G0–G3
| Claim | Status |
|---|---|
| K1 census | **Supported:** Brazil and LamaH chains diverge on 3–5% of days, broadly across gauges; USGS/GRDC archive chains are faithful |
| K2 benchmark | Strengthened: lineage keys are incomplete (sub-km unmatched copies, cross-gauge near-identical series), and this is measurable |
| K3 ID-free method | **Dropped** (G2); kept only as an evaluation of existing rules |
| K4 consequence | **Kept** through leakage (12% of test basins, +0.51 NSE upper bound); validation-shift part dropped |

Open: G4 needs a plan amendment, because the diverging chains are not USGS. Optional: an LSTM leakage run to replace the upper bound with a real model effect.

## Addendum (2026-10-19): optional LSTM leakage check, unlocked by G3 PASS
Protocol fixed in the `g3_lstm.py` header before training (raw: `out/g3_lstm/`).
- Test set: 200 GRDC-Caravan basins that have a core duplicate.
- Condition A: 1,000 shared clean basins + the 200 duplicates.
- Condition B: the same 1,000 + 200 other clean basins, all > 5 km from the test basins.
- Model: LSTM, hidden 64, 2 layers, on the P104; same period 1990–2009; 3 seeds per condition.

| | Median NSE on test basins |
|---|---:|
| A — duplicates in training (per seed .507 / .479 / .452) | **0.468** |
| B — no duplicates (per seed .305 / .305 / .305) | **0.288** |
| Paired ΔNSE (A − B) per basin, median [IQR] | **+0.102** [+0.034, +0.263] |
| Basins with ΔNSE > 0 | 86.5% (Wilcoxon p = 2e-25) |

- **Pre-set reading:** material inflation (median ΔNSE ≥ 0.05 and p < 0.01) → **yes**.
- The B seed medians coincide to three decimals, but the per-basin values differ (checked), so this is not a seed bug.
- A few test basins have extremely negative NSE (minimum −2,099), likely near-constant or ephemeral flow. That makes the mean meaningless (mean ΔNSE 5.4), and the reading therefore uses the median, as pre-set.
- **Limit:** the model is deliberately modest: climate attributes only, 15 short epochs, absolute NSE 0.29–0.47. A stronger model may show a different magnitude. The copy predictor (NSE 0.9999) remains the upper bound.
