# E4 fixed-test-set report (PLAN_E4_FIXEDTEST.md, frozen 2026-10-26, md5 b8103dd11aa16ccf8a3edc5ee6398b62)

Run 2026-10-26 with `e4_fixedtest.py`, outputs in `out/e4fixed/` (`nse.json`, `meta.json`, `summary.json`), log `out/e4fixed_run.log`.
W models reused from `out/e4splits/nse.json` (R1–R5) as the plan specifies; 10 new models (M1–M5, U1–U5).

## Matching
- Candidates outside the 3,060-basin pool, valid, single-member lineage class: 5,967 (then >5 km from every test basin, per seed).
- Leaking training basins removed per seed: 184, 175, 179, 206, 177.
- Cross-subset matches (no same-subset candidate left): 0, 1, 0, 7, 1 (9 in total).

## Outcomes (as frozen)
| | M (matched, primary) | U (random, sensitivity) |
|---|---|---|
| Primary 1: median Δ = NSE_W − NSE_M, affected records (888 records, 651 basins) | **+0.016** [95% CI +0.010, +0.021] | +0.019 [+0.013, +0.024] |
| Negative control: median Δ, unaffected records (2,172) | −0.002 | −0.007 |
| Primary 2: mean over seeds of per-seed median difference, all test basins | **+0.013** [95% t-interval −0.001, +0.026] | +0.013 [−0.008, +0.034] |
| per seed | +0.017, +0.027, −0.003, +0.012, +0.008 | +0.024, +0.029, −0.013, +0.020, +0.005 |

**Readout (frozen):** Primary 1: *no material per-basin leakage* (median below 0.05, although the CI excludes 0).
Primary 2: *no detectable pooled inflation* (interval includes 0).

## Interpretation (descriptive)
The copy-specific gain for this LSTM on a fixed test set is ~0.02 NSE per affected basin, which is far below the +0.10 of the
controlled-injection experiment (PLAN_G1_G4 / g3_lstm). The injection's control set B consisted of basins from other regions and
climates, so most of its gain appears to be the value of training on a similar basin, which a matched non-copy basin supplies almost
as well. The copy predictor (natural exposure) still shows that a leaked record is a near-perfect answer key; this model barely
uses it. Paper E4, abstract, intro and conclusion revised accordingly (draft v6, 2026-10-26).
