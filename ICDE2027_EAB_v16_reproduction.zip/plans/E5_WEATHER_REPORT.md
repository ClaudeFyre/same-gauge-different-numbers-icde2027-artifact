# E5 report — second lake, German weather stations (PLAN_E5_WEATHER.md, frozen 2026-11-06, md5 df8ab1bc1cdc822e92e46c3aa64f46ab)

Scripts: `e5_select.py` (metadata-only selection), `e5_remotezip.py`, `e5_fetch.py`, `e5_run.py`, `e5_summarise.py`.
Outputs: `out/e5/` (selection, fetch plan/log/summary, `e5_pairs.csv`, `e5_attrib.csv`, `e5_summary.csv`, `e5_verdicts.json`).
Data: `data/Expansion_2026-11-06/weather/{meta,series}`; 41.6 MB metadata + 350 MB series (cap reached).

## Deviations from the plan (recorded, not hidden)
- Download cap (350 MB) reached while reading blended RR: 456 of 457 blended RR files fetched; **blended TG not fetched**.
  Pairs involving blended TG are therefore absent; everything else is complete.
- Implementation choices fixed in the `e5_run.py` header before running (QC flags kept and reported, period 1951–2025,
  W1 attributed over divergent ∪ shift-explained days, placebo ±2/±3 d).

## Results (frozen readouts)
- **E1-W regime:** single faithful regime for key-linked pairs (max 0.65%) and for metadata-linked pairs (max 0.62%).
- GHCN-Daily (E-flag days) vs ECA&D non-blended (key-linked): **0 divergent and 0 shifted days on 7,794,941 days; values identical (max |Δ| = 0).**
- ECA&D non-blended vs DWD (metadata-linked): RR 0.20%, TX 0.001%, TN 0.002%, TG 0.001%.
- ECA&D blended vs non-blended / DWD: 0.32–0.65%.
- **E2-W:** blended chains EXPLAINED (blending W3 79–91% of attributed days); ECA&D/DWD and GHCN/DWD chains LOCALIZED to the
  DWD–ECA&D edge (RR: W1 shift 28%, specific vs placebo ≤ 5.0%; W4 72%); NB/DWD TG OPEN (39 days).
- Caveat: GHCN-Daily copies ECA&D, so W4's third copy is not independent; localisation to the edge does not tell which side changed.

## Descriptive (not covered by a frozen rule)
- Flat 2% relative tolerance on NB/DWD pairs: RR 0.34% vs 0.20% frozen; TX/TN essentially unchanged (same 0.1 °C grids).
