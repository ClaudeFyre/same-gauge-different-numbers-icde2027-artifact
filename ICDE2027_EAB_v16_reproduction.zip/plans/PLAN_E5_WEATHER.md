# PLAN_E5_WEATHER — second lake: German weather-station records (DRAFT, not frozen)

**Status.** Frozen 2026-11-06 after author approval ("执行所有"), after reading station metadata only and **before** any station
series was downloaded or read. md5 recorded in FROZEN_2026-11-06.md5. Sec. 10 lists what the metadata check changed in this draft.

## 1. Question
Do the E1/E2 findings hold in a second, independent time-series lake? Specifically:
- **Q1 (E1):** Do lineage-keyed copies of the same station series agree after the documented transformation, under the same
  rounding-aware tolerance logic, and do chains again split into faithful and diverging regimes?
- **Q2 (E2):** Where copies diverge, can the divergence be explained by a named transformation (day-boundary attribution,
  daily-mean formula, blending) or localised to one edge of the lineage graph?
- **Q3 (E3, optional, descriptive):** How do the identifier-free rules M0–M4 behave on this lake's keyed pairs?
E4 (model leakage) is not replicated; the paper says so.

## 2. Lake and lineage graph
- **Producer (root):** Deutscher Wetterdienst (DWD) Climate Data Center, daily station data `observations_germany/climate/daily/kl/historical`
  (versioned, quality-controlled; CC BY 4.0; anonymous). Variables used: TMK (daily mean T), TXK, TNK (°C, 0.1 °C), RSK (precipitation, mm, 0.1 mm).
- **Intermediate:** ECA&D **non-blended** series supplied by participant "National Climate Data Center (DWD)" (0.1 °C, 0.1 mm; free for
  non-commercial research and education; anonymous). Each series carries an element code that states its day definition
  (e.g. RR2 "morning previous day … until morning today (shifted 1 day back by ECA staff)").
- **Aggregated:** (a) ECA&D **blended** series (non-blended series gap-filled with GTS SYNOP and nearby stations ≤12.5 km, ≤25 m);
  (b) **GHCN-Daily** (NOAA NCEI; source flag `E` = ECA&D; also `S`/`2` = GTS-derived summaries; units 0.1 °C, 0.1 mm).
- Note two-way flow: ECA&D also lists GHCND and GSOD as participants. Edges are taken only from source flags and source tables,
  never inferred from values.

## 3. Copy pairs and station selection (metadata only)
- **Lineage keys:** (i) GHCN-Daily IDs with network code `E` embed the ECA&D non-blended identifier; (ii) `mingle-list.txt` lists, per
  GHCN station, each source code and source identifier; (iii) ECA&D blended source tables list the non-blended sources (SOUID) used.
- **DWD ↔ ECA&D link:** use a DWD station identifier if the ECA&D source tables carry one. If they do not, link by metadata
  (distance < 1 km, |Δ elevation| ≤ 10 m, normalised name match) and label these pairs **metadata-linked**; they are reported
  separately and never pooled with key-linked pairs in a pass condition.
- **Selection:** German stations (GHCN country `GM`) with (a) a GHCN-Daily series whose mingle list includes source `E`, (b) an ECA&D
  non-blended series from participant DWD for at least one of TG/TX/TN/RR, (c) a DWD kl historical series, and (d) at least 3,650
  overlapping days in 1951–2025. If more than 150 stations qualify, draw 150 with seed 0 (sorted by GHCN ID). Same set for all variables.

## 4. Definitions (adapted from Sec. III; frozen here)
- **Precipitation (ratio scale):** exactly as Sec. III: scale constant k = median(a/b) over days with b > 0 (≥ 365 days), scale-stable if
  IQR(a/(kb)) ≤ 0.01, τ = max(0.02|kb|, 2(h_a + k h_b)), divergent if |a − kb| > τ and not within τ of k b(t±1) (shift-explained counted separately).
- **Temperature (interval scale):** a ratio constant is meaningless for °C. Transformation family a = k b + c with k fixed by the
  documented units (k = 1 for °C vs °C, 0.1 for tenths); offset c = median(a − k b); a pair is offset-stable if |c| ≤ 0.05 °C and the IQR of
  (a − k b − c) ≤ 0.1 °C. Tolerance τ_T = 2(h_a + k h_b) (= 0.2 °C for two 0.1 °C grids); no relative floor. Divergent/shift rule as above.
- Quantisation step q(x) estimated as in Sec. III; reported per repository as in the q-step check.

## 5. Outcomes and pre-set readings
- **E1-W (primary):** divergence rate per repository pair and variable, pooled over stable pairs; share of stations above 1%;
  top-10% concentration; shift-explained share. Reading: a pair/variable is *diverging* if its rate ≥ 1% with ≥ 20 compared pairs,
  *faithful* otherwise. The replication **supports two regimes** if at least one pair/variable is faithful (< 0.5%) and at least one is diverging.
  If all are faithful, we report "single faithful regime"; if all diverge, "no faithful chain". All outcomes are reported.
- **Bounds:** as Table IV: all pairs, unstable pairs bounded low/high.

## 6. Attribution tests for divergent days (E2-W), applied in this order; first applicable test assigns the cause
- **W1 day attribution:** the copy equals the root on day t−1 or t+1 within τ (already counted as shift-explained by E1-W; reported here as a cause).
- **W2 daily-mean formula (TG only):** the copy equals (TX+TN)/2 of the root within τ_T while the root's TMK differs (copy uses a max/min mean),
  or vice versa; also tested separately before and after 2001-04-01 (DWD's documented change of TMK computation).
- **W3 blending (blended series only):** the day lies in a segment that the blended source table assigns to a non-DWD source (SYNOP or neighbour).
- **W4 edge localisation:** with three copies (DWD, ECA&D non-blended, GHCN), the divergence is placed on the edge whose two ends disagree
  while the third copy agrees with one of them (as L4/B5).
- Otherwise **unresolved**.
- Chain verdict as Sec. VI: EXPLAINED if named transformations (W1–W3) ≥ 50% of divergent days; LOCALIZED if W1–W4 together ≥ 50%; OPEN otherwise.
- Placebo for W1: the same test with shifts of ±2 and ±3 days; W1 is called specific only if it exceeds every placebo by ≥ 10 percentage points.

## 7. Optional E3-W (descriptive)
M0 uses coordinates within 1 km and elevation within ±10 m instead of drainage area; M1–M4 unchanged; positives = key-linked pairs;
negatives = all cross-repository pairs of different stations within 50 km with Pearson ≥ 0.9 (hard) plus 100× random (seed 0). No pass rule.

## 8. Data volume and approval (metered connection)
- Step A, metadata (≈ 40 MB): `ghcnd-stations.txt` 11.4 MB, `mingle-list.txt` 4.7 MB, ECA&D non-blended info and blended source tables for
  TG/TX/TN/RR (≈ 1.7–3.3 MB each, ≈ 20 MB), DWD `KL_Tageswerte_Beschreibung_Stationen.txt` 1.4 MB. Needs no approval under the 100 MB rule but is reported.
- Step B, series for ≤ 150 stations (≈ 250–350 MB, **needs approval**): GHCN-Daily `by_station/*.csv.gz` (≈ 0.85 MB each, ≈ 130 MB);
  DWD kl historical zips (≈ 0.5–1 MB each, ≈ 100 MB); ECA&D station files read out of `ECA_{non}blend_{tg,tx,tn,rr}.zip` (0.7–1.4 GB each on S3)
  by HTTP range requests on the zip central directory, so only the selected members are transferred (estimate 60–120 MB).
- Nothing is redistributed: the artifact ships station identifiers, derived labels and fetch scripts (ECA&D is non-commercial only).

## 9. Paper integration (after results)
New Sec. "E5: A second lake" (≈ 0.8 page: one table side by side with Table II, one paragraph per question), and one sentence each in
abstract, introduction and discussion. Space is recovered by condensing Tables VII and IX into text, shortening Table IV and the related work.

## 10. Pre-freeze changes from the metadata check (metadata only; no observations read)
`out/e5/selection.csv/json` (script `e5_select.py`) and `out/e5/eca_zip_dirs.json`:
- **Keys.** ECA&D source tables carry no DWD station number, and GHCN's `I 617…` source entries exist for only 19 German stations and do
  not match DWD numbers. Hence **all pairs with the DWD root are metadata-linked** (Sec. 3 fallback: < 1 km, |Δz| ≤ 10 m; observed
  median 0.145 km, max 0.958 km). Key-linked pairs are GHCN-Daily ↔ ECA&D non-blended (mingle list, source `E`, per element; exist for
  RR, TX, TN, not for the daily mean) and ECA&D blended ↔ non-blended (blended source table, STAID → SOUID with periods).
- **Readings by link type.** The E1-W regime reading (Sec. 5) is evaluated separately for key-linked and for metadata-linked pairs.
- **GHCN source days.** GHCN-Daily ↔ ECA&D comparisons use only GHCN days whose source flag is `E`; the share of other flags is reported.
- **Daily mean.** TG is compared DWD (TMK) ↔ ECA&D non-blended TG ↔ ECA&D blended TG only (GHCN has no ECA&D TAVG link).
- **Selection (d).** Values cannot be read before freezing, so (d) is applied in two stages: pre-selection on metadata periods
  (≥ 10 years of common period within 1951–2025 for GHCN, ECA&D and DWD), then per pair the Sec. III rule of ≥ 365 compared days.
  776 stations qualify; 150 drawn with seed 0 (picked list in `selection.json`). All 150 carry ECA&D element codes RR3 (precipitation
  "morning today 06/07/08 until morning next day"), TX3 and TN3 ("0-0 UT").
- **Volume.** ECA&D central directories 8.5 MB (read); members 54–105 KB median; estimated series download ≈ 300–330 MB in total.
