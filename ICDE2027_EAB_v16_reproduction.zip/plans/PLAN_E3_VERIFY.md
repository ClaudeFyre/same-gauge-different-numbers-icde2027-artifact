# PLAN_E3_VERIFY — verifying the E3 negatives that rules call copies (frozen 2026-10-20, before any verification evidence is read)

**Purpose.** E3 found that no rule reaches precision 0.99, but some "false positives" may be unlabelled true copies. This plan
re-labels the questionable negatives with explicit evidence and reports precision as a **conservative interval** under incomplete truth.
It does not change the frozen G2 verdict; it adds a bounded re-evaluation.

## 1. Scope (fixed)
All negative pairs in `labels/discovery_pairs.csv` (unperturbed rows) that are **flagged** (sub-km or near-identical) **or** called a copy by
**any** of M0–M4. Count fixed at freezing time: **581 pairs** (296 flagged, 533 any-rule FP; US 322, EU 191, AU 35, BR 33).
"Copy" means: **the two series are records of the same physical gauging station** (same measurement site). Distinct stations with
near-identical records (e.g. derived or transferred records) are **not** copies under this definition.

## 2. Evidence (metadata only; no discharge values are used, so the label cannot be circular with M1/M4)
For each pair, collect per side: station name, river name (if any), coordinates, drainage area, identifier and issuing agency.
- Local attribute files: Caravan (names, area), GRDC-Caravan (names, area, `nat_id`), LamaH-CE (`govnr`, name, river, area).
- USGS site metadata from the anonymous NWIS site service (`waterservices.usgs.gov/nwis/site/`, rdb, batched, < 5 MB total):
  station name, coordinates, drainage area, for every USGS identifier in scope.
- No other downloads. GRDC stations without a local name stay without a name.

## 3. Decision rules (applied mechanically, in this order; first match wins)
Notation: d = distance (km); A = drainage-area ratio max/min (when both known); N = name match, defined as: after lower-casing,
removing punctuation, agency boilerplate (`river`, `at`, `near`, `nr`, `bei`, `rio`, `ribeirao`, `creek`, `ck`, `r.`), and
state/country suffixes, the token sets share ≥ 50% of the smaller set, or one normalised name contains the other.
- **R1 Confirmed copy (same identifier after documented normalisation):** the two identifiers denote the same national station after a
  format transformation documented by a publisher (e.g. GRDC `nat_id` with a leading-zero/check-digit/suffix variant matching the
  national code), AND d < 1 km.
- **R2 Confirmed copy (same site):** d < 1 km AND N AND (A ≤ 1.05 or area unknown on a side).
- **R3 Confirmed non-copy (different site):** (A > 1.10) OR (d ≥ 5 km AND not N) OR (both identifiers are distinct, currently listed USGS
  sites whose NWIS names differ, i.e. not N).
- **R4 Unresolved:** everything else (including pairs where one side has neither name nor area).
Each decision is written with the rule that fired and the evidence values to `out/e3verify/verify_pairs.csv`.
Who: the rules are applied by script; no case-by-case judgement. Afterwards the authors are asked to spot-check a random sample
of 30 decisions (seed 0) from each of R1/R2, R3 and R4; disagreements are reported, not silently fixed.

## 4. Outputs and readout (fixed)
For each class (c1–c5) and rule (M0–M4), recompute precision and recall after relabelling **confirmed copies** as positives, under:
- **Lower bound:** unresolved pairs remain negatives.
- **Upper bound:** unresolved pairs are treated as copies (positives).
Report: counts per R1–R4, precision/recall intervals per rule and class, and whether any rule reaches precision ≥ 0.99 at either bound.
Verdict wording (fixed):
- If no rule reaches 0.99 even at the upper bound → "the precision gap is robust to label incompleteness".
- If some rule reaches 0.99 only at the upper bound → "the gap may be an artefact of label incompleteness; truth-dependent".
- If some rule reaches 0.99 at the lower bound → "the original E3 conclusion does not hold for that rule/class" (reported as such).
The 0.99 threshold is the pre-registered application target of G2, stated as such in the paper; it is not claimed as a universal standard.
