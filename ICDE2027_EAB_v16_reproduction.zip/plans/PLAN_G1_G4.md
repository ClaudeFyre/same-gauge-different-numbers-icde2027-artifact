# PLAN_G1_G4 — frozen rules for the republication route (2026-10-18, before any G1 data are read)

Context: G0 passed with all claims NARROWED (`G0_REPORT.md`). The centre is now K1 (how faithful republished copies are to the source). K4 (leakage) supports it, and K3 (ID-free discovery) is conditional on G2.
General rules, carried over from the earlier PLAN files: thresholds below are fixed. No re-tuning after results are seen. A failed gate is reported as failed, not rescued with new experiments. Exploratory results are labelled as exploratory.
**Pilot exclusion:** the VT/NH pair (GlobalRiverWSE-USGS vs NWIS) has already been looked at (`pilot*.py`). It is reported as exploratory and **does not count towards any pass condition**.

## Shared definitions
- **Copy pair:** two series in different repositories that share a lineage key. Allowed keys: identical USGS site number; GRDC number; GRDC-Caravan `nat_id` ↔ source national ID; LamaH ID. Keys are used only as truth, never as method input in G2.
- **Overlap:** days where both series are finite. A pair needs ≥ 365 overlap days.
- **Scale alignment:** k = median(a/b) over overlap days with b > 0, which absorbs units and area normalisation. A pair is "scale-stable" if IQR(a/(k·b)) ≤ 0.01. Unstable pairs are reported separately as "non-constant transformation" and not counted as divergent days.
- **Rounding tolerance:** τ_t = max(0.02·|k·b_t|, 2·(h_a + k·h_b)), where h is half of the quantization step inferred per series as the smallest positive difference among the distinct values (the same estimator as the old probe).
- **Divergent day:** |a_t − k·b_t| > τ_t. **Shift-explained:** divergent, but matches b at t±1 within τ.
- **Pair divergence rate:** divergent days that are not shift-explained / overlap days, pooled over all gauges in the repository pair.

## G1 — prevalence (local data only; extraction allowed, no download)
Repository pairs that count (pre-listed; a pair with < 20 copy pairs is reported but does not count):
1. Caravan `camels_` (CAMELS-US) vs Caravan `hysets_`, same USGS number
2. Caravan core vs GRDC-Caravan, via `nat_id` (CAMELS-US, HYSETS, CAMELS-BR, CAMELS-AUS, LamaH-CE subsets kept separate)
3. Caravan `lamah_` vs standalone LamaH-CE daily (`icde_probe/raw/lamah`)
4. GlobalRiverWSE GRDC vs GRDC-Caravan, same GRDC number
5. GlobalRiverWSE USGS vs Caravan `camels_`/`hysets_`, outside VT/NH
6. Caravan-DE vs CausalRivers (daily mean of the 15-min data), only if a lineage key exists. Otherwise skipped (no geographic matching in G1).

**Pass:** at least 2 counting pairs with a divergence rate ≥ 1.0%, **or** a duplicate share ≥ 2% of basins when Caravan core and GRDC-Caravan are combined without `nat_id` deduplication.
**Kill:** every counting pair < 0.2% and the duplicate share < 2%. Between these bounds the result is "weak". Continue only to G3, as a leakage-only paper.
Also report: the share of scale-unstable pairs, the shift-explained share, divergence by year, and divergence for flagged vs unflagged values where flags exist.

## G2 — ID-free discovery (only if G1 passes or is weak)
Setup per region (US, central Europe, Brazil, Australia). Positives = G1 copy pairs. Hard negatives = pairs < 50 km apart with Pearson r ≥ 0.9 on overlap and different lineage keys, plus LamaH NEXTDOWNID neighbours. Easy negatives are sampled up to 100× the positives.
Methods (all fixed now):
- M0 coordinates ≤ 1 km and drainage-area ratio within ±10%
- M1 R² > 0.99 on overlap (GSIM time-series rule)
- **M2 GSIM full rule:** metadata similarity < 0.25, then the R² rule; the 0.90–0.99 band counts as "identical" (no visual step)
- M3 exact hash after scale alignment and rounding to the coarser grid
- M4 quantization-floor test from the old probe, ≥ 0.9 of days within τ

Transformation classes: unit/area scaling only; plus rounding coarser than the source; partial overlap < 50% of the shorter series; series with a G1 divergence rate ≥ 5%; metadata degraded (names removed, coordinates jittered by 0–5 km, which reproduces the CausalRivers-type errors).
**Pass (method contribution kept):** in at least one class, the best of M0–M2 reaches recall < 0.90 at precision ≥ 0.99, **and** M3 or M4 improves recall by ≥ 0.10 at the same precision.
**Otherwise:** drop the method contribution and keep G2 only as a measurement of existing methods.

## G3 — consequences
- **Leakage:** combine Caravan core and GRDC-Caravan without deduplication; 10 random 80/20 basin splits (seeds 0–9, fixed). For test basins with a duplicate in train, compare the *copy predictor* (the train duplicate × k) against the *nearest non-duplicate neighbour* predictor (the closest train basin that is not a copy pair, area-scaled). The test period is the last 20% of the overlap.
  **Pass:** median NSE gain ≥ 0.10 **and** affected test basins ≥ 2%. The LSTM run (P104, hidden=64, layers=2) is optional and only runs if this passes.
- **Validation shift:** for GlobalRiverWSE validation pairs whose gauge is a G1 copy pair with a re-fetchable source, compute KGE of the archive's own altimetry–gauge relation against the archive Q and against the source Q.
  **Pass:** ≥ 5% of those gauges change KGE by > 0.05.
- **Kill rule:** both fail → drop K4 from the paper.

## G4 — attribution of causes (VT/NH first, then G1 divergent pairs with a USGS source)
Download: NWIS instantaneous values for the 20 most divergent USGS gauges, period 2016-10 to 2023-12. Report the size first if it exceeds 100 MB.
Cause tests, applied in order; each divergent day gets the first cause that explains it within τ:
1. Unit/rounding (already in τ, so excluded by construction)
2. ±1 day shift
3. Day boundary: the daily mean from IV in UTC instead of local standard time
4. Aggregation: daily value = IV mean vs mean of hourly samples vs noon sample
5. Missing-day fill in the copy (the copy is finite where the source is missing or flagged)

Anything left over is labelled **"unattributed (consistent with post-publication revision, not verifiable without vintages)"**. A revision is never claimed as verified.
**Pass:** ≥ 50% of divergent days attributed to causes 2–5. **Otherwise** report divergence as unexplained, and the paper's claim stays at "measured, not explained".

## Execution order and artefacts
G1 → (G2 ∥ G3) → G4. Each gate writes `G*_REPORT.md` with raw outputs in `republish_pilot/out/`. Scripts are run with `python -I`, fixed seeds, and no Auto-Relate code.
Disk: extracting Caravan (24.8 GB gz) and the GRDC-Caravan CSV zip (8.8 GB) is allowed, with 387 GB free. Only the streamflow variable and attributes are extracted where possible.
