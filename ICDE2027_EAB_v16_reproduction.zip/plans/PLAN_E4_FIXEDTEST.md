# PLAN_E4_FIXEDTEST — leakage on a fixed test set with matched controls (frozen 2026-10-26 after user approval, before any model is trained)

**Purpose.** Address two review points on E4: (1) the controlled injection compared training sets that differed in more than
the copies (geography, climate, difficulty); (2) the random-vs-lineage comparison used different test sets. Here the **test set is
fixed** and only the training side changes: the copies of test basins are removed and replaced by **matched** non-copy basins.

## 1. Pool and splits (identical to PLAN_E4_SPLITS, reused)
- Same valid-basin list (`out/e4splits/valid.json`), same lineage classes, same 2,500 sampled classes (seed 0) → 3,060 basins.
- Same random 80/20 basin splits, seeds 1–5 → for each seed the same R_train / R_test (612 test basins; 167–196 with a copy in R_train).

## 2. Training conditions per seed (same LSTM, hyper-parameters and training code as E4)
- **W (with copies):** train on R_train. This is exactly model R{seed} of PLAN_E4_SPLITS; its per-basin NSE on R_test is **reused**
  from `out/e4splits/nse.json` (same code, data and seed), not retrained.
- **M (matched controls):** R_train minus every basin that shares a lineage class with any R_test basin ("leaking copies"), plus the
  same number of **replacement** basins, each matched to one removed copy by nearest neighbour (without replacement) in the
  standardised space of the 14 Caravan climate attributes + log drainage area, restricted to the same source subset (Caravan subset
  or GRDC-Caravan) and to replacement candidates that are (a) valid, (b) outside the 3,060-basin pool, (c) in a single-member lineage
  class, and (d) more than 5 km from every R_test basin.
- **U (unmatched controls, sensitivity):** as M, but replacements drawn uniformly at random from the same candidate set (seed = split seed).
Training seed for M and U = split seed (as for W). New models: 10 (M and U × 5 seeds).

## 3. Outcomes (fixed)
On the fixed R_test of each seed, per-basin NSE (1991–2009 days with observations) for W, M, U.
- **Primary 1 — per-basin leakage on a fixed test set:** for test basins with a copy in R_train, Δ_i = NSE_W − NSE_M; report the
  median over all (basin, seed) records with a 95% bootstrap CI resampling basins (10,000 draws, seed 0).
- **Primary 2 — pooled inflation on a fixed test set:** per seed, median NSE_W over all R_test basins − median NSE_M over the same
  basins; mean over 5 seeds with a 95% t-interval (4 d.f.).
- **Negative control:** the same Δ_i for test basins **without** a copy in R_train (expected ≈ 0).
- **Sensitivity:** Primaries 1 and 2 recomputed with U instead of M.
- **Readout (fixed):** Primary 1 shows "material per-basin leakage" if the median ≥ 0.05 and its CI excludes 0; Primary 2 shows
  "detectable pooled inflation" if its interval lies above 0. All outcomes are reported regardless of direction; thresholds are not
  changed afterwards. If matching fails for a removed copy (no candidate in the same subset), it is matched across subsets and the
  number of such cases is reported.

## 4. Cost
~10 models × ~5 min on the P104 plus loading of the replacement candidates (~15 min). No downloads.
