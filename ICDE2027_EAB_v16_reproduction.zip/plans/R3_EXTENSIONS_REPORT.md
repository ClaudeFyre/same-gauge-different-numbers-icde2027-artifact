# Report — PLAN_R3_EXTENSIONS.md (frozen 2026-11-07, md5 63d9801399f66d0ad65c849b73b99085)

All four parts ran as frozen; results reported whatever their direction. Outputs: out/x1, out/e4extremes, out/x3, out/x4.

| Part | Frozen reading | Key numbers |
|---|---|---|
| X1 learned matcher (x1_features.py, x1_learned.py) | **passes** (c1, c5; also under verified upper bound) | c1 precision 0.993 recall 0.23 (6 FP, all verified copies); c5 0.995 / 0.25; c2/c3 recall 0.04/0.05; c4 0. Threshold landed at score 1.0 in every LORO fold. Rule features reproduce shipped M0–M4 decisions on all 1.32 M rows. |
| X2 extremes (e4_extremes.py, x2_eval.py) | FHV **not material**; AMAX **not material** | all 15 retrained models NSE-identical to stored; Δ|FHV| median +1.3 pp [0.1, 2.3] (neg. control +0.9); Δ AMAX +0.017 [0.008, 0.026]; pooled +2.0 pp [−2.2, 6.1]; median |FHV| ≈ 42% |
| X3-V1 ANA insertion dates | **uninformative** | divergent months re-inserted after 2020: 17% vs 36% control; 16 vs 53 stations, p = 9e-6 (opposite direction) |
| X3-V2 CAMELS-BR v1.2 | **dated revision evidence** | 30,265 edge-divergent days: v1.2 agrees with ANA 99.2% vs v1.1 0.4%; control 99.1% (v1.1 87.2%) |
| X3-V3 DWD logs | descriptive | historical daily kl archive re-published 2015, 2016, 2018, 2019, 2021 (product level only) |
| X4 synthetic lineage (x4_synth.py) | **not validated** (localisation, naming precision) | 197 chains; false divergence 0.0014%; localisation 71%; naming precision 65%. Descriptive diagnostic (same seeds, decisions identical): localisation 99% when all benign edges stable (77 chains) vs 41% otherwise (73); 45% of benign-only chains have an unstable edge. |

Notes: the X2 run was interrupted by a machine restart after 12/15 models and resumed for seed 5 (script skips finished models); log of the first part in out/e4extremes/run_part1.log.
