# PLAN_E4_SPLITS — random vs lineage-aware basin splits (frozen 2026-10-20, before any model is trained)

**Purpose.** Separate the two E4 scenarios. The controlled injection experiment measured the gain on basins whose copies are in
training. This experiment estimates the **overall** score inflation that an ordinary random basin split produces on the combined
Caravan + GRDC-Caravan pool, compared with a split that keeps all copies of a gauge on one side.

## 1. Pool (fixed)
- Basins of Caravan v1.6 core and GRDC-Caravan with ≥ 3,650 finite streamflow days and complete forcing in 1990–2009.
- **Lineage classes:** connected components of the G1 copy-pair keys P1 and P2 (a basin without a copy is its own class).
- To keep training cost fixed while preserving the natural duplicate rate, sample **2,500 lineage classes** uniformly at random
  (seed 0) and include **all** member basins of each sampled class.

## 2. Splits (fixed; 5 repetitions, seeds 1–5)
- **R (random basin split):** 80/20 split over basins, ignoring lineage.
- **L (lineage-aware split):** 80/20 split over lineage classes; all members of a class fall on the same side.
For each seed, R and L are drawn independently from the same pool.

## 3. Model and training (identical to the E4 injection experiment, unchanged)
LSTM, hidden 64, 2 layers, dropout 0.4, 10 ERA5-Land forcings + 14 Caravan climate attributes, window 365, Adam 1e-3,
15 epochs × 800 batches × 256, NSE* loss, inputs standardised on the training split; training and testing on 1990–2009
(spatial generalisation). One model per split and seed → **10 models**. GPU: local P104 (< 1 GB used).

## 4. Evaluation and readout (fixed)
- NSE per test basin (1991–2009 days with observations).
- Per seed: Δ_s = median NSE over all test basins under R − median NSE over all test basins under L.
- **Primary estimate:** mean of Δ_s over the 5 seeds with a 95% t-interval (4 d.f.).
- **Secondary (descriptive):** under R, the median NSE of test basins **with** a copy in training vs **without**; the share of
  R test basins with a copy in training.
- **Readout (fixed):** "random splits inflate the overall median NSE" if the 95% interval of the primary estimate lies above 0;
  "no detectable overall inflation" if it contains 0. Either outcome is reported; the threshold is not adjusted afterwards.
- Expected runtime: ~1.5–2 h (data loading ~20 min, 10 × ~6 min training + evaluation).
