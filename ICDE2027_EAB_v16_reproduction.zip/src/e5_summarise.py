"""E5 verdicts per PLAN_E5_WEATHER.md (Sec. 5, 6, 10) from out/e5/e5_summary.csv and e5_attrib.csv, plus one DESCRIPTIVE
sensitivity (not covered by a frozen rule): divergence rates under (a) a flat 2% relative tolerance without the rounding term,
and (b) the ratio-scale definition of Sec. III applied to temperature, on the same stable pairs."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import json, sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
import e5_run as R
OUT = R.OUT
S = pd.read_csv(OUT / 'e5_summary.csv'); A = pd.read_csv(OUT / 'e5_attrib.csv')
res = {}
for lk in ['key', 'meta']:
    s = S[(S.link == lk) & (S.pairs >= 20)]
    faithful = s[s.rate < 0.005]; diverging = s[s.rate >= 0.01]
    res[f'regime_{lk}'] = ('two regimes' if len(faithful) and len(diverging) else
                           'single faithful regime' if not len(diverging) else 'no faithful chain')
    res[f'max_rate_{lk}'] = float(s.rate.max())
real = A[~A.cause.str.startswith('placebo')]; pl = A[A.cause.str.startswith('placebo')]
verd = {}
for (a, b, el), x in real.groupby(['a', 'b', 'el']):
    tot = x.days.sum(); c = x.groupby('cause').days.sum() / tot
    named = sum(v for k, v in c.items() if k.startswith(('W1', 'W2', 'W3'))); loc = named + sum(v for k, v in c.items() if k.startswith('W4'))
    p = pl[(pl.a == a) & (pl.b == b) & (pl.el == el)].groupby('cause').days.sum() / tot
    w1 = float(c.get('W1 shift', 0)); w1_specific = bool(len(p) and w1 >= p.max() + 0.10)
    verd[f'{a}/{b}/{el}'] = dict(days=int(tot), verdict='EXPLAINED' if named >= 0.5 else 'LOCALIZED' if loc >= 0.5 else 'OPEN',
                                 shares={k: round(float(v), 4) for k, v in c.items()}, placebo_max=float(p.max()) if len(p) else None,
                                 w1_specific=w1_specific)
res['attribution'] = verd
# ---- descriptive sensitivity on NB/DWD and BL/NB pairs
plan = json.load(open(OUT / 'fetch_plan.json')); sel = pd.read_csv(OUT / 'selection.csv'); sel = sel[sel.ghcn.isin(plan['ghcn'])]
dwdfiles = {p.name.split('_')[2]: p for p in (R.D / 'dwd').glob('*.zip')}
cnt = {}
for g in plan['ghcn']:
    s = sel[sel.ghcn == g]; W = R.load_dwd(dwdfiles[str(int(s[s.el == 'TX'].dwd.iloc[0])).zfill(5)])
    for el in ['RR', 'TX', 'TN']:
        N = R.load_eca(R.D / 'eca_nonblend' / f"{el}_SOUID{int(s[s.el == el].souid.iloc[0])}.txt")['v']; b = W[el]
        m = np.isfinite(N) & np.isfinite(b)
        if m.sum() < 365: continue
        r = R.compare(N, b, el)
        if not r.get('stable'): continue
        a_, b_ = N[m], b[m]
        flat = np.abs(a_ - b_) > 0.02 * np.abs(b_)
        cnt.setdefault(el, dict(n=0, frozen=0, flat2=0))
        cnt[el]['n'] += int(m.sum()); cnt[el]['frozen'] += r['n_div']; cnt[el]['flat2'] += int(flat.sum())
res['sensitivity_NB_DWD'] = {el: dict(days=v['n'], frozen_rate=v['frozen'] / v['n'], flat2_rate=v['flat2'] / v['n']) for el, v in cnt.items()}
json.dump(res, open(OUT / 'e5_verdicts.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
