"""Worker for e4_splits.py: load forcing + streamflow for one basin on the 1990-2009 grid (Caravan netCDF or GRDC-Caravan csv)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import zipfile
from pathlib import Path
import numpy as np, pandas as pd, netCDF4

CAR = ROOT / 'data/Caravan/extracted/Caravan-nc'
GZP = ROOT / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip'
FORC = ['total_precipitation_sum', 'temperature_2m_mean', 'temperature_2m_min', 'temperature_2m_max',
        'potential_evaporation_sum_FAO_PENMAN_MONTEITH', 'surface_net_solar_radiation_mean', 'surface_net_thermal_radiation_mean',
        'dewpoint_temperature_2m_mean', 'snow_depth_water_equivalent_mean', 'surface_pressure_mean']
DAYS = pd.date_range('1990-01-01', '2009-12-31')
_gz = None
def load(gid):
    global _gz
    try:
        if gid.startswith('GRDC_'):
            if _gz is None: _gz = zipfile.ZipFile(GZP)
            d = pd.read_csv(_gz.open(f'GRDC_Caravan_extension_csv/timeseries/csv/grdc/{gid}.csv'), usecols=['date'] + FORC + ['streamflow'], parse_dates=['date'])
            df = d.set_index('date').reindex(DAYS)
        else:
            s = gid.split('_')[0]
            with netCDF4.Dataset(CAR / 'timeseries/netcdf' / s / f'{gid}.nc') as d:
                t = pd.to_datetime(netCDF4.num2date(d['date'][:], d['date'].units, only_use_cftime_datetimes=False, only_use_python_datetimes=True))
                df = pd.DataFrame({v: np.ma.filled(d[v][:].astype(float), np.nan) for v in FORC + ['streamflow']}, index=t).reindex(DAYS)
        X = df[FORC].values.astype(np.float32); y = df.streamflow.values.astype(np.float32)
        return gid, X, y
    except Exception:
        return gid, None, None
def validity(gid):
    g, X, y = load(gid)
    if X is None: return gid, False
    return gid, bool(np.isfinite(y).sum() >= 3650 and np.isfinite(X).all())
