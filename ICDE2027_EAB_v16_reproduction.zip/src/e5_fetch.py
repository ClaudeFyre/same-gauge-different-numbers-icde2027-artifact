"""E5 series download for the 150 selected stations (PLAN_E5_WEATHER.md, frozen 2026-11-06, md5 df8ab1bc...).
GHCN-Daily by_station csv.gz; DWD kl historical zips; ECA&D non-blended and blended station files read out of the
Europe-wide zips by HTTP range requests. Hard cap 350 MB (as reported to the user); stops before exceeding it."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import sys, json, re, time, urllib.request
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
from e5_remotezip import open_remote
from e5_select import eca_info, dwd_kl, km, M
import numpy as np
D = (ROOT / 'data/Expansion_2026-11-06/weather/series')
OUT = (ART / 'out/e5')
CAP = 350e6
total = 0
def get(url, dest):
    global total
    if dest.exists() and dest.stat().st_size > 0: return dest.stat().st_size
    b = urllib.request.urlopen(url, timeout=180).read()
    if total + len(b) > CAP: sys.exit(f'STOP: cap reached at {total/1e6:.1f} MB')
    dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(b); total += len(b); return len(b)

if __name__ == '__main__':
    sel = pd.read_csv(OUT / 'selection.csv'); picked = json.load(open(OUT / 'selection.json'))['picked']
    sel = sel[sel.ghcn.isin(picked)]
    # TG source per station: DWD-participant TG series metadata-linked to the same DWD station as the station's TX link
    tg = eca_info('tg'); tg = tg[tg.parid == 11]; dwd = dwd_kl()
    st_dwd = sel[sel.el == 'TX'].set_index('ghcn').dwd.astype(int).astype(str).str.zfill(5).to_dict()
    tgmap = {}
    for g, d in st_dwd.items():
        r = dwd[dwd.dwd == d].iloc[0]; dist = km(r.lat, r.lon, tg.lat.values, tg.lon.values)
        ok = (dist < 1.0) & (np.abs(tg.z.values - r.z) <= 10)
        if ok.any(): tgmap[g] = int(tg.souid.values[np.argmin(np.where(ok, dist, 1e9))])
    # blended STAIDs that use the selected sources
    want = {('tx', s) for s in sel[sel.el == 'TX'].souid} | {('tn', s) for s in sel[sel.el == 'TN'].souid} | \
           {('rr', s) for s in sel[sel.el == 'RR'].souid} | {('tg', s) for s in tgmap.values()}
    staid = {}
    for el in ['tx', 'tn', 'rr', 'tg']:
        for l in open(M / f'ECA_blend_source_{el}.txt', encoding='latin1'):
            p = l.split(',')
            if len(p) > 10 and p[0].strip().isdigit() and p[1].strip().isdigit() and (el, int(p[1])) in want:
                staid.setdefault(el, set()).add(int(p[0]))
    plan = dict(ghcn=picked, dwd=sorted(set(st_dwd.values())), tg=tgmap, staid={k: sorted(v) for k, v in staid.items()})
    json.dump(plan, open(OUT / 'fetch_plan.json', 'w'), indent=1)
    log = open(OUT / 'fetch_log.txt', 'a')
    t0 = time.time()
    for i, g in enumerate(picked):
        n = get(f'https://www.ncei.noaa.gov/pub/data/ghcn/daily/by_station/{g}.csv.gz', D / 'ghcn' / f'{g}.csv.gz')
    print('ghcn done', round(total / 1e6, 1), 'MB', round(time.time() - t0), 's', flush=True)
    listing = urllib.request.urlopen('https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/daily/kl/historical/', timeout=120).read().decode('latin1')
    total += len(listing)
    files = dict((m.group(1), m.group(0)) for m in re.finditer(r'tageswerte_KL_(\d{5})_\d{8}_\d{8}_hist\.zip', listing))
    miss = [d for d in plan['dwd'] if d not in files]
    for d in plan['dwd']:
        if d in files: get('https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/daily/kl/historical/' + files[d], D / 'dwd' / files[d])
    print('dwd done', round(total / 1e6, 1), 'MB; missing', miss, flush=True)
    for kind in ['nonblend', 'blend']:
        for el in ['tx', 'tn', 'rr', 'tg']:
            if kind == 'nonblend':
                ids = sorted(sel[sel.el == el.upper()].souid) if el != 'tg' else sorted(set(tgmap.values()))
                names = [f'{el.upper()}_SOUID{s}.txt' for s in ids]
            else:
                names = [f'{el.upper()}_STAID{s:06d}.txt' for s in plan['staid'].get(el, [])]
            z, f = open_remote(f'https://knmi-ecad-assets-prd.s3.amazonaws.com/download/ECA_{kind}_{el}.zip')
            have = set(z.namelist()); dest = D / f'eca_{kind}'; dest.mkdir(parents=True, exist_ok=True)
            for nm in names:
                if nm not in have: log.write(f'missing {kind} {nm}\n'); continue
                if (dest / nm).exists(): continue
                b = z.read(nm)
                if total + f.bytes > CAP: sys.exit(f'STOP: cap reached at {(total + f.bytes)/1e6:.1f} MB')
                (dest / nm).write_bytes(b)
            total += f.bytes
            print(kind, el, len(names), 'files', round(total / 1e6, 1), 'MB', round(time.time() - t0), 's', flush=True)
    json.dump(dict(total_bytes=total, seconds=round(time.time() - t0), dwd_missing=miss), open(OUT / 'fetch_summary.json', 'w'), indent=1)
    print('TOTAL', round(total / 1e6, 1), 'MB')
