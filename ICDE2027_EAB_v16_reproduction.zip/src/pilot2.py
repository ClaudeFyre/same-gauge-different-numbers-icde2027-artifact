import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, zipfile, numpy as np, pandas as pd
from _stream import stream_array
v = pd.read_parquet(ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet'); v['date']=pd.to_datetime(v['date'])
sites=set(v.site.astype(str))
z = zipfile.ZipFile(ROOT / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip')
allj=[]
for r in stream_array(z.open('Result datasets/Validation dataset/globe_gauge_discharge_data_8y.json')):
    if str(r['agency'])!='USGS' or str(r['id']) not in sites: continue
    g=pd.Series(np.asarray(r['discharge'],float),index=pd.to_datetime(r['time']))
    n=v[v.site==str(r['id'])].set_index('date')
    j=pd.concat([g.rename('g'),n.Q.rename('q'),n.cd.rename('cd')],axis=1).dropna(subset=['g','q']); j=j[j.q>0]
    j['back']=j.g/0.0283168466; j['site']=r['id']
    for L in (-1,1):
        j[f'lag{L}']=(np.abs(j.g/0.0283168466-n.Q.shift(L).reindex(j.index))<=0.02*j.q)
    allj.append(j)
J=pd.concat(allj); J['rel']=np.abs(J.back-J.q)/J.q; J['mis']=J.rel>0.02
print('values',len(J),'mismatch>2%',J.mis.mean().round(4))
print('by year'); print(J.groupby(J.index.year).mis.mean().round(3).to_dict())
print('mismatch explained by +-1 day shift', (J.mis&(J.lag1|J['lag-1'])).sum()/J.mis.sum())
print('by NWIS code'); print(J.groupby('cd').mis.agg(['mean','size']))
m=J[J.mis]; print('rel err quantiles of mismatches', m.rel.quantile([.1,.5,.9]).round(3).to_dict())
print('dates range in archive', J.index.min(), J.index.max())
# rounding check on matches: significant digits of archive values
s=J.g[~J.mis].head(20); print(s.values)
