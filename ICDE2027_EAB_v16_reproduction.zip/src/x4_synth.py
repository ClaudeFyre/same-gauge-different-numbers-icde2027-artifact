"""X4 of PLAN_R3_EXTENSIONS.md [diagnostic re-run 2026-11-07 adds per-edge logging only; decisions unchanged] (frozen 2026-11-07, md5 63d98013...): synthetic lineage with planted causes.
compare() is copied verbatim from g1.py and segments() from g4.py, so the protocol is the one used in E1/E2.
Implementation choices fixed before running:
- Roots: 100 LamaH-CE hourly gauges (daily root = UTC calendar-day mean, rounded to 0.001) and 100 DWD RR series from E5
  (as published), drawn with seed 0. Graph R->A->B, R->C; every edge applies a benign unit scale (k drawn from {1, 0.0283168,
  0.864}) and re-rounds to a grid (0.01 or 0.001 of the child's unit).
- Planted cause (seed 0), one per chain: T0 none; T1 -1 h window (LamaH only; edges from R); T2 linear interpolation of the child
  over random blocks of 1-6 days covering 2% of days; T3 child scaled by f ~ U(1.05, 1.30) after a random date in the middle 60%
  of the record; T4 parent revised after copying: the planted child keeps the old values while the parent's current series (and
  its other children) carry the revision f ~ U(1.05, 1.30) after a random date; T5 0.5% of child days times U(0.5, 1.5).
- Detection per direct edge (child vs parent): g1.compare(); an edge is flagged if it is scale-unstable or has divergent days.
  Predicted edge: an unstable edge first (largest IQR), else the edge with the highest divergent-day rate; none if no edge is flagged.
- Naming, in E2's order, on the predicted edge: unstable -> 'segment' if g4.segments() applies on the whole pair, else
  'unexplained'; stable -> per divergent day: 'window' if the child matches k times the -1 h / 07-07 / prev 07-07 window of the root's
  hourly data (edges from R, LamaH only) while not matching k times the parent; 'interpolation' if the child lies within tau of the
  linear interpolation of k*parent between the days bounding its run of divergent days; 'segment' if g4.segments() covers the day;
  else 'unexplained'. Chain name = majority day label. Mapping: T1->window, T2->interpolation, T3->segment.
"""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import glob, json, zipfile, io
from pathlib import Path
import numpy as np, pandas as pd
R0 = ROOT; P = ART; OUT = P / 'out/x4'; OUT.mkdir(parents=True, exist_ok=True)
HOURLY = Path(sorted(glob.glob(str(R0 / 'data/LamaH-CE/extracted_hourly/**/D_gauges/2_timeseries/hourly'), recursive=True))[0])
DWD = R0 / 'data/Expansion_2026-11-06/weather/series/dwd'

def qstep(x):
    u = np.unique(x[np.isfinite(x)]); d = np.diff(u); d = d[d > 0]
    return float(d.min()) if len(d) else 0.0

def compare(a, b):   # verbatim from g1.py
    j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna()
    if len(j) < 365: return None
    pos = j[j.b > 0]
    if len(pos) < 30: return None
    r = pos.a / pos.b; k = float(r.median())
    if not np.isfinite(k) or k <= 0: return None
    rr = pos.a / (k * pos.b); iqr = float(rr.quantile(.75) - rr.quantile(.25))
    ha, hb = qstep(j.a.values) / 2, qstep(j.b.values) / 2
    kb = k * j.b
    tau = np.maximum(0.02 * kb.abs(), 2 * (ha + k * hb))
    div = (j.a - kb).abs() > tau
    bfull = b.reindex(pd.date_range(j.index.min() - pd.Timedelta(days=1), j.index.max() + pd.Timedelta(days=1)))
    sh = np.zeros(len(j), bool)
    for L in (-1, 1):
        bs = bfull.shift(L).reindex(j.index)
        sh |= ((j.a - k * bs).abs() <= tau).fillna(False).values
    shift_expl = div.values & sh
    real = div.values & ~shift_expl
    return dict(n=len(j), k=k, iqr=iqr, stable=iqr <= 0.01, real=int(real.sum()), shift=int(shift_expl.sum()),
                real_mask=pd.Series(real, index=j.index), tau=tau)

def segments(a, b, div_idx):   # verbatim logic from g4.py (returns (applies, days))
    j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna(); j = j[j.b > 0]
    if len(j) < 730: return False, set()
    best = None
    for cp in pd.date_range(j.index[0], j.index[-1], freq='MS'):
        s1, s2 = j[j.index < cp], j[j.index >= cp]
        if len(s1) < 365 or len(s2) < 365: continue
        k1, k2 = (s1.a / s1.b).median(), (s2.a / s2.b).median()
        r1, r2 = s1.a / (k1 * s1.b), s2.a / (k2 * s2.b)
        i1, i2 = r1.quantile(.75) - r1.quantile(.25), r2.quantile(.75) - r2.quantile(.25)
        pooled = (i1 * len(s1) + i2 * len(s2)) / len(j)
        if best is None or pooled < best[0]: best = (pooled, cp, k1, k2, i1, i2)
    if best is None: return False, set()
    _, cp, k1, k2, i1, i2 = best
    if not (i1 <= 0.01 and i2 <= 0.01 and abs(k1 / k2 - 1) >= 0.02): return False, set()
    ha, hb = qstep(j.a.values) / 2, qstep(j.b.values) / 2
    out = set()
    for d in div_idx:
        if d not in j.index: continue
        k = k1 if d < cp else k2; bb = j.b[d]
        if abs(j.a[d] - k * bb) <= max(0.02 * abs(k * bb), 2 * (ha + k * hb)): out.add(d)
    return True, out

def load_lamah(lid):
    d = pd.read_csv(HOURLY / f'ID_{lid}.csv', sep=';')
    idx = pd.to_datetime(dict(year=d.YYYY, month=d.MM, day=d.DD, hour=d.hh, minute=d.mm))
    q = pd.Series(d.qobs.values.astype(float), index=idx); q[q < 0] = np.nan
    return q

def window(q, off):   # same construction as g4.hourly()
    return q.copy().set_axis(q.index - pd.Timedelta(hours=off)).resample('D').mean()

def load_dwd(p):
    z = zipfile.ZipFile(p); nm = [n for n in z.namelist() if n.startswith('produkt_klima_tag')][0]
    df = pd.read_csv(io.BytesIO(z.read(nm)), sep=';', skipinitialspace=True, dtype={'MESS_DATUM': str}); df.columns = [c.strip() for c in df.columns]
    x = df[df.RSK > -999]; return pd.Series(x.RSK.values.astype(float), index=pd.to_datetime(x.MESS_DATUM, format='%Y%m%d'))

def benign(x, rng):
    k = rng.choice([1.0, 0.0283168, 0.864]); g = rng.choice([0.01, 0.001])
    return np.round(x * k / g) * g

def plant_series(child_old, kind, rng):
    x = child_old.copy(); n = len(x)
    if kind == 'T2':
        target = int(0.02 * n); covered = 0; v = x.values.copy()
        while covered < target:
            L = int(rng.integers(1, 7)); s = int(rng.integers(1, n - L - 1))
            v[s:s + L] = np.interp(np.arange(s, s + L), [s - 1, s + L], [v[s - 1], v[s + L]]); covered += L
        x = pd.Series(v, index=x.index)
    elif kind == 'T3':
        d = x.index[int(rng.integers(int(0.2 * n), int(0.8 * n)))]; x[x.index >= d] *= rng.uniform(1.05, 1.30)
    elif kind == 'T5':
        i = rng.choice(n, max(1, int(0.005 * n)), replace=False); v = x.values.copy(); v[i] *= rng.uniform(0.5, 1.5, len(i)); x = pd.Series(v, index=x.index)
    return x

def chain(root, hourly, kind, edge, rng):
    R = root.copy()
    if kind == 'T1':
        alt = window(hourly, -1).reindex(R.index)
    s = {}
    def child_of(parent_name, parent_series, cname):
        base = alt if (kind == 'T1' and edge == (parent_name, cname)) else parent_series
        c = pd.Series(benign(base.values, rng), index=base.index)
        if edge == (parent_name, cname) and kind in ('T2', 'T3', 'T5'): c = plant_series(c, kind, rng)
        return c
    if kind == 'T4':
        n = len(R); d = R.index[int(rng.integers(int(0.2 * n), int(0.8 * n)))]; f = rng.uniform(1.05, 1.30)
        rev = lambda x: x.where(x.index < d, x * f)
        A_old = child_of('R', R, 'A')
        if edge == ('R', 'A'):
            A = A_old; Rcur = rev(R); C = child_of('R', Rcur, 'C'); B = child_of('A', A, 'B'); R = Rcur
        elif edge == ('R', 'C'):
            C = child_of('R', R, 'C'); Rcur = rev(R); A = child_of('R', Rcur, 'A'); B = child_of('A', A, 'B'); R = Rcur
        else:   # ('A', 'B'): A revised after B copied
            B = child_of('A', A_old, 'B'); A = rev(A_old); C = child_of('R', R, 'C')
    else:
        A = child_of('R', R, 'A'); B = child_of('A', A, 'B'); C = child_of('R', R, 'C')
    return dict(R=R, A=A, B=B, C=C)

def protocol(S, hourly):
    edges = [('R', 'A'), ('A', 'B'), ('R', 'C')]; info = {}
    for p, c in edges:
        r = compare(S[c], S[p]); info[(p, c)] = r
    flagged = {e: r for e, r in info.items() if r is not None and (not r['stable'] or r['real'] > 0)}
    tot_days = sum(r['n'] for r in info.values() if r is not None); tot_div = sum(r['real'] for r in info.values() if r is not None and r['stable'])
    global EDGEINFO
    EDGEINFO = {f'{p}->{c}': (None if r is None else dict(stable=bool(r['stable']), real=int(r['real']), n=int(r['n']), iqr=round(r['iqr'], 4))) for (p, c), r in info.items()}
    if not flagged: return None, 'none', tot_div, tot_days
    unst = [e for e, r in flagged.items() if not r['stable']]
    e = max(unst, key=lambda e: info[e]['iqr']) if unst else max(flagged, key=lambda e: flagged[e]['real'] / flagged[e]['n'])
    r = info[e]; p, c = e
    if not r['stable']:
        ap, _ = segments(S[c], S[p], [])
        return e, ('segment' if ap else 'unexplained'), tot_div, tot_days
    days = r['real_mask'][r['real_mask']].index; lab = pd.Series('unexplained', index=days)
    a, b, k, tau = S[c], S[p], r['k'], r['tau']
    if hourly is not None and p == 'R':
        alts = [window(hourly, off).reindex(b.index) for off in (-1, 7, -17)]
        for d in days:
            if abs(a[d] - k * b[d]) > tau[d] and any(np.isfinite(w[d]) and abs(a[d] - k * w[d]) <= tau[d] for w in alts): lab[d] = 'window'
    rest = lab[lab == 'unexplained'].index
    if len(rest):
        run_id = (pd.Series(rest).diff() != pd.Timedelta(days=1)).cumsum().values
        for _, grp in pd.Series(rest).groupby(run_id):
            s0, s1 = grp.iloc[0] - pd.Timedelta(days=1), grp.iloc[-1] + pd.Timedelta(days=1)
            if s0 in b.index and s1 in b.index and np.isfinite(b[s0]) and np.isfinite(b[s1]):
                xs = np.interp([(d - s0).days for d in grp], [0, (s1 - s0).days], [k * b[s0], k * b[s1]])
                for d, v in zip(grp, xs):
                    if abs(a[d] - v) <= tau[d]: lab[d] = 'interpolation'
    rest = lab[lab == 'unexplained'].index
    if len(rest):
        ap, dd = segments(a, b, list(rest))
        for d in dd: lab[d] = 'segment'
    return e, (lab.value_counts().idxmax() if len(lab) else 'unexplained'), tot_div, tot_days

if __name__ == '__main__':
    rng = np.random.default_rng(0)
    lam_ids = sorted(int(Path(f).stem.split('_')[1]) for f in glob.glob(str(HOURLY / 'ID_*.csv')))
    lam = sorted(rng.choice(lam_ids, 100, replace=False)); dwdf = sorted(DWD.glob('*.zip')); dw = sorted(rng.choice(len(dwdf), 100, replace=False))
    rows = []
    for src, items in [('lamah', lam), ('dwd', dw)]:
        for it in items:
            if src == 'lamah':
                q = load_lamah(int(it)); root = np.round(q.resample('D').mean().dropna() / 0.001) * 0.001; hourly = q
            else:
                root = load_dwd(dwdf[int(it)]).dropna(); hourly = None
            root = root[root.index >= '1951-01-01']
            if len(root) < 3650: continue
            kinds = ['T0', 'T1', 'T2', 'T3', 'T4', 'T5'] if src == 'lamah' else ['T0', 'T2', 'T3', 'T4', 'T5']
            kind = kinds[int(rng.integers(len(kinds)))]
            edges = [('R', 'A'), ('R', 'C')] if kind == 'T1' else [('R', 'A'), ('A', 'B'), ('R', 'C')]
            edge = edges[int(rng.integers(len(edges)))]
            S = chain(root, hourly, kind, edge, rng)
            e, name, tdiv, tdays = protocol(S, hourly)
            rows.append(dict(src=src, item=str(it), kind=kind, edge='->'.join(edge), pred_edge='->'.join(e) if e else 'none', name=name, div_days=tdiv, days=tdays, edges=json.dumps(EDGEINFO)))
            print(src, it, kind, edge, '->', e, name, flush=True)
    D = pd.DataFrame(rows); D.to_csv(OUT / 'x4_chains.csv', index=False)
    t0 = D[D.kind == 'T0']; pl = D[D.kind != 'T0']
    fdr = float(t0.div_days.sum() / t0.days.sum()) if len(t0) else np.nan
    loc = float((pl.pred_edge == pl.edge).mean())
    exp = {'T1': 'window', 'T2': 'interpolation', 'T3': 'segment'}
    named = D[D.name.isin(['window', 'interpolation', 'segment'])]
    prec = float(np.mean([exp.get(k) == n for k, n in zip(named.kind, named.name)])) if len(named) else np.nan
    rec = {k: float((D[D.kind == k].name == v).mean()) for k, v in exp.items() if (D.kind == k).any()}
    conf = pd.crosstab(D.kind, D.name).to_dict()
    loc_by = {k: float((g.pred_edge == g.edge).mean()) for k, g in pl.groupby('kind')}
    S = dict(chains=len(D), per_kind=D.kind.value_counts().to_dict(), false_divergence_T0=fdr, T0_chains_flagged=float((t0.pred_edge != 'none').mean()) if len(t0) else np.nan,
             localisation_accuracy=loc, localisation_by_kind=loc_by, naming_precision=prec, naming_recall=rec, confusion=conf)
    S['reading'] = 'validated' if (fdr <= 0.005 and loc >= 0.9 and prec >= 0.9) else 'not validated: ' + ', '.join(
        n for n, ok in [('false divergence', fdr <= 0.005), ('localisation', loc >= 0.9), ('naming precision', prec >= 0.9)] if not ok)
    json.dump(S, open(OUT / 'x4_summary.json', 'w'), indent=1, default=str); print(json.dumps(S, indent=1, default=str))
