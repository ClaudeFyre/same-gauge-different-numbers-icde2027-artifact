"""Build the released label files from the experiment outputs (identifiers and derived labels only; no discharge values).

labels/copy_pairs.csv            keyed copy pairs of E1 with scale constant, stability and divergence counts
labels/discovery_pairs.csv       E3 benchmark pairs (positives + negatives) with explicit ground-truth caveat flags
labels/divergent_day_causes.csv.gz  E2 cause per divergent day
labels/LABELS.md                 definitions and counts (written by this script)
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART
import json, math, pickle, ast
import pandas as pd

L = ART / 'labels'; L.mkdir(exist_ok=True)
meta = pickle.load(open(ART / 'cache/g2_meta.pkl', 'rb'))['meta']
REPO = {'P1_hysets_vs_camels': ('Caravan/hysets', 'Caravan/camels', 'USGS number'),
        'P2_grdc_vs_camels': ('GRDC-Caravan', 'Caravan/camels', 'nat_id'), 'P2_grdc_vs_hysets': ('GRDC-Caravan', 'Caravan/hysets', 'nat_id'),
        'P2_grdc_vs_camelsaus': ('GRDC-Caravan', 'Caravan/camelsaus', 'nat_id'), 'P2_grdc_vs_camelsbr': ('GRDC-Caravan', 'Caravan/camelsbr', 'nat_id'),
        'P2_grdc_vs_lamah': ('GRDC-Caravan', 'Caravan/lamah', 'nat_id'), 'P3_caravanlamah_vs_lamah': ('Caravan/lamah', 'LamaH-CE (ID)', 'agency number (govnr)'),
        'P4_gwse_vs_grdccaravan': ('GlobalRiverWSE', 'GRDC-Caravan', 'GRDC number'), 'P5_gwse_vs_caravanUS': ('GlobalRiverWSE', 'Caravan/camels|hysets', 'USGS number')}

# 1) copy pairs
g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv')
def clean_id(x):
    if isinstance(x, str) and x.startswith('('):
        t = ast.literal_eval(x); return f'{t[0]}:{t[1]}'
    return str(x)
cp = pd.DataFrame(dict(pair_type=g1.pair, repo_a=g1.pair.map(lambda p: REPO[p][0]), id_a=g1.a.map(clean_id),
                       repo_b=g1.pair.map(lambda p: REPO[p][1]), id_b=g1.b.map(clean_id), lineage_key=g1.pair.map(lambda p: REPO[p][2]),
                       overlap_days=g1.n, scale_k=g1.k.round(8), ratio_iqr=g1.iqr.round(6), scale_stable=g1.stable,
                       divergent_days=g1.real, shift_explained_days=g1['shift']))
cp['divergence_rate'] = (cp.divergent_days / cp.overlap_days).where(cp.scale_stable).round(6)
cp.to_csv(L / 'copy_pairs.csv', index=False)

# 2) discovery benchmark pairs with caveat flags
R = pd.read_parquet(ART / 'out/g2/g2_rows.parquet')
def hav(a, b):
    p = math.pi / 180
    x = math.sin((b['lat'] - a['lat']) * p / 2) ** 2 + math.cos(a['lat'] * p) * math.cos(b['lat'] * p) * math.sin((b['lon'] - a['lon']) * p / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(x))
pos = R[(R.label == 1) & R.cls.isin(['c1', 'c4', 'c6'])]           # each positive once, in its own (unperturbed) class
neg = R[(R.label == 0) & (R.cls == 'c1')]                          # negatives, unperturbed evaluation
D = pd.concat([pos, neg], ignore_index=True)
na, nb = [ast.literal_eval(x) for x in D.a], [ast.literal_eval(x) for x in D.b]
D['repo_a'] = [meta[n]['repo'] for n in na]; D['id_a'] = [str(n[1]) for n in na]
D['repo_b'] = [meta[n]['repo'] for n in nb]; D['id_b'] = [str(n[1]) for n in nb]
D['lineage_a'] = [meta[n]['lineage'] for n in na]; D['lineage_b'] = [meta[n]['lineage'] for n in nb]
D['dist_km'] = [round(hav(meta[x], meta[y]), 3) for x, y in zip(na, nb)]
D['positive_class'] = D.cls.where(D.label == 1, '')
D['negative_kind'] = D.kind.where(D.label == 0, '')
D['flag_subkm_unmatched_key'] = (D.label == 0) & (D.dist_km < 1)
D['flag_near_identical_series'] = (D.label == 0) & D.M4
out = D[['region', 'repo_a', 'id_a', 'repo_b', 'id_b', 'lineage_a', 'lineage_b', 'label', 'positive_class', 'negative_kind', 'dist_km',
         'flag_subkm_unmatched_key', 'flag_near_identical_series', 'M0', 'M1', 'M2', 'M3', 'M4']]
out = out.rename(columns={m: f'rule_{m}_unperturbed' for m in ['M0', 'M1', 'M2', 'M3', 'M4']})
out.to_csv(L / 'discovery_pairs.csv', index=False)

# 3) divergent-day causes
G = pd.read_parquet(ART / 'out/g4/g4_days.parquet')
G.to_csv(L / 'divergent_day_causes.csv.gz', index=False, compression='gzip')

# 4) LABELS.md
ns = int(out.flag_subkm_unmatched_key.sum()); ni = int(out.flag_near_identical_series.sum())
both = int((out.flag_subkm_unmatched_key & out.flag_near_identical_series).sum())
far = int((out.flag_near_identical_series & (out.dist_km >= 1)).sum())
md = f"""# Released labels

All files contain identifiers and derived labels only. No discharge values from any repository are redistributed.

## copy_pairs.csv ({len(cp):,} rows)
E1 copy pairs identified by lineage keys (never by geography or values) that have at least 365 overlapping days (keyed pairs without enough overlap are omitted).
- `scale_k`: median of a/b on days with both values finite and b > 0.
- `ratio_iqr`: IQR of a/(k b).
- `scale_stable`: ratio_iqr <= 0.01.
- `divergent_days`: days outside the rounding-aware tolerance and not explained by a +-1-day shift.
- `shift_explained_days`: divergent days that a +-1-day offset explains; excluded from the rate.
- `divergence_rate`: divergent_days / overlap_days; only defined for scale-stable pairs.

## discovery_pairs.csv ({len(out):,} rows)
The E3 benchmark.
- `label = 1`: a keyed copy pair ({int((out.label == 1).sum()):,} rows), with `positive_class` c1 (stable, < 5% divergent), c4 (stable, >= 5%) or c6 (scale-unstable).
- `label = 0`: a pair with *different* lineage keys ({int((out.label == 0).sum()):,} rows), with `negative_kind` hard (< 50 km and Pearson r >= 0.9, or LamaH upstream/downstream neighbours) or easy (random).
- `rule_*_unperturbed`: decisions of rules M0-M4 on the unperturbed series (paper, Sec. VII).

**Ground-truth caveat flags (negatives only).** A negative label means "different lineage key", which is not proof of "not a copy".
- `flag_subkm_unmatched_key` ({ns:,} rows): the two gauges lie less than 1 km apart. Inspected cases are identifier-format mismatches (GRDC nat_id vs CAMELS-AUS codes, Austrian agency numbers vs LamaH numbering, archive GRDC stations duplicating USGS gauges). **Likely unlabelled copies; treat as uncertain.**
- `flag_near_identical_series` ({ni:,} rows; {both:,} also sub-km; {far:,} at least 1 km apart): the quantisation-floor rule M4 matches, i.e. at least 90% of days agree within the tolerance. Beyond 1 km these are typically distinct gauges with near-identical records (possible derived or transferred records). **Not verified case by case.**

We recommend excluding flagged negatives from precision computations, or reporting results with and without them, as in the paper's sensitivity analysis.

## divergent_day_causes.csv.gz ({len(G):,} rows)
E2 attribution, one row per divergent day of the three diverging chains (columns: chain, a, b, day, cause).
Cause codes, in the order applied:
- L1: LamaH gap interpolation
- L2: aggregation window / day boundary
- L3, B4: scale segment
- L4, B1, B5: edge localisation
- B2: raw vs consistency-checked ANA level
- unresolved / unattributed

See plans/PLAN_G4_AMENDMENT.md for the frozen definitions.

## e3_verification.csv (581 rows) and e3_spotcheck_sample.csv (90 rows)
Metadata-only verification of every questionable E3 negative (flagged, or called a copy by any rule), per the frozen
`plans/PLAN_E3_VERIFY.md`: rule R1/R2 = confirmed copy (same station), R3 = confirmed non-copy, R4 = unresolved, with the
evidence (names, areas, distance, identifiers) for each decision. The spot-check sample (30 per group, seed 0) is provided
for independent review of the mechanical decisions.
"""
(L / 'LABELS.md').write_text(md, encoding='utf-8')
print(json.dumps(dict(copy_pairs=len(cp), discovery_pairs=len(out), subkm=ns, near_identical=ni, near_identical_far=far, causes=len(G))))
