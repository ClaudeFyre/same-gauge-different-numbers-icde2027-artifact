"""Read members of a remote zip via HTTP range requests (only the central directory and the requested members are transferred)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import io, urllib.request, zipfile

class HttpFile(io.RawIOBase):
    def __init__(self, url, block=1 << 20):
        self.url, self.pos, self.block, self.cache, self.bytes = url, 0, block, {}, 0
        req = urllib.request.Request(url, method='HEAD')
        self.size = int(urllib.request.urlopen(req, timeout=60).headers['Content-Length'])
    def seekable(self): return True
    def readable(self): return True
    def tell(self): return self.pos
    def seek(self, off, whence=0):
        self.pos = off if whence == 0 else (self.pos + off if whence == 1 else self.size + off); return self.pos
    def _get(self, a, b):
        req = urllib.request.Request(self.url, headers={'Range': f'bytes={a}-{b - 1}'})
        for t in range(4):
            try:
                d = urllib.request.urlopen(req, timeout=120).read(); self.bytes += len(d); return d
            except Exception:
                if t == 3: raise
    def read(self, n=-1):
        if n is None or n < 0: n = self.size - self.pos
        n = max(0, min(n, self.size - self.pos)); out = self._get(self.pos, self.pos + n) if n else b''
        self.pos += len(out); return out
    def readinto(self, b):
        d = self.read(len(b)); b[:len(d)] = d; return len(d)

def open_remote(url):
    f = HttpFile(url); z = zipfile.ZipFile(io.BufferedReader(f, buffer_size=1 << 16)); return z, f
