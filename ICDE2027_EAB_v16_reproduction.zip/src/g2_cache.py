"""Build the G2 series cache once (parallel). Same metadata/series semantics as g2.py; no rule changes."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import pickle, time, sys, numpy as np, pandas as pd
sys.path.insert(0, str(ART / 'src'))
from concurrent.futures import ProcessPoolExecutor
if __name__ == '__main__':
    t = time.time()
    src = open(ART / 'src/g2.py', encoding='utf-8').read()
    head = src.split("_c = pickle.load")[0]          # metadata section only
    g = {'__name__': 'g2meta', '__file__': __file__}; exec(compile(head, 'g2', 'exec'), g)
    meta, add, norm, vtnh, grdc_lin = g['meta'], g['add'], g['norm'], g['vtnh'], g['grdc_lin']
    from g2_load import load_node, to_arr
    nodes = list(meta)
    ser = {}
    with ProcessPoolExecutor(12) as ex:
        for i, (node, arr) in enumerate(ex.map(load_node, nodes, chunksize=50)):
            if arr is None: meta.pop(node)
            else: ser[node] = arr
            if i % 2000 == 0: print('loaded', i, len(nodes), round(time.time() - t), 's', flush=True)
    import zipfile
    zw = zipfile.ZipFile(g['GWSE'])
    for r in g['stream_array'](zw.open('Result datasets/Validation dataset/globe_gauge_discharge_data_30y.json')):
        ag, i = str(r['agency']), str(r['id'])
        if ag == 'USGS' and i in vtnh: continue
        lin = 'US:' + norm(i) if ag == 'USGS' else grdc_lin.get(i, 'GRDC:' + i)
        node = ('gwse', ag + '_' + i)
        if add(node, 'gwse_' + ag.lower(), r['lat'], r['lon'], np.nan, None, lin):
            meta[node]['station'] = None
            ser[node] = to_arr(pd.to_datetime(r['time']), r['discharge'])
    keys = list(ser)
    np.save(ART / 'cache/g2_series.npy', np.stack([ser[k] for k in keys]))
    pickle.dump(dict(keys=keys, meta={k: meta[k] for k in keys}), open(ART / 'cache/g2_meta.pkl', 'wb'))
    print('cached', len(keys), 'series in', round(time.time() - t), 's', flush=True)
