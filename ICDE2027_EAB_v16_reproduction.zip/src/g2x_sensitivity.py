"""Post-hoc sensitivity for E3 (descriptive; does not change the frozen G2 verdict): precision/recall per class after
removing negatives whose two series lie within 1 km of each other (likely unlabelled copies)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART
import json, math, pickle
import pandas as pd

R = pd.read_parquet(ART / 'out/g2/g2_rows.parquet')
meta = pickle.load(open(ART / 'cache/g2_meta.pkl', 'rb'))['meta']
def hav(a, b):
    p = math.pi / 180
    x = math.sin((b['lat'] - a['lat']) * p / 2) ** 2 + math.cos(a['lat'] * p) * math.cos(b['lat'] * p) * math.sin((b['lon'] - a['lon']) * p / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(x))
neg = R[R.label == 0][['a', 'b']].drop_duplicates()
neg['d'] = [hav(meta[eval(a)], meta[eval(b)]) for a, b in zip(neg.a, neg.b)]
near = set(zip(neg[neg.d < 1].a, neg[neg.d < 1].b))
print('negatives within 1 km:', len(near))
out = {}
for c in ['c1', 'c2', 'c3', 'c4', 'c5']:
    d = R[R.cls == c]
    keep = d[(d.label == 1) | ~pd.Series(list(zip(d.a, d.b)), index=d.index).isin(near)]
    res = {}
    for M in ['M0', 'M1', 'M2', 'M3', 'M4']:
        tp = int((keep[M] & (keep.label == 1)).sum()); fp = int((keep[M] & (keep.label == 0)).sum()); P = int((keep.label == 1).sum())
        res[M] = (round(tp / (tp + fp), 4) if tp + fp else None, round(tp / P, 3))
    out[c] = res; print(c, res)
json.dump(out, open(ART / 'out/g2/g2x_sensitivity_excl_1km_negatives.json', 'w'), indent=1)
