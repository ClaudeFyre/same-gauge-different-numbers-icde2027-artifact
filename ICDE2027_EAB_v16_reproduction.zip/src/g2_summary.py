"""Aggregate per-region G2 rows and apply the frozen G2 scoring/verdict (scoring code taken verbatim from g2.py)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import json, glob
from pathlib import Path
import pandas as pd
OUT = ART / 'out/g2'
R = pd.concat([pd.read_parquet(f) for f in sorted(glob.glob(str(OUT / 'g2_rows_*.parquet')))], ignore_index=True)
R.to_parquet(OUT / 'g2_rows.parquet', index=False)
classes = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6']
src = open(ART / 'src/g2.py', encoding='utf-8').read()
score_src = src[src.index("M = ['M0'"):src.index("summary['counts']")]
pos_n = R[R.label == 1][['a', 'b']].drop_duplicates().shape[0]
neg = R[R.label == 0][['a', 'b', 'kind']].drop_duplicates()
exec(score_src)
summary['counts'] = dict(positives=pos_n, negatives=len(neg), hard=int((neg.kind == 'hard').sum()))
(OUT / 'g2_summary.json').write_text(json.dumps(summary, indent=1, default=float))
for c, s in summary['pooled'].items():
    print(c, {m: (round(v['precision'], 3), round(v['recall'], 3), round(v['recall_at_p99'], 3)) for m, v in s.items()})
print(json.dumps(summary['gate']), json.dumps(summary['counts']))
