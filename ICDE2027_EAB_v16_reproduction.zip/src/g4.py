"""G4 attribution per PLAN_G4_AMENDMENT.md (frozen 2026-10-19). Implementation details fixed BEFORE running:
- Divergent days, k, tau, stable: re-derived with g1.compare() exactly as in G1 (same pair lists, same loaders).
- Third-series matching: k3 = median(copy/third) over their full overlap with third>0 (>=30 days); match iff
  |copy - k3*third| <= max(0.02*|k3*third|, 2*(h_copy + k3*h_third)), h = half of inferred quantization step.
- L1: LamaH gaps/ lists hourly timesteps; a day is 'interpolated' if any listed timestep falls on that calendar day.
- L2: alternative daily aggregations of LamaH hourly runoff: windows [D-1h, D+23h), [D+7h, D+31h), [D-17h, D+7h)
  relative to the hourly timestamps as published; cause if the *other* copy matches any alternative within tau and the
  LamaH-side series (daily for P3; Caravan lamah for P2) is the divergent one by definition.
  For P3: copy = Caravan lamah. For P2-lamah: copy = GRDC-Caravan.
- L3/B4: change point searched on month starts; segments >= 365 overlap days; pooled IQR of a/(k_i b) minimised;
  conditions IQR <= 0.01 in both, |k1/k2-1| >= 0.02. A divergent day is explained if it is within tau under its segment k.
- B3 DISABLED: ANA status-code meanings conflict between two official ANA manuals (HIDRO 1.2 vs SRDH), so under the
  frozen rule codes are reported raw only.
- ANA: level-1 (bruto) and level-2 (consistido) daily series from HidroSerieHistorica; a copy 'matches level L' using k
  fitted against the level-2 series (fallback level-1 if no level-2 overlap); same k for both levels (same units).
- Categories: explained {L1,L2,L3,B2,B4}; localized {L4 edges, B1, B5 edge}; unresolved/unattributed otherwise.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, json, zipfile, re, glob
from pathlib import Path
import numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore', category=RuntimeWarning)
sys.path.insert(0, str(ART / 'src'))
src = open(ART / 'src/g1.py', encoding='utf-8').read().split('# P4/P5')[0]
G = {'__file__': __file__}; exec(compile(src, 'g1', 'exec'), G)
compare, caravan, grdc, lamah, pairs, qstep = G['compare'], G['caravan'], G['grdc'], G['lamah'], G['pairs'], G['qstep']
gatt, norm = G['gatt'], G['norm']
lam_att = G['lam_att']
OUT = ART / 'out/g4'; OUT.mkdir(parents=True, exist_ok=True)
HOURLY = sorted(glob.glob(str(ROOT / 'data/LamaH-CE/extracted_hourly/**/D_gauges/2_timeseries/hourly'), recursive=True))
GAPS = ROOT / 'icde_probe/raw/lamah/D_gauges/2_timeseries/gaps'
CBR = zipfile.ZipFile(ROOT / 'data/Expansion_2026-10-19/CAMELS_BR/02_CAMELS_BR_streamflow_m3s.zip')
ANA = ROOT / 'data/Expansion_2026-10-19/ANA'

def match(x, y):
    """Boolean Series on common days: x ~ k*y within tau (k fitted on full overlap)."""
    j = pd.concat([x.rename('x'), y.rename('y')], axis=1).dropna(); pp = j[j.y > 0]
    if len(pp) < 30: return None
    k = float((pp.x / pp.y).median())
    if not np.isfinite(k) or k <= 0: return None
    hx, hy = qstep(j.x.values) / 2, qstep(j.y.values) / 2
    tau = np.maximum(0.02 * np.abs(k * j.y), 2 * (hx + k * hy))
    return (np.abs(j.x - k * j.y) <= tau)

def divergent_days(a, b):
    r = compare(a, b)
    if r is None or not r['stable']: return None, r
    return r['real_mask'][r['real_mask']].index, r

class SegRes(set):
    def __init__(self, applies, days):
        super().__init__(days); self.applies = applies

def rolling_k_range(a, b):
    j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna(); j = j[j.b > 0]
    if len(j) < 730: return None
    rk = (j.a / j.b).rolling(365, min_periods=200).median().dropna()
    return float(rk.max() / rk.min()) if len(rk) and rk.min() > 0 else None

def segments(a, b, div_idx):
    j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna(); j = j[j.b > 0]
    if len(j) < 730: return SegRes(False, set())
    best = None
    for cp in pd.date_range(j.index[0], j.index[-1], freq='MS'):
        s1, s2 = j[j.index < cp], j[j.index >= cp]
        if len(s1) < 365 or len(s2) < 365: continue
        k1, k2 = (s1.a / s1.b).median(), (s2.a / s2.b).median()
        r1, r2 = s1.a / (k1 * s1.b), s2.a / (k2 * s2.b)
        i1, i2 = r1.quantile(.75) - r1.quantile(.25), r2.quantile(.75) - r2.quantile(.25)
        pooled = (i1 * len(s1) + i2 * len(s2)) / len(j)
        if best is None or pooled < best[0]: best = (pooled, cp, k1, k2, i1, i2)
    if best is None: return SegRes(False, set())
    _, cp, k1, k2, i1, i2 = best
    if not (i1 <= 0.01 and i2 <= 0.01 and abs(k1 / k2 - 1) >= 0.02): return SegRes(False, set())
    ha, hb = qstep(j.a.values) / 2, qstep(j.b.values) / 2
    out = set()
    for d in div_idx:
        if d not in j.index: continue
        k = k1 if d < cp else k2; bb = j.b[d]
        if abs(j.a[d] - k * bb) <= max(0.02 * abs(k * bb), 2 * (ha + k * hb)): out.add(d)
    return SegRes(True, out)

def gaps_days(lid):
    f = GAPS / f'ID_{lid}.csv'
    if not f.exists(): return set()
    g = pd.read_csv(f, sep=';')
    return set(pd.to_datetime(dict(year=g.YYYY, month=g.MM, day=g.DD)))

_hcache = {}
def hourly(lid):
    if lid in _hcache: return _hcache[lid]
    fs = [Path(h) / f'ID_{lid}.csv' for h in HOURLY if (Path(h) / f'ID_{lid}.csv').exists()]
    if not fs: _hcache[lid] = None; return None
    d = pd.read_csv(fs[0], sep=';')
    idx = pd.to_datetime(dict(year=d.YYYY, month=d.MM, day=d.DD, hour=d.hh, minute=d.mm))
    q = pd.Series(d.qobs.values.astype(float), index=idx); q[q < 0] = np.nan
    alts = {}
    for name, off in [('shift-1h', -1), ('07-07', 7), ('prev07-07', -17)]:
        alts[name] = q.copy().set_axis(q.index - pd.Timedelta(hours=off)).resample('D').mean()
    _hcache[lid] = alts
    return alts

def lamah_id_of(caravan_lamah_gid):
    gov = caravan_lamah_gid.split('_', 1)[1]
    m = lam_att[lam_att.govnr.astype(str).map(norm) == norm(gov)]
    return int(m.ID.iloc[0]) if len(m) else None

grdc_by_lin = {}
for _, r in gatt.iterrows():
    if isinstance(r.nat_id, str): grdc_by_lin[norm(r.nat_id)] = r.gauge_id

rows, unstable = [], []
# ---------------- LamaH P3: a = Caravan lamah, b = LamaH-CE daily
for a_id, b_id in pairs['P3_caravanlamah_vs_lamah']:
    a, b = caravan(a_id), lamah(b_id)[0]
    div, r = divergent_days(a, b)
    if r is None: continue
    if div is None:
        unstable.append(dict(chain='LamaH-P3', a=a_id, b=b_id, single_changepoint=segments(a, b, []).applies, rolling_k_max_over_min=rolling_k_range(a, b))); continue
    gd = gaps_days(b_id); alts = hourly(b_id); seg = segments(a, b, div)
    gid = grdc_by_lin.get(norm(a_id.split('_', 1)[1])); g = grdc(gid) if gid else None
    m_alt = {k: match(a, v) for k, v in alts.items()} if alts else {}
    m_gb = match(g, b) if g is not None else None; m_ga = match(g, a) if g is not None else None
    for d in div:
        cause = None
        if d in gd: cause = 'L1 interpolation'
        elif any(m is not None and d in m.index and m[d] for m in m_alt.values()): cause = 'L2 aggregation/day-boundary'
        elif d in seg: cause = 'L3 scale segment'
        elif m_gb is not None and d in m_gb.index and m_gb[d] and not (m_ga is not None and d in m_ga.index and m_ga[d]): cause = 'L4 edge LamaH-CE->Caravan'
        elif m_ga is not None and d in m_ga.index and m_ga[d] and not (d in m_gb.index and m_gb[d]): cause = 'L4 edge agency->LamaH-CE'
        else: cause = 'unresolved'
        rows.append(dict(chain='LamaH-P3', a=a_id, b=b_id, day=d, cause=cause))
print('P3 done', len(rows), flush=True)

# ---------------- LamaH P2: a = GRDC-Caravan, b = Caravan lamah
for a_id, b_id in pairs['P2_grdc_vs_lamah']:
    a, b = grdc(a_id), caravan(b_id)
    div, r = divergent_days(a, b)
    if r is None: continue
    if div is None: unstable.append(dict(chain='LamaH-P2', a=a_id, b=b_id, single_changepoint=segments(a, b, []).applies, rolling_k_max_over_min=rolling_k_range(a, b))); continue
    lid = lamah_id_of(b_id)
    gd = gaps_days(lid) if lid else set(); alts = hourly(lid) if lid else None
    seg = segments(a, b, div)
    ld = lamah(lid)[0] if lid else None
    m_alt = {k: match(a, v) for k, v in alts.items()} if alts else {}
    m_la = match(a, ld) if ld is not None else None; m_lb = match(b, ld) if ld is not None else None
    for d in div:
        if d in gd: cause = 'L1 interpolation'
        elif any(m is not None and d in m.index and m[d] for m in m_alt.values()): cause = 'L2 aggregation/day-boundary'
        elif d in seg: cause = 'L3 scale segment'
        elif m_lb is not None and d in m_lb.index and m_lb[d] and not (m_la is not None and d in m_la.index and m_la[d]): cause = 'L4 GRDC differs from both LamaH products'
        elif m_la is not None and d in m_la.index and m_la[d] and not (d in m_lb.index and m_lb[d]): cause = 'L4 edge LamaH-CE->Caravan'
        else: cause = 'unresolved'
        rows.append(dict(chain='LamaH-P2', a=a_id, b=b_id, day=d, cause=cause))
print('P2-lamah done', len(rows), flush=True)

# ---------------- BR: a = GRDC-Caravan, b = Caravan camelsbr
def camelsbr_m3s(code):
    try:
        d = pd.read_csv(CBR.open(f'02_CAMELS_BR_streamflow_m3s/{code}_streamflow_m3s.txt'), sep=r'\s+')
    except KeyError:
        return None, None
    idx = pd.to_datetime(dict(year=d.year, month=d.month, day=d.day))
    return pd.Series(d.streamflow_m3s.values.astype(float), index=idx), pd.Series(d.qual_control_by_ana.values, index=idx)
def ana(code):
    f = ANA / f'{code}.xml'
    if not f.exists(): return None, None, None
    t = f.read_text(encoding='utf-8', errors='replace')
    lv = {1: {}, 2: {}}; st = {}
    for blk in re.findall(r'<SerieHistorica[^>]*>(.*?)</SerieHistorica>', t, re.S):
        L = int(re.search(r'<NivelConsistencia>(\d)', blk).group(1))
        m0 = pd.Timestamp(re.search(r'<DataHora>([\d-]+)', blk).group(1))
        for dd in range(1, 32):
            mv = re.search(rf'<Vazao{dd:02d}>([-\d.]+)</Vazao{dd:02d}>', blk)
            if not mv: continue
            try: day = m0.replace(day=dd)
            except ValueError: continue
            lv[L][day] = float(mv.group(1))
            ms = re.search(rf'<Vazao{dd:02d}Status>(\d+)</Vazao{dd:02d}Status>', blk)
            if ms: st[(L, day)] = int(ms.group(1))
    s1 = pd.Series(lv[1]).sort_index() if lv[1] else None
    s2 = pd.Series(lv[2]).sort_index() if lv[2] else None
    return s1, s2, st

br_status = []
for a_id, b_id in pairs['P2_grdc_vs_camelsbr']:
    a, b = grdc(a_id), caravan(b_id)
    div, r = divergent_days(a, b)
    if r is None: continue
    code = b_id.split('_', 1)[1]
    if div is None: unstable.append(dict(chain='BR', a=a_id, b=b_id, single_changepoint=segments(a, b, []).applies, rolling_k_max_over_min=rolling_k_range(a, b))); continue
    c, qc = camelsbr_m3s(code); r1, r2, st = ana(code)
    seg = segments(a, b, div)
    m_bc = match(b, c) if c is not None else None; m_ac = match(a, c) if c is not None else None
    ref = r2 if r2 is not None else r1
    def lvl_match(x):
        if ref is None: return None, None
        j = pd.concat([x.rename('x'), ref.rename('y')], axis=1).dropna(); pp = j[j.y > 0]
        if len(pp) < 30: return None, None
        k = float((pp.x / pp.y).median()); hx = qstep(j.x.values) / 2
        out = []
        for rs in (r1, r2):
            if rs is None: out.append(None); continue
            jj = pd.concat([x.rename('x'), rs.rename('y')], axis=1).dropna(); hy = qstep(jj.y.values) / 2
            out.append(np.abs(jj.x - k * jj.y) <= np.maximum(0.02 * np.abs(k * jj.y), 2 * (hx + k * hy)))
        return out
    ca1, ca2 = lvl_match(a)
    second = c if c is not None else b
    cc1, cc2 = lvl_match(second)
    cb1, cb2 = lvl_match(b)
    def hit(m, d): return m is not None and d in m.index and bool(m[d])
    for d in div:
        br_status.append(dict(a=a_id, day=d, st1=st.get((1, d)) if st else None, st2=st.get((2, d)) if st else None,
                              camelsbr_qc=(qc[d] if qc is not None and d in qc.index else None)))
        if m_bc is not None and d in m_bc.index and not m_bc[d] and hit(m_ac, d): cause = 'B1 edge CAMELS-BR->Caravan'
        elif (hit(ca1, d) and not hit(ca2, d) and hit(cc2, d) and not hit(cc1, d)) or (hit(ca2, d) and not hit(ca1, d) and hit(cc1, d) and not hit(cc2, d)):
            cause = 'B2 raw-vs-consistido'
        elif d in seg: cause = 'B4 scale segment'
        elif (hit(ca1, d) or hit(ca2, d)) and not (hit(cb1, d) or hit(cb2, d)): cause = 'B5 edge into Caravan/CAMELS-BR branch'
        elif (hit(cb1, d) or hit(cb2, d)) and not (hit(ca1, d) or hit(ca2, d)): cause = 'B5 edge into GRDC branch'
        else: cause = 'unattributed (consistent with revision; not verifiable)'
        rows.append(dict(chain='BR', a=a_id, b=b_id, day=d, cause=cause))
print('BR done', len(rows), flush=True)

import pickle
pickle.dump(dict(rows=rows, br_status=br_status, unstable=unstable), open(OUT / 'g4_raw.pkl', 'wb'))
R = pd.DataFrame(rows); R['a'] = R['a'].astype(str); R['b'] = R['b'].astype(str)
R.to_parquet(OUT / 'g4_days.parquet', index=False)
pd.DataFrame(br_status).astype({'a': str}).to_parquet(OUT / 'g4_br_status.parquet', index=False)
pd.DataFrame(unstable).to_csv(OUT / 'g4_unstable_pairs.csv', index=False)
EXPL = ('L1', 'L2', 'L3', 'B2', 'B4'); LOC = ('L4', 'B1', 'B5')
summ = {}
for ch, d in R.groupby('chain'):
    n = len(d); cnt = d.cause.value_counts().to_dict()
    e = d.cause.str[:2].isin(EXPL).mean(); l = d.cause.str[:2].isin(LOC).mean()
    verdict = 'EXPLAINED' if e >= 0.5 else ('LOCALIZED' if e + l >= 0.5 else 'OPEN')
    summ[ch] = dict(divergent_days=n, explained=round(e, 4), localized=round(l, 4), verdict=verdict, causes=cnt)
summ['pooled_no_verdict'] = dict(days=len(R), explained=round(R.cause.str[:2].isin(EXPL).mean(), 4),
                                 localized=round(R.cause.str[:2].isin(LOC).mean(), 4))
summ['hourly_dirs_found'] = HOURLY
(OUT / 'g4_summary.json').write_text(json.dumps(summ, indent=1, default=str))
print(json.dumps(summ, indent=1, default=str))
