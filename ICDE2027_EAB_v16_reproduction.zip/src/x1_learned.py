"""X1 of PLAN_R3_EXTENSIONS.md (frozen 2026-11-07, md5 63d98013...): learned matcher, leave-one-region-out.
Fixed before running: HistGradientBoostingClassifier(max_iter=300, learning_rate=0.1, random_state=0), repo pair as categorical;
training rows = classes c1-c5 of the three training regions; threshold = lowest score whose inner-LORO precision >= 0.99 (pooled
inner predictions of the training regions); verified bounds use the E3 verification sets exactly as e3_verify.py (pairs that were not
verified keep their original label)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import json, pickle
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
P = ART; OUT = P / 'out/x1'
F = ['logov', 'logk', 'iqr', 'within', 'r2', 'exact', 'shift', 'logq', 'logdist', 'logarea', 'jw_river', 'jw_station', 'repo']
REG = ['US', 'EU', 'BR', 'AU']
D = pd.concat([pd.read_parquet(OUT / f'features_{r}.parquet') for r in REG], ignore_index=True)
cats = sorted(D.repo.unique()); D['repo'] = pd.Categorical(D.repo, categories=cats).codes
X = D[F].astype(float).values; y = D.label.values; train_mask = D.cls.isin(['c1', 'c2', 'c3', 'c4', 'c5']).values
def fit(idx):
    m = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.1, random_state=0, categorical_features=[F.index('repo')])
    return m.fit(X[idx], y[idx])
def thr99(score, lab):
    o = np.argsort(-score); s = score[o]; l = lab[o]; tp = np.cumsum(l); prec = tp / np.arange(1, len(l) + 1)
    ok = np.where(prec >= 0.99)[0]
    return float(s[ok.max()]) if len(ok) else np.inf   # lowest score keeping cumulative precision >= 0.99
D['score'] = np.nan; D['pred'] = False; thr = {}
for r in REG:
    tr = [t for t in REG if t != r]
    inner_s, inner_y = [], []
    for t in tr:
        fi = np.where(D.region.isin([u for u in tr if u != t]).values & train_mask)[0]; ti = np.where((D.region == t).values & train_mask)[0]
        m = fit(fi); inner_s.append(m.predict_proba(X[ti])[:, 1]); inner_y.append(y[ti])
    th = thr99(np.concatenate(inner_s), np.concatenate(inner_y)); thr[r] = th
    m = fit(np.where(D.region.isin(tr).values & train_mask)[0]); te = np.where((D.region == r).values)[0]
    sc = m.predict_proba(X[te])[:, 1]; D.loc[te, 'score'] = sc; D.loc[te, 'pred'] = sc >= th
    print(r, 'threshold', th, flush=True)
# ---- verified relabelling as e3_verify.py
V = pd.read_csv(P / 'out/e3verify/verify_pairs.csv')
def nodekey(repo, i):
    kind = 'car' if repo.startswith('car_') else 'grdc' if repo == 'grdc_caravan' else 'lamah' if repo == 'lamah_ce' else 'gwse'
    return str((kind, int(float(i)) if kind == 'lamah' else i))
V['ka'] = [nodekey(a, b) for a, b in zip(V.repo_a, V.id_a)]; V['kb'] = [nodekey(a, b) for a, b in zip(V.repo_b, V.id_b)]
copy_set = set(zip(V[V.rule.isin(['R1', 'R2'])].ka, V[V.rule.isin(['R1', 'R2'])].kb)); unres_set = set(zip(V[V.rule == 'R4'].ka, V[V.rule == 'R4'].kb))
key = list(zip(D.a, D.b)); is_copy = np.array([k in copy_set for k in key]); is_unres = np.array([k in unres_set for k in key])
res = {}
G2 = json.load(open(P / 'out/g2/g2_summary.json'))['pooled']
for c in ['c1', 'c2', 'c3', 'c4', 'c5', 'c6']:
    x = D.cls == c; out = {}
    for name, lab in [('original', y == 1), ('lower', (y == 1) | is_copy), ('upper', (y == 1) | is_copy | is_unres)]:
        L = lab[x.values]; pr = D.pred.values[x.values]; tp = int((pr & L).sum()); fp = int((pr & ~L).sum())
        out[name] = dict(precision=tp / (tp + fp) if tp + fp else None, recall=tp / L.sum(), tp=tp, fp=fp)
    o = out['original']; out['recall_at_p99'] = o['recall'] if (o['precision'] or 0) >= 0.99 else 0.0
    out['best_base_r99'] = max(G2[c][m]['recall_at_p99'] for m in ['M0', 'M1', 'M2']) if c in G2 else None
    res[c] = out
hits = [c for c in ['c1', 'c2', 'c3', 'c4', 'c5'] if res[c]['best_base_r99'] < 0.90 and res[c]['recall_at_p99'] - res[c]['best_base_r99'] >= 0.10]
hits_up = [c for c in ['c1', 'c2', 'c3', 'c4', 'c5'] if (res[c]['upper']['precision'] or 0) >= 0.99 and res[c]['upper']['recall'] - res[c]['best_base_r99'] >= 0.10 and res[c]['best_base_r99'] < 0.90]
summ = dict(thresholds=thr, per_class=res, classes_passing=hits, classes_passing_upper=hits_up,
            reading='learned matcher passes' if hits else 'learned matcher fails')
# ---- error analysis (descriptive): matcher and M4 on c1-c5
ea = {}
for m_, col in [('ML', 'pred'), ('M4', 'M4')]:
    e = {}
    for c in ['c1', 'c2', 'c3', 'c4', 'c5']:
        x = D[D.cls == c]
        e[c] = dict(missed_positives=int(((x.label == 1) & ~x[col].astype(bool)).sum()), positives=int((x.label == 1).sum()))
    fpx = D[(D.cls == 'c1') & (D.label == 0) & D[col].astype(bool)]
    near = fpx[(10 ** fpx.logdist) < 50]; kn = list(zip(near.a, near.b))
    e['false_matches_c1'] = dict(total=len(fpx), within_50km=len(near), verified_copy=int(sum(k in copy_set for k in kn)),
                                  unresolved=int(sum(k in unres_set for k in kn)), other_near=int(len(near) - sum(k in copy_set or k in unres_set for k in kn)))
    ea[m_] = e
summ['errors'] = ea
D[['cls', 'label', 'kind', 'region', 'a', 'b', 'score', 'pred']].to_parquet(OUT / 'x1_scores.parquet', index=False)
json.dump(summ, open(OUT / 'x1_summary.json', 'w'), indent=1, default=float)
print(json.dumps({c: dict(p=res[c]['original']['precision'], r=res[c]['original']['recall'], r99=res[c]['recall_at_p99'], base=res[c]['best_base_r99'],
                          up=res[c]['upper']['precision']) for c in res}, indent=1, default=float))
print(summ['reading'], hits, hits_up); print(json.dumps(ea, indent=1))
