"""Stream a top-level JSON array of records without loading multi-GB files (copied from the project catalog code)."""
import io, json


def stream_array(raw):
    reader = io.TextIOWrapper(raw, encoding='utf-8-sig')
    step = 2 * 1024 * 1024
    buffer = reader.read(step)
    pos = 0
    while pos < len(buffer) and buffer[pos].isspace():
        pos += 1
    if buffer[pos:pos + 1] != '[':
        raise ValueError('Expected a JSON array')
    pos += 1
    decoder = json.JSONDecoder()
    while True:
        while pos < len(buffer) and (buffer[pos].isspace() or buffer[pos] == ','):
            pos += 1
        if pos == len(buffer):
            buffer, pos = reader.read(step), 0
            if not buffer:
                raise ValueError('Truncated array')
            continue
        if buffer[pos] == ']':
            return
        try:
            record, end = decoder.raw_decode(buffer, pos)
        except json.JSONDecodeError:
            more = reader.read(step)
            if not more:
                raise
            buffer, pos = buffer[pos:] + more, 0
            if len(buffer) > 64 * 1024 * 1024:
                raise ValueError('Unusually large individual station record')
            continue
        yield record
        pos = end
        if pos > step:
            buffer, pos = buffer[pos:], 0


