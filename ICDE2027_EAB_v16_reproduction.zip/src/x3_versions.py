"""X3 of PLAN_R3_EXTENSIONS.md (frozen 2026-11-07, md5 63d98013...): version evidence.
Implementation choices fixed before running:
- V1: a month counts as 're-inserted after the snapshot' if ANY ANA record of that month (either consistency level) has DataIns
  later than 2020-03-13 (CAMELS-BR v1.0). Divergent months = months with >= 1 day whose E2 cause is the ANA->CAMELS-BR edge
  ('B5 edge into Caravan/CAMELS-BR branch'); comparison months = months with ANA records and no divergent day of any cause in
  the BR chain for that station. Sign test over stations having both month types (ties dropped), two-sided.
- V2: ANA current series = level 2 where present, else level 1 (as E2's B5). For each station, k = median(v12/ANA) over days with
  ANA > 0 (>= 365 days), tau as Sec. III with q estimated per series; agreement = |v12 - k*ANA| <= tau.
  Divergent days = CAMELS-BR-edge days of E2; control = all other days of that station with v1.1, v1.2 and ANA values.
  The same agreement is reported for v1.1 on both day sets.
- V3: lines of the DWD change and error logs that mention the daily kl product; descriptive only.
"""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import re, json, zipfile, sys
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import binomtest
sys.path.insert(0, str(Path(__file__).parent))
R = ROOT; P = ART; OUT = P / 'out/x3'; OUT.mkdir(parents=True, exist_ok=True)
ANA = R / 'data/Expansion_2026-10-19/ANA'
V11 = zipfile.ZipFile(R / 'data/Expansion_2026-10-19/CAMELS_BR/02_CAMELS_BR_streamflow_m3s.zip')
V12 = zipfile.ZipFile(R / 'data/Expansion_2026-11-07/camelsbr_v12/02_CAMELS_BR_streamflow_all_catchments.zip')
SNAP = pd.Timestamp('2020-03-13')

def ana(code):
    t = (ANA / f'{code}.xml').read_text(encoding='utf-8', errors='replace')
    lv = {1: {}, 2: {}}; ins = {}
    for blk in re.findall(r'<SerieHistorica[^>]*>(.*?)</SerieHistorica>', t, re.S):
        L = int(re.search(r'<NivelConsistencia>(\d)', blk).group(1)); m0 = pd.Timestamp(re.search(r'<DataHora>([\d-]+)', blk).group(1))
        di = re.search(r'<DataIns>([\d-]+)', blk)
        if di: ins[m0] = max(ins.get(m0, pd.Timestamp('1900-01-01')), pd.Timestamp(di.group(1)))
        for dd in range(1, 32):
            mv = re.search(rf'<Vazao{dd:02d}>([-\d.]+)</Vazao{dd:02d}>', blk)
            if not mv: continue
            try: lv[L][m0.replace(day=dd)] = float(mv.group(1))
            except ValueError: continue
    s = pd.Series(lv[2], dtype=float).sort_index().combine_first(pd.Series(lv[1], dtype=float).sort_index())
    return s, pd.Series(ins)

def cbr(z, name):
    d = pd.read_csv(z.open(name), sep=r'\s+')
    col = 'streamflow_m3s'
    return pd.Series(d[col].values.astype(float), index=pd.to_datetime(dict(year=d.year, month=d.month, day=d.day)))

def qstep(x):
    u = np.unique(np.round(x[np.isfinite(x)], 4)); d = np.diff(u); d = d[d > 1e-9]
    return float(d.min()) if len(d) else 0.0

def agree(c, a):
    j = pd.concat([c.rename('c'), a.rename('a')], axis=1).dropna(); p = j[j.a > 0]
    if len(p) < 365: return None
    k = float((p.c / p.a).median()); tau = np.maximum(0.02 * np.abs(k * j.a), 2 * (qstep(j.c.values) / 2 + k * qstep(j.a.values) / 2))
    return (np.abs(j.c - k * j.a) <= tau)

if __name__ == '__main__':
    D = pd.read_parquet(P / 'out/g4/g4_days.parquet'); D = D[D.chain == 'BR']; D['day'] = pd.to_datetime(D.day)
    D['code'] = D.b.str.split('_').str[1]
    edge = 'B5 edge into Caravan/CAMELS-BR branch'
    v12names = {n.split('/')[-1].split('_')[0]: n for n in V12.namelist() if n.endswith('_streamflow.txt')}
    v11names = {n.split('/')[-1].split('_')[0]: n for n in V11.namelist() if n.endswith('_streamflow_m3s.txt')}
    rows1, rows2 = [], []
    for code, x in D.groupby('code'):
        if not (ANA / f'{code}.xml').exists(): continue
        a, ins = ana(code)
        dm = set(x[x.cause == edge].day.dt.to_period('M')); anym = set(x.day.dt.to_period('M'))
        later = (ins > SNAP); lm = {k.to_period('M'): bool(v) for k, v in later.items()}
        div = [lm[m] for m in dm if m in lm]; ctl = [v for m, v in lm.items() if m not in anym]
        rows1.append(dict(code=code, n_div=len(div), n_ctl=len(ctl), later_div=float(np.mean(div)) if div else np.nan,
                          later_ctl=float(np.mean(ctl)) if ctl else np.nan, ins_dates=int(ins.nunique())))
        if code in v12names and code in v11names:
            c12, c11 = cbr(V12, v12names[code]), cbr(V11, v11names[code])
            g12, g11 = agree(c12, a), agree(c11, a)
            if g12 is None or g11 is None: continue
            ed = set(x[x.cause == edge].day); common = g12.index.intersection(g11.index)
            dset = [d for d in common if d in ed]; cset = [d for d in common if d not in set(x.day)]
            rows2.append(dict(code=code, n_div=len(dset), n_ctl=len(cset), v12_div=int(g12.loc[dset].sum()), v11_div=int(g11.loc[dset].sum()),
                              v12_ctl=int(g12.loc[cset].sum()), v11_ctl=int(g11.loc[cset].sum()),
                              v12_equals_v11=float((np.abs(c12.reindex(common) - c11.reindex(common)) <= 1e-6).mean())))
    A = pd.DataFrame(rows1); B = pd.DataFrame(rows2)
    A.to_csv(OUT / 'v1_ana_insertion.csv', index=False); B.to_csv(OUT / 'v2_camelsbr_v12.csv', index=False)
    both = A[(A.n_div > 0) & (A.n_ctl > 0)]; diff = (both.later_div - both.later_ctl)
    pos, neg = int((diff > 0).sum()), int((diff < 0).sum())
    p = binomtest(pos, pos + neg, 0.5).pvalue if pos + neg else np.nan
    v1 = dict(stations=len(both), median_diff=float(diff.median()) if len(both) else np.nan, pos=pos, neg=neg, p=float(p),
              share_later_div=float((both.later_div * both.n_div).sum() / both.n_div.sum()) if len(both) else np.nan,
              share_later_ctl=float((both.later_ctl * both.n_ctl).sum() / both.n_ctl.sum()) if len(both) else np.nan,
              distinct_insertion_dates_median=float(A.ins_dates.median()))
    v1['reading'] = 'divergent months were re-inserted later' if (v1['median_diff'] > 0 and p < 0.05) else 'uninformative'
    tot = B[['n_div', 'n_ctl', 'v12_div', 'v11_div', 'v12_ctl', 'v11_ctl']].sum()
    v2 = dict(stations=len(B), div_days=int(tot.n_div), ctl_days=int(tot.n_ctl),
              v12_agree_div=float(tot.v12_div / tot.n_div), v11_agree_div=float(tot.v11_div / tot.n_div),
              v12_agree_ctl=float(tot.v12_ctl / tot.n_ctl), v11_agree_ctl=float(tot.v11_ctl / tot.n_ctl),
              v12_equals_v11_median=float(B.v12_equals_v11.median()))
    v2['reading'] = ('dated revision evidence' if (v2['v12_agree_div'] >= 0.5 and v2['v12_agree_ctl'] >= 0.95) else
                     'no evidence' if v2['v12_agree_div'] < 0.2 else 'partial')
    L = (ROOT / 'data/Expansion_2026-11-07/dwd_logs')
    v3 = []
    for f in ['Change_log_CDC_ftp.txt', 'Error_log_CDC_ftp.txt']:
        date = None
        for line in (L / f).read_text(encoding='latin1').splitlines():
            if re.fullmatch(r'\d{8}', line.strip()): date = line.strip()
            if re.search(r'daily/kl|klima_tag|tageswerte_KL', line, re.I): v3.append(dict(log=f, date=date, line=line.strip()[:160]))
    json.dump(dict(V1=v1, V2=v2, V3_entries=v3), open(OUT / 'x3_summary.json', 'w'), indent=1, default=str)
    print(json.dumps(dict(V1=v1, V2=v2, V3_n=len(v3)), indent=1, default=str))
