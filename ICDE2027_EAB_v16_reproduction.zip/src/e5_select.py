"""E5 station selection per PLAN_E5_WEATHER.md Sec. 3, from metadata files only (no observations are read).
Key links: GHCN-Daily station -> ECA&D non-blended SOUID per element via mingle-list.txt (source code E, '000<EL><SOUID>').
Metadata links: ECA&D DWD source -> DWD kl Stations_id by distance < 1 km, |dz| <= 10 m (name reported, not required)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import re, json, sys, math
from pathlib import Path
import numpy as np, pandas as pd
M = (ROOT / 'data/Expansion_2026-11-06/weather/meta')
OUT = (ART / 'out/e5'); OUT.mkdir(parents=True, exist_ok=True)

def dms(s):
    s = s.strip(); sg = -1 if s[0] == '-' else 1; d, m, x = (float(v) for v in s[1:].split(':'))
    return sg * (d + m / 60 + x / 3600)

def eca_info(el):
    rows = []
    for l in open(M / f'ECA_nonblend_info_{el}.txt', encoding='latin1'):
        p = l.rstrip('\n').split(',')
        if len(p) < 11 or not p[0].strip().isdigit() or p[2].strip() != 'DE': continue
        rows.append(dict(souid=int(p[0]), name=p[1].strip(), lat=dms(p[3]), lon=dms(p[4]), z=float(p[5]), ele=p[6].strip(),
                         start=int(p[7]), stop=int(p[8]), parid=int(p[9]), par=p[10].strip()))
    return pd.DataFrame(rows)

def dwd_kl():
    rows = []
    for l in open(M / 'KL_Tageswerte_Beschreibung_Stationen.txt', encoding='latin1').readlines()[2:]:
        p = l.split()
        if len(p) < 7 or not p[0].isdigit(): continue
        rows.append(dict(dwd=p[0], start=int(p[1]), stop=int(p[2]), z=float(p[3]), lat=float(p[4]), lon=float(p[5]), name=' '.join(p[6:-2])))
    return pd.DataFrame(rows)

def km(a1, o1, a2, o2):
    a1, o1, a2, o2 = map(np.radians, (a1, o1, a2, o2))
    return 2 * 6371 * np.arcsin(np.sqrt(np.sin((a2 - a1) / 2) ** 2 + np.cos(a1) * np.cos(a2) * np.sin((o2 - o1) / 2) ** 2))

if __name__ == '__main__':
    ghcn = {}
    for l in open(M / 'ghcnd-stations.txt'):
        if l.startswith('GM'): ghcn[l[:11]] = dict(lat=float(l[12:20]), lon=float(l[21:30]), z=float(l[31:37]), name=l[41:71].strip())
    link = []   # (ghcn, element, souid)
    for l in open(M / 'mingle-list.txt'):
        if not l.startswith('GM'): continue
        for m in re.finditer(r' E 000(RR|TX|TN)(\d{6})', l): link.append((l[:11], m.group(1), int(m.group(2))))
    link = pd.DataFrame(link, columns=['ghcn', 'el', 'souid'])
    info = pd.concat([eca_info(e).assign(el=e.upper()) for e in ['tx', 'tn', 'rr', 'tg']])
    dwd = dwd_kl()
    # key-linked GHCN <-> ECA&D (DWD participant only)
    L = link.merge(info[info.parid == 11][['souid', 'el', 'name', 'lat', 'lon', 'z', 'ele', 'start', 'stop']], on=['souid', 'el'])
    # metadata link ECA&D source -> DWD kl station
    srcs = info[info.parid == 11].drop_duplicates('souid')
    best = []
    for r in srcs.itertuples():
        d = km(r.lat, r.lon, dwd.lat.values, dwd.lon.values); i = int(np.argmin(d))
        ok = d[i] < 1.0 and abs(dwd.z.values[i] - r.z) <= 10
        best.append(dict(souid=r.souid, dwd=dwd.dwd.values[i] if ok else None, d_km=float(d[i]), dz=float(dwd.z.values[i] - r.z),
                         dwd_name=dwd.name.values[i], dwd_start=int(dwd.start.values[i]), dwd_stop=int(dwd.stop.values[i])))
    B = pd.DataFrame(best)
    L = L.merge(B, on='souid', how='left')
    # station-level candidates: GHCN station with key-linked TX and RR (DWD participant) and a metadata-linked DWD kl station,
    # overlapping metadata periods >= 10 years within 1951-2025 for all three sources
    def ov(r):
        s = max(r.start, r.dwd_start, 19510101); e = min(r.stop, r.dwd_stop, 20251231)
        return (e // 10000 - s // 10000) if e > s else 0
    L['ov_years'] = [ov(r) if r.dwd else 0 for r in L.itertuples()]
    good = L[(L.ov_years >= 10)]
    st = good.groupby('ghcn').el.apply(set)
    cand = sorted(g for g, s in st.items() if {'TX', 'RR'} <= s)
    rng = np.random.default_rng(0); pick = sorted(rng.choice(cand, 150, replace=False)) if len(cand) > 150 else cand
    print('GHCN GM stations', len(ghcn), '| E links (RR/TX/TN)', len(link), '| DWD-participant links', len(L),
          '| metadata-linked to DWD kl', int(L.dwd.notna().sum()), '| candidates', len(cand), '| picked', len(pick))
    print('link distance (km) among linked: median %.3f, max %.3f; |dz| max %.0f' % (L[L.dwd.notna()].d_km.median(), L[L.dwd.notna()].d_km.max(), L[L.dwd.notna()].dz.abs().max()))
    print('element codes of picked:', good[good.ghcn.isin(pick)].groupby('el').ele.value_counts().to_dict())
    sel = good[good.ghcn.isin(pick)]
    sel.to_csv(OUT / 'selection.csv', index=False)
    tg = info[(info.parid == 11) & (info.el == 'TG')].merge(B, on='souid')
    json.dump(dict(n_ghcn_gm=len(ghcn), n_links=len(link), n_dwd_links=len(L), n_candidates=len(cand), picked=list(pick),
                   n_tg_sources_linked=int(tg.dwd.notna().sum())), open(OUT / 'selection.json', 'w'), indent=1)
