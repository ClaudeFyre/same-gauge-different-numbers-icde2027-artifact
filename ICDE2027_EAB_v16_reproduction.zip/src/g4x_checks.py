"""Descriptive robustness checks for G4 (no verdict changes): L2 window breakdown + placebo windows; BR cause x CAMELS-BR qc flag x year."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import numpy as np, pandas as pd, json, warnings
warnings.filterwarnings('ignore')
s = open(ART / 'src/g4.py', encoding='utf-8').read()
exec(compile(s.split('rows, unstable = [], []')[0], 'g4', 'exec'))
exec(compile(s[s.index('def camelsbr_m3s'):s.index('br_status = []')], 'g4b', 'exec'))
D = pd.read_parquet(OUT / 'g4_days.parquet'); D['day'] = pd.to_datetime(D['day'])
res = {}
# ---- L2 windows + placebo on a fixed sample of 25 P3 gauges (seed 0)
P3 = D[D.chain == 'LamaH-P3']
gauges = pd.Series(P3.b.unique()).sample(25, random_state=0).tolist()
def window(q, off): return q.copy().set_axis(q.index - pd.Timedelta(hours=off)).resample('D').mean()
cnt = {}; tot = 0
for b_id in gauges:
    a_id = P3[P3.b == b_id].a.iloc[0]; a = caravan(a_id)
    fs = Path(HOURLY[0]) / f'ID_{b_id}.csv'
    d = pd.read_csv(fs, sep=';'); q = pd.Series(d.qobs.values.astype(float), index=pd.to_datetime(dict(year=d.YYYY, month=d.MM, day=d.DD, hour=d.hh, minute=d.mm))); q[q < 0] = np.nan
    days = pd.DatetimeIndex(P3[P3.b == b_id].day); tot += len(days)
    for name, off in [('calendar 00-24', 0), ('shift-1h', -1), ('07-07', 7), ('prev07-07', -17), ('PLACEBO +12h', 12), ('PLACEBO +3d', 72), ('PLACEBO -3d', -72)]:
        m = match(a, window(q, off))
        if m is None: continue
        cnt[name] = cnt.get(name, 0) + int(m.reindex(days).fillna(False).sum())
res['P3_sample_divergent_days'] = tot
res['P3_share_matched_by_window'] = {k: round(v / tot, 3) for k, v in cnt.items()}
# ---- BR: cause x CAMELS-BR qual_control_by_ana x year
B = D[D.chain == 'BR'].copy(); S = pd.read_parquet(OUT / 'g4_br_status.parquet'); S['day'] = pd.to_datetime(S['day'])
B = B.merge(S[['a', 'day', 'camelsbr_qc', 'st2']], on=['a', 'day'], how='left')
B['period'] = pd.cut(B.day.dt.year, [1900, 1999, 2009, 2014, 2030], labels=['<2000', '2000-09', '2010-14', '>=2015'])
res['BR_cause_by_camelsbr_qc'] = B.groupby('cause').camelsbr_qc.apply(lambda x: x.value_counts(normalize=True, dropna=False).round(3).to_dict()).to_dict()
res['BR_cause_by_period'] = pd.crosstab(B.cause, B.period, normalize='columns').round(3).to_dict()
res['BR_ana_status_raw_on_divergent_days'] = B.st2.value_counts(dropna=False).to_dict()
# non-divergent reference for qc flag: CAMELS-BR qc share over all days of the same gauges
qc_all = []
for code in B.b.str.split('_').str[1].unique():
    c, qc = camelsbr_m3s(code)
    if qc is not None: qc_all.append(qc)
res['CAMELSBR_qc_share_all_days_same_gauges'] = pd.concat(qc_all).value_counts(normalize=True).round(3).to_dict()
def fix(o):
    if isinstance(o, dict): return {str(k): fix(v) for k, v in o.items()}
    return o
res = fix(res)
(OUT / 'g4x_checks.json').write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
