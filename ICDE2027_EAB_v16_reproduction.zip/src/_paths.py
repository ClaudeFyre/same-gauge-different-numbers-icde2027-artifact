"""Path configuration for the artifact.

REPUB_ROOT points to the data root. Third-party data must be placed under it with the layout documented in
README.md ("Data layout"); fetch/fetch_all.py creates exactly this layout. ART is the artifact directory itself;
outputs go to ART/out and caches to ART/cache.
"""
import os
from pathlib import Path

ROOT = Path(os.environ.get('REPUB_ROOT', Path(__file__).resolve().parents[1] / 'data_root'))
ART = Path(__file__).resolve().parents[1]
(ART / 'out').mkdir(exist_ok=True)
(ART / 'cache').mkdir(exist_ok=True)
