"""G3 optional LSTM leakage check (unlocked by G3 leakage PASS). Protocol fixed BEFORE running:
Question: does a trained model's score on test basins inflate when their duplicates are in the training set?
- Test set T: 200 GRDC-Caravan basins drawn (seed 0) from G1 P2 copy pairs whose GRDC series and core partner both have
  >= 3650 finite streamflow days in 1990-2009. Target/forcing for T come from GRDC-Caravan.
- Clean pool: Caravan core basins that are in no G1 copy pair (P1/P2), have >= 3650 finite days in 1990-2009, and lie
  > 5 km from every T basin (guards against the unlabelled sub-km copies found in G2).
- Shared training set S: 1,000 basins from the clean pool (seed 0).
  A (leaky) = S + the 200 core partners of T.  B (clean) = S + 200 further clean-pool basins (seed 1, disjoint from S).
- Same period for training and testing (1990-2009; spatial generalisation, the setting where duplicates leak).
- Model: LSTM(10 ERA5-Land forcings + 14 Caravan climate attributes) hidden=64, layers=2, linear head, dropout 0.4;
  seq-to-one, window 365; Adam 1e-3; 15 epochs x 800 batches x 256 windows; NSE* loss (basin std from training data);
  inputs standardised with the condition's own training statistics. Seeds 0,1,2 per condition (6 models).
- Evaluation: NSE per T basin over 1991-2009 days with observations (365-day windows ending on each day), averaged over
  seeds per condition. Report median NSE_A, median NSE_B, paired dNSE = A - B per basin, Wilcoxon signed-rank p,
  share of basins with dNSE > 0.
- Pre-set reading: "material inflation" iff median paired dNSE >= 0.05 and Wilcoxon p < 0.01.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, json, zipfile, math, time
from pathlib import Path
import numpy as np, pandas as pd, torch, netCDF4
from scipy.spatial import cKDTree
from scipy.stats import wilcoxon

CAR = ROOT / 'data/Caravan/extracted/Caravan-nc'
GZ = zipfile.ZipFile(ROOT / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip')
OUT = ART / 'out/g3_lstm'; OUT.mkdir(parents=True, exist_ok=True)
FORC = ['total_precipitation_sum', 'temperature_2m_mean', 'temperature_2m_min', 'temperature_2m_max',
        'potential_evaporation_sum_FAO_PENMAN_MONTEITH', 'surface_net_solar_radiation_mean', 'surface_net_thermal_radiation_mean',
        'dewpoint_temperature_2m_mean', 'snow_depth_water_equivalent_mean', 'surface_pressure_mean']
T0, T1 = pd.Timestamp('1990-01-01'), pd.Timestamp('2009-12-31'); DAYS = pd.date_range(T0, T1); ND = len(DAYS)
SUBS = ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']
dev = torch.device('cuda')
SMOKE = len(sys.argv) > 1 and sys.argv[1] == 'smoke'
EPOCHS, NB, SEEDS = (1, 20, (0,)) if SMOKE else (15, 800, (0, 1, 2))

def load_core(gid):
    s = gid.split('_')[0]
    with netCDF4.Dataset(CAR / 'timeseries/netcdf' / s / f'{gid}.nc') as d:
        t = pd.to_datetime(netCDF4.num2date(d['date'][:], d['date'].units, only_use_cftime_datetimes=False, only_use_python_datetimes=True))
        cols = {v: np.ma.filled(d[v][:].astype(float), np.nan) for v in FORC + ['streamflow']}
    df = pd.DataFrame(cols, index=t).reindex(DAYS)
    return df[FORC].values.astype(np.float32), df.streamflow.values.astype(np.float32)
def load_grdc(gid):
    d = pd.read_csv(GZ.open(f'GRDC_Caravan_extension_csv/timeseries/csv/grdc/{gid}.csv'), usecols=['date'] + FORC + ['streamflow'], parse_dates=['date'])
    df = d.set_index('date').reindex(DAYS)
    return df[FORC].values.astype(np.float32), df.streamflow.values.astype(np.float32)

# ---------------- statics and coordinates
stat = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_caravan_{s}.csv') for s in SUBS] +
                 [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_caravan_grdc.csv'))]).drop_duplicates('gauge_id').set_index('gauge_id')
coords = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon']] for s in SUBS] +
                   [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon']]]).drop_duplicates('gauge_id').set_index('gauge_id')
SCOLS = list(stat.columns)

g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv')
cp = g1[g1.pair.str.startswith(('P1', 'P2'))]
in_pair = set(cp.a) | set(cp.b)
p2 = g1[g1.pair.str.startswith('P2')][['a', 'b']].drop_duplicates('a')

def xyz(ids):
    la = np.radians(coords.loc[ids, 'gauge_lat'].values); lo = np.radians(coords.loc[ids, 'gauge_lon'].values)
    return np.c_[np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]

DATA = {}
def get(gid):
    if gid not in DATA:
        DATA[gid] = load_grdc(gid) if gid.startswith('GRDC_') else load_core(gid)
    return DATA[gid]
def ok(gid):
    try: _, q = get(gid)
    except Exception: return False
    return np.isfinite(q).sum() >= 3650 and gid in stat.index

t0 = time.time()
rng = np.random.default_rng(0)
cand = p2.sample(frac=1, random_state=0)
T = []
for _, r in cand.iterrows():
    if ok(r.a) and ok(r.b): T.append((r.a, r.b))
    if len(T) == 200: break
print('T', len(T), round(time.time() - t0), 's', flush=True)
Tids = [a for a, _ in T]; partners = [b for _, b in T]
core_all = [g for s in SUBS for g in pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv').gauge_id if g not in in_pair and g in coords.index]
tree = cKDTree(xyz(Tids))
dmin, _ = tree.query(xyz(core_all), k=1)
far = [g for g, d in zip(core_all, dmin) if d * 6371 > 5]
order = list(pd.Series(far).sample(frac=1, random_state=0))
S, R = [], []
for g in order:
    if len(S) < 1000:
        if ok(g): S.append(g)
    elif len(R) < 200:
        if ok(g): R.append(g)
    else: break
print('S', len(S), 'R', len(R), round(time.time() - t0), 's', flush=True)
json.dump(dict(T=T, S=S, R=R), open(OUT / 'g3_lstm_sets.json', 'w'))

class Net(torch.nn.Module):
    def __init__(s, nin):
        super().__init__(); s.lstm = torch.nn.LSTM(nin, 64, num_layers=2, batch_first=True); s.drop = torch.nn.Dropout(0.4); s.head = torch.nn.Linear(64, 1)
    def forward(s, x):
        o, _ = s.lstm(x); return s.head(s.drop(o[:, -1])).squeeze(-1)

def build(ids):
    X = np.stack([get(g)[0] for g in ids]); Y = np.stack([get(g)[1] for g in ids]); St = stat.loc[ids, SCOLS].values.astype(np.float32)
    return X, Y, St

def run(cond, train_ids, seed):
    torch.manual_seed(seed); r = np.random.default_rng(seed)
    X, Y, St = build(train_ids)
    xm, xs = np.nanmean(X, (0, 1)), np.nanstd(X, (0, 1)) + 1e-6
    sm, ss = np.nanmean(St, 0), np.nanstd(St, 0) + 1e-6
    ym, ysd = np.nanmean(Y), np.nanstd(Y)
    qstd = np.nanstd(Y, 1)
    Xn = np.nan_to_num((X - xm) / xs); Sn = np.nan_to_num((St - sm) / ss); Yn = (Y - ym) / ysd
    valid = [(i, t) for i in range(len(train_ids)) for t in np.where(np.isfinite(Yn[i, 364:]))[0] + 364]
    valid = np.array(valid)
    Xg = torch.tensor(Xn, device=dev); Sg = torch.tensor(Sn, device=dev); Yg = torch.tensor(np.nan_to_num(Yn), device=dev)
    wg = torch.tensor(1 / (qstd / ysd + 0.1) ** 2, device=dev, dtype=torch.float32)
    net = Net(len(FORC) + len(SCOLS)).to(dev); opt = torch.optim.Adam(net.parameters(), 1e-3)
    ar = torch.arange(-364, 1, device=dev)
    for ep in range(EPOCHS):
        net.train(); tl = 0
        for _ in range(NB):
            b = valid[r.integers(0, len(valid), 256)]
            bi = torch.tensor(b[:, 0], device=dev); bt = torch.tensor(b[:, 1], device=dev)
            idx = bt[:, None] + ar[None, :]
            x = torch.cat([Xg[bi[:, None], idx], Sg[bi][:, None, :].expand(-1, 365, -1)], -1)
            pred = net(x); loss = (wg[bi] * (pred - Yg[bi, bt]) ** 2).mean()
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); tl += loss.item()
        print(cond, seed, 'epoch', ep, round(tl / NB, 4), round(time.time() - t0), 's', flush=True)
    # evaluate on T
    net.eval(); out = {}
    Xt, Yt, Stt = build(Tids)
    Xtn = torch.tensor(np.nan_to_num((Xt - xm) / xs), device=dev); Stn = torch.tensor(np.nan_to_num((Stt - sm) / ss), device=dev)
    with torch.no_grad():
        for i, g in enumerate(Tids[:3] if SMOKE else Tids):
            ts = torch.arange(365, ND, device=dev); preds = []
            for c in range(0, len(ts), 2048):
                tt = ts[c:c + 2048]; idx = tt[:, None] + ar[None, :]
                x = torch.cat([Xtn[i][idx], Stn[i][None, None, :].expand(len(tt), 365, -1)], -1)
                preds.append(net(x).cpu().numpy())
            p = np.concatenate(preds) * ysd + ym; o = Yt[i, 365:]
            m = np.isfinite(o)
            out[g] = float(1 - ((p[m] - o[m]) ** 2).sum() / ((o[m] - o[m].mean()) ** 2).sum()) if m.sum() > 365 else np.nan
    return out

res = {}
for cond, ids in [('A_leaky', S + partners), ('B_clean', S + R)]:
    for seed in SEEDS:
        res[f'{cond}_{seed}'] = run(cond, ids, seed)
        json.dump(res, open(OUT / (('smoke_' if SMOKE else '') + 'g3_lstm_nse.json'), 'w'), indent=1)
df = pd.DataFrame(res)
A = df[[c for c in df if c.startswith('A_')]].mean(1); B = df[[c for c in df if c.startswith('B_')]].mean(1)
d = (A - B).dropna()
stat_w = wilcoxon(d) if len(d) > 10 else None
summ = dict(n_test=int(d.size), median_nse_A=float(A.median()), median_nse_B=float(B.median()), median_dNSE=float(d.median()),
            mean_dNSE=float(d.mean()), share_dNSE_pos=float((d > 0).mean()), wilcoxon_p=float(stat_w.pvalue) if stat_w else None,
            seed_spread_B=float(df[[c for c in df if c.startswith('B_')]].median().std()))
summ['material_inflation'] = bool(summ['median_dNSE'] >= 0.05 and (summ['wilcoxon_p'] or 1) < 0.01)
(OUT / (('smoke_' if SMOKE else '') + 'g3_lstm_summary.json')).write_text(json.dumps(summ, indent=1))
print(json.dumps(summ, indent=1))
