"""Descriptive (not a gate): magnitude and flow-level of G1 divergent days for the 3 pairs >=1%, stable pairs only."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import numpy as np, pandas as pd
src = open(ART / 'src/g1.py', encoding='utf-8').read().split('# P4/P5')[0]
exec(compile(src, 'g1', 'exec'))
d = pd.read_csv(OUT / 'g1_pairs.csv'); d = d[d.stable]
out = {}
for p in ['P2_grdc_vs_camelsbr', 'P2_grdc_vs_lamah', 'P3_caravanlamah_vs_lamah']:
    rel, low = [], []
    for _, r in d[d.pair == p].iterrows():
        bid = int(r.b) if p.startswith('P3') else r.b
        a = grdc(r.a) if p.startswith('P2') else caravan(r.a)
        b = caravan(bid) if p.startswith('P2') else lamah(bid)[0]
        res = compare(a, b); m = res['real_mask']
        j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna().loc[m.index]
        kb = res['k'] * j.b; q10 = kb.quantile(.1)
        rr = ((j.a - kb).abs() / kb.abs().clip(lower=1e-9))[m]
        rel.append(rr); low.append((kb[m] <= q10))
    rel = pd.concat(rel); low = pd.concat(low)
    out[p] = dict(div_days=len(rel), rel_median=round(rel.median(), 3), share_gt10pct=round((rel > .10).mean(), 3),
                  share_gt50pct=round((rel > .5).mean(), 3), share_in_lowest_decile_flow=round(low.mean(), 3))
    print(p, out[p], flush=True)
pd.DataFrame(out).T.to_csv(OUT / 'g1x_magnitude.csv')
