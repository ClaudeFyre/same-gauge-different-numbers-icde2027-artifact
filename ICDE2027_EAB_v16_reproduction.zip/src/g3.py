"""G3 consequences per PLAN_G1_G4.md (frozen). Implementation choices fixed BEFORE running:
Leakage
- Combined pool = Caravan v1.6 core (7 subsets) + GRDC-Caravan, no dedup. Copy pairs = G1 keyed pairs P1 (hysets<->camels,
  inside core) + P2 (GRDC-Caravan<->core via nat_id). Results reported for all, and for P2-only.
- 10 random 80/20 basin splits, seeds 0-9. A test basin is affected if >=1 copy partner is in train; if several, the one
  with the longest overlap (ties: first in sorted order; added 2026-10-26 after a clean-clone run showed that
  set iteration order made tie-breaking depend on Python's hash seed). k fitted on the first 80% of the overlap (median ratio, b>0); test period = last 20% of overlap.
- Neighbour predictor: nearest train basin (great circle) that is not a copy partner, taken from the 30 nearest basins;
  streamflow is mm/d in both datasets, so area scaling is the identity. NSE computed on test-period days where the
  predictor and the target are both finite (>= 30 days, else basin skipped).
- Pass: median (over affected basin-splits) NSE_copy - NSE_neigh >= 0.10 AND mean affected share of test basins >= 2%.
Validation shift
- Records of Matched_gaugeQ_and_VS.json whose gauge is a G1 copy pair (P4: GRDC id in GRDC-Caravan; P5: USGS id in
  Caravan camels/hysets, VT/NH excluded). Source Q = partner copy scaled by k = median(archive/source) over overlap.
- Pass dates: 1899-12-30 + floor(monitor_time). Relation = OLS Q ~ a + b*WSE fitted on archive Q (>= 10 dates).
  KGE(Qhat, archive Q) vs KGE(Qhat, source Q) on the same dates. Per gauge: median |dKGE| over its VS records.
- Pass: >= 5% of gauges with median |dKGE| > 0.05.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, json, zipfile, math
from pathlib import Path
import numpy as np, pandas as pd, xarray as xr
from scipy.spatial import cKDTree

CAR = ROOT / 'data/Caravan/extracted/Caravan-nc'
GZIP = ROOT / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip'
GWSE = ROOT / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip'
OUT = ART / 'out/g3'; OUT.mkdir(parents=True, exist_ok=True)
from _stream import stream_array

gz = zipfile.ZipFile(GZIP)
def caravan(gid):
    s = gid.split('_')[0]
    with xr.open_dataset(CAR / 'timeseries/netcdf' / s / f'{gid}.nc') as d:
        return d['streamflow'].to_series().astype(float)
def grdc(gid):
    d = pd.read_csv(gz.open(f'GRDC_Caravan_extension_csv/timeseries/csv/grdc/{gid}.csv'), usecols=['date', 'streamflow'], parse_dates=['date'])
    return d.set_index('date').streamflow.astype(float)
def load(g): return grdc(g) if g.startswith('GRDC_') else caravan(g)

def nse(sim, obs):
    d = ((obs - obs.mean()) ** 2).sum()
    return float(1 - ((sim - obs) ** 2).sum() / d) if d > 0 else np.nan
def kge(sim, obs):
    if obs.std() == 0 or sim.std() == 0 or obs.mean() == 0: return np.nan
    r = np.corrcoef(sim, obs)[0, 1]
    return float(1 - math.sqrt((r - 1) ** 2 + (sim.std() / obs.std() - 1) ** 2 + (sim.mean() / obs.mean() - 1) ** 2))

# ---------------- pool and copy pairs
att = []
for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']:
    a = pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon']]; att.append(a)
go = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon']]
att.append(go)
pool = pd.concat(att, ignore_index=True).drop_duplicates('gauge_id').reset_index(drop=True)
g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv')
cp = g1[g1.pair.str.startswith(('P1', 'P2'))][['pair', 'a', 'b']]
partners = {}
for _, r in cp.iterrows():
    partners.setdefault(r.a, set()).add((r.b, r.pair)); partners.setdefault(r.b, set()).add((r.a, r.pair))
print('pool', len(pool), 'basins with partners', len(partners), flush=True)

la, lo = np.radians(pool.gauge_lat.values), np.radians(pool.gauge_lon.values)
xyz = np.c_[np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]
tree = cKDTree(xyz)
ids = pool.gauge_id.values; pos_of = {g: i for i, g in enumerate(ids)}
near = {}
for g in partners:
    if g not in pos_of: continue
    _, nn = tree.query(xyz[pos_of[g]], k=31)
    near[g] = [ids[j] for j in nn if ids[j] != g]
need = set(partners) | {x for v in near.values() for x in v}
S = {}
for i, g in enumerate(sorted(need)):
    try: S[g] = load(g)
    except Exception: pass
    if i % 2000 == 0: print('loaded', i, len(need), flush=True)

# ---------------- leakage
rows = []
for seed in range(10):
    rng = np.random.default_rng(seed)
    test = set(rng.choice(ids, size=int(0.2 * len(ids)), replace=False))
    n_test = len(test)
    for t in sorted(test):
        if t not in partners or t not in S: continue
        cands = sorted((p, pr) for p, pr in partners[t] if p not in test and p in S)
        if not cands: continue
        best = None
        for p, pr in cands:
            j = pd.concat([S[t].rename('y'), S[p].rename('x')], axis=1).dropna()
            if best is None or len(j) > len(best[2]): best = (p, pr, j)
        p, pr, j = best
        if len(j) < 150: continue
        cut = int(0.8 * len(j)); tr, te = j.iloc[:cut], j.iloc[cut:]
        pp = tr[tr.x > 0]
        if len(pp) < 30: continue
        k = float((pp.y / pp.x).median())
        copy_pred = k * te.x
        nb = next((n for n in near.get(t, []) if n not in test and n in S and n not in {q for q, _ in partners[t]}), None)
        if nb is None: continue
        jj = pd.concat([te.y, copy_pred.rename('c'), S[nb].rename('n')], axis=1).dropna()
        if len(jj) < 30: continue
        rows.append(dict(seed=seed, test=t, partner=p, pair=pr, neighbour=nb, n_test_days=len(jj), n_test_basins=n_test,
                         nse_copy=nse(jj.c, jj.y), nse_neigh=nse(jj.n, jj.y)))
    print('seed', seed, 'affected so far', len(rows), flush=True)
L = pd.DataFrame(rows); L['gain'] = L.nse_copy - L.nse_neigh
L.to_csv(OUT / 'g3_leakage_rows.csv', index=False)
def leak_summary(df):
    aff = df.groupby('seed').size() / df.groupby('seed').n_test_basins.first()
    return dict(affected_rows=len(df), mean_affected_share=float(aff.mean()), median_gain=float(df.gain.median()),
                median_nse_copy=float(df.nse_copy.median()), median_nse_neigh=float(df.nse_neigh.median()))
summ = {'leakage_all': leak_summary(L), 'leakage_P2_only': leak_summary(L[L.pair.str.startswith('P2')])}
la_ = summ['leakage_all']
summ['leakage_pass'] = la_['median_gain'] >= 0.10 and la_['mean_affected_share'] >= 0.02
print(json.dumps(summ), flush=True)

# ---------------- validation shift
vtnh = set(pd.read_parquet(ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet').site.astype(str))
gadd = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_additional_grdc.csv'))
grdc_ids = {g.split('_', 1)[1]: g for g in gadd.gauge_id}
usgs = {}
for s in ['hysets', 'camels']:
    for g in pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv').gauge_id: usgs[g.split('_', 1)[1]] = g
z = zipfile.ZipFile(GWSE)
vrows = []
src_cache = {}
for r in stream_array(z.open('Result datasets/Validation dataset/Matched_gaugeQ_and_VS.json')):
    ag, gid = str(r.get('gauge_agency')), str(r.get('gauge_id'))
    partner = grdc_ids.get(gid) if ag == 'GRDC' else (usgs.get(gid) if (ag == 'USGS' and gid not in vtnh) else None)
    if partner is None: continue
    if partner not in src_cache:
        try: src_cache[partner] = load(partner)
        except Exception: src_cache[partner] = None
    src = src_cache[partner]
    if src is None: continue
    arch = pd.Series(np.asarray(r['gauge_discharge'], float), index=pd.to_datetime(r['gauge_time']))
    j = pd.concat([arch.rename('a'), src.rename('s')], axis=1).dropna(); pp = j[j.s > 0]
    if len(pp) < 30: continue
    k = float((pp.a / pp.s).median())
    dates = pd.to_datetime('1899-12-30') + pd.to_timedelta(np.floor(np.asarray(r['monitor_time'], float)), unit='D')
    w = pd.Series(np.asarray(r['monitor_wse'], float), index=dates)
    w = w[~w.index.duplicated()]
    m = pd.concat([w.rename('w'), arch.rename('a'), (k * src).rename('s')], axis=1).dropna()
    if len(m) < 10 or m.w.std() == 0: continue
    b, a0 = np.polyfit(m.w, m.a, 1); qh = a0 + b * m.w
    ka, ks = kge(qh.values, m.a.values), kge(qh.values, m.s.values)
    vrows.append(dict(agency=ag, gauge=gid, vs=r.get('FID_VS'), n=len(m), kge_arch=ka, kge_src=ks, dkge=abs(ks - ka) if np.isfinite(ka) and np.isfinite(ks) else np.nan))
V = pd.DataFrame(vrows); V.to_csv(OUT / 'g3_validation_rows.csv', index=False)
per_g = V.dropna(subset=['dkge']).groupby(['agency', 'gauge']).dkge.median()
summ['validation'] = dict(vs_records=len(V), gauges=int(per_g.size), share_gt005=float((per_g > 0.05).mean()) if per_g.size else None,
                          median_dkge=float(per_g.median()) if per_g.size else None)
summ['validation_pass'] = bool(per_g.size and (per_g > 0.05).mean() >= 0.05)
summ['verdict'] = 'K4 kept' if (summ['leakage_pass'] or summ['validation_pass']) else 'K4 dropped'
(OUT / 'g3_summary.json').write_text(json.dumps(summ, indent=1, default=float))
print(json.dumps(summ, default=float))
