"""G1 prevalence per PLAN_G1_G4.md (frozen). a = downstream copy, b = upstream/reference copy."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, json, zipfile, glob, os
from pathlib import Path
import numpy as np, pandas as pd, xarray as xr

CAR = ROOT / 'data/Caravan/extracted/Caravan-nc'
GZIP = ROOT / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip'
LAMAH = ROOT / 'icde_probe/raw/lamah/D_gauges'
GWSE = ROOT / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip'
OUT = ART / 'out/g1'; OUT.mkdir(parents=True, exist_ok=True)
from _stream import stream_array

def qstep(x):
    u = np.unique(x[np.isfinite(x)])
    d = np.diff(u); d = d[d > 0]
    return float(d.min()) if len(d) else 0.0

def compare(a, b):
    j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna()
    if len(j) < 365: return None
    pos = j[j.b > 0]
    if len(pos) < 30: return None
    r = pos.a / pos.b; k = float(r.median())
    if not np.isfinite(k) or k <= 0: return None
    rr = pos.a / (k * pos.b); iqr = float(rr.quantile(.75) - rr.quantile(.25))
    ha, hb = qstep(j.a.values) / 2, qstep(j.b.values) / 2
    kb = k * j.b
    tau = np.maximum(0.02 * kb.abs(), 2 * (ha + k * hb))
    div = (j.a - kb).abs() > tau
    bfull = b.reindex(pd.date_range(j.index.min() - pd.Timedelta(days=1), j.index.max() + pd.Timedelta(days=1)))
    sh = np.zeros(len(j), bool)
    for L in (-1, 1):
        bs = bfull.shift(L).reindex(j.index)
        sh |= ((j.a - k * bs).abs() <= tau).fillna(False).values
    shift_expl = div.values & sh
    real = div.values & ~shift_expl
    yrs = pd.Series(real, index=j.index).groupby(j.index.year).agg(['sum', 'size'])
    return dict(n=len(j), k=k, iqr=iqr, stable=iqr <= 0.01, div=int(div.sum()), shift=int(shift_expl.sum()),
                real=int(real.sum()), years=yrs, real_mask=pd.Series(real, index=j.index))

# ---------- loaders
def caravan(gid):
    sub = gid.split('_')[0]
    f = CAR / 'timeseries/netcdf' / sub / f'{gid}.nc'
    if not f.exists(): return None
    with xr.open_dataset(f) as d:
        return d['streamflow'].to_series().astype(float)

gz = zipfile.ZipFile(GZIP)
def grdc(gid):
    try:
        d = pd.read_csv(gz.open(f'GRDC_Caravan_extension_csv/timeseries/csv/grdc/{gid}.csv'), usecols=['date', 'streamflow'], parse_dates=['date'])
    except KeyError:
        return None
    return d.set_index('date').streamflow.astype(float)

lam_att = pd.read_csv(LAMAH / '1_attributes/Gauge_attributes.csv', sep=';')
def lamah(lid):
    d = pd.read_csv(LAMAH / f'2_timeseries/daily/ID_{lid}.csv', sep=';')
    idx = pd.to_datetime(dict(year=d.YYYY, month=d.MM, day=d.DD))
    q = pd.Series(d.qobs.values, index=idx).astype(float); q[q < 0] = np.nan
    return q, pd.Series(d.ckhs.values, index=idx)

core_ids = {s: pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv').gauge_id.tolist()
            for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']}
gatt = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_additional_grdc.csv'))

def norm(s): return str(s).strip().upper().lstrip('0')

pairs = {}  # name -> list of (a_id, b_id, loader_a, loader_b)
# P1 camels vs hysets
hy = {norm(g.split('_', 1)[1]): g for g in core_ids['hysets']}
pairs['P1_hysets_vs_camels'] = [(hy[norm(c.split('_', 1)[1])], c) for c in core_ids['camels'] if norm(c.split('_', 1)[1]) in hy]
# P2 GRDC-Caravan vs core via nat_id, country-restricted
country_sub = {'US': ['camels', 'hysets'], 'CA': ['hysets'], 'MX': ['hysets'], 'BR': ['camelsbr'], 'AU': ['camelsaus'],
               'CL': ['camelscl'], 'GB': ['camelsgb']}
lamah_cty = {'AT', 'DE', 'CZ', 'CH', 'IT', 'SI', 'HU', 'SK', 'LI'}
idx_sub = {s: {norm(g.split('_', 1)[1]): g for g in core_ids[s]} for s in core_ids}
p2 = {}
for _, r in gatt.iterrows():
    if pd.isna(r.nat_id): continue
    subs = country_sub.get(r.country, ['lamah'] if r.country in lamah_cty else [])
    for s in subs:
        m = idx_sub[s].get(norm(r.nat_id))
        if m: p2.setdefault(s, []).append((r.gauge_id, m))
for s, v in p2.items(): pairs[f'P2_grdc_vs_{s}'] = v
# P3 Caravan lamah vs standalone LamaH by govnr
gov = {norm(g): i for g, i in zip(lam_att.govnr, lam_att.ID)}
pairs['P3_caravanlamah_vs_lamah'] = [(c, gov[norm(c.split('_', 1)[1])]) for c in core_ids['lamah'] if norm(c.split('_', 1)[1]) in gov]

# P4/P5 GlobalRiverWSE 30y archive (chosen before results: longest overlap)
vtnh = set(pd.read_parquet(ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet').site.astype(str))
grdc_nums = {g.split('_', 1)[1]: g for g in gatt.gauge_id}
usgs_core = {}
for c in core_ids['hysets']: usgs_core.setdefault(c.split('_', 1)[1], c)
for c in core_ids['camels']: usgs_core[c.split('_', 1)[1]] = c  # prefer camels
gw = {}
zw = zipfile.ZipFile(GWSE)
for r in stream_array(zw.open('Result datasets/Validation dataset/globe_gauge_discharge_data_30y.json')):
    ag, i = str(r['agency']), str(r['id'])
    if (ag == 'GRDC' and i in grdc_nums) or (ag == 'USGS' and i in usgs_core and i not in vtnh):
        gw[(ag, i)] = pd.Series(np.asarray(r['discharge'], float), index=pd.to_datetime(r['time']))
pairs['P4_gwse_vs_grdccaravan'] = [(('GRDC', i), grdc_nums[i]) for (ag, i) in gw if ag == 'GRDC']
pairs['P5_gwse_vs_caravanUS'] = [(('USGS', i), usgs_core[i]) for (ag, i) in gw if ag == 'USGS']

def load(pname, x, side):
    if pname.startswith('P4') or pname.startswith('P5'):
        if side == 'a': return gw[x]
        return grdc(x) if pname.startswith('P4') else caravan(x)
    if pname.startswith('P2'): return grdc(x) if side == 'a' else caravan(x)
    if pname.startswith('P3'): return caravan(x) if side == 'a' else lamah(x)[0]
    return caravan(x)

summary, rows = {}, []
for pname, lst in pairs.items():
    agg = dict(copy_pairs_keyed=len(lst), compared=0, unstable=0, overlap=0, real=0, shift=0, div=0)
    years = []
    flag_stats = []
    for a_id, b_id in lst:
        a, b = load(pname, a_id, 'a'), load(pname, b_id, 'b')
        if a is None or b is None: continue
        res = compare(a, b)
        if res is None: continue
        agg['compared'] += 1
        row = dict(pair=pname, a=str(a_id), b=str(b_id), n=res['n'], k=res['k'], iqr=res['iqr'], stable=res['stable'],
                   div=res['div'], shift=res['shift'], real=res['real'])
        rows.append(row)
        if not res['stable']:
            agg['unstable'] += 1; continue
        agg['overlap'] += res['n']; agg['real'] += res['real']; agg['shift'] += res['shift']; agg['div'] += res['div']
        years.append(res['years'])
        if pname.startswith('P3'):
            fl = lamah(b_id)[1].reindex(res['real_mask'].index)
            flag_stats.append(pd.DataFrame(dict(real=res['real_mask'], flag=fl)))
    if years:
        y = pd.concat(years).groupby(level=0).sum(); agg['by_year'] = (y['sum'] / y['size']).round(4).to_dict()
    if flag_stats:
        f = pd.concat(flag_stats); agg['by_lamah_ckhs'] = f.groupby('flag').real.agg(['mean', 'size']).round(4).to_dict('index')
    agg['divergence_rate'] = agg['real'] / agg['overlap'] if agg['overlap'] else None
    agg['shift_explained_share_of_div'] = agg['shift'] / agg['div'] if agg['div'] else None
    agg['counts'] = agg['compared'] - agg['unstable'] >= 20
    summary[pname] = agg
    print(pname, {k: v for k, v in agg.items() if k not in ('by_year',)}, flush=True)

pd.DataFrame(rows).to_csv(OUT / 'g1_pairs.csv', index=False)
# leakage: duplicate share in Caravan core + GRDC-Caravan without nat_id dedup
n_core = sum(len(v) for v in core_ids.values()); n_grdc = gatt.shape[0]
dup_grdc = len({a for k, v in p2.items() for a, _ in v})
summary['duplicate_share'] = dict(core=n_core, grdc=n_grdc, grdc_with_core_duplicate=dup_grdc,
                                  share_of_combined=dup_grdc / (n_core + n_grdc))
counting = [p for p, v in summary.items() if p.startswith('P') and v['counts']]
hits = [p for p in counting if (summary[p]['divergence_rate'] or 0) >= 0.01]
low = all((summary[p]['divergence_rate'] or 0) < 0.002 for p in counting)
dshare = summary['duplicate_share']['share_of_combined']
summary['gate'] = dict(counting_pairs=counting, pairs_ge_1pct=hits,
                       verdict='PASS' if (len(hits) >= 2 or dshare >= 0.02) else ('KILL' if low and dshare < 0.02 else 'WEAK'))
(OUT / 'g1_summary.json').write_text(json.dumps(summary, indent=1, default=str))
print(json.dumps(summary['duplicate_share']), json.dumps(summary['gate']))
