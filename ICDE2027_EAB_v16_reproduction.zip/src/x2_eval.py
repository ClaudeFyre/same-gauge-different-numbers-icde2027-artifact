"""X2 of PLAN_R3_EXTENSIONS.md (frozen 2026-11-07, md5 63d98013...): extreme-flow metrics from out/e4extremes/pred_*.npz.
Fixed before running: evaluation days = prediction days (365-day windows ending 1991..2009) with finite observations;
FHV (Yilmaz et al. 2008) = 100 * sum(S_h - O_h) / sum(O_h) over the top 2% of the separately sorted simulated and observed
flows; AMAX = median over calendar years with >= 300 observed days of |max p - max o| / max o; high-flow NSE on days with o >= the
basin's 90th percentile (descriptive). Basins with < 365 observed days are skipped (as for NSE)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import sys, json
from pathlib import Path
import numpy as np, pandas as pd
from scipy import stats
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0, str(ART / 'src'))
import e4s_load as L
OUT = (ART / 'out/e4extremes')
YEARS = pd.DatetimeIndex(L.DAYS)[365:].year.values

def metrics(p, o):
    m = np.isfinite(o)
    if m.sum() <= 365: return dict(fhv=np.nan, amax=np.nan, nse_hi=np.nan)
    pp, oo, yy = p[m], o[m], YEARS[m]; n = max(1, int(round(0.02 * len(oo))))
    sh, oh = np.sort(pp)[::-1][:n], np.sort(oo)[::-1][:n]
    fhv = 100 * (sh - oh).sum() / oh.sum() if oh.sum() > 0 else np.nan
    am = []
    for y in np.unique(yy):
        k = yy == y
        if k.sum() >= 300 and oo[k].max() > 0: am.append(abs(pp[k].max() - oo[k].max()) / oo[k].max())
    hi = oo >= np.percentile(oo, 90); oh2 = oo[hi]; ph = pp[hi]
    nse_hi = 1 - ((ph - oh2) ** 2).sum() / ((oh2 - oh2.mean()) ** 2).sum() if hi.sum() > 30 and oh2.std() > 0 else np.nan
    return dict(fhv=float(fhv), amax=float(np.median(am)) if am else np.nan, nse_hi=float(nse_hi))

if __name__ == '__main__':
    tags = sorted(p.stem[5:] for p in OUT.glob('pred_*.npz'))
    preds = {t: dict(np.load(OUT / f'pred_{t}.npz')) for t in tags}
    basins = sorted(set().union(*[set(v) for v in preds.values()]))
    with ProcessPoolExecutor(12) as ex: obs = {g: y[365:] for g, X, y in ex.map(L.load, basins, chunksize=20)}
    rows = [dict(tag=t, basin=g, **metrics(preds[t][g].astype(float), obs[g])) for t in tags for g in preds[t]]
    R = pd.DataFrame(rows); R.to_csv(OUT / 'x2_metrics.csv', index=False)
    S = {}
    for ctrl in ['M', 'U']:
        rec, neg, pooled = {'fhv': [], 'amax': []}, {'fhv': [], 'amax': []}, []
        for seed in range(1, 6):
            hc = json.load(open(OUT / f'has_copy_{seed}.json'))
            w = R[R.tag == f'W{seed}'].set_index('basin'); c = R[R.tag == f'{ctrl}{seed}'].set_index('basin')
            j = w.join(c, lsuffix='_w', rsuffix='_c').dropna(subset=['fhv_w', 'fhv_c'])
            d_f = j.fhv_c.abs() - j.fhv_w.abs(); d_a = j.amax_c - j.amax_w
            for g in j.index:
                (rec if hc.get(g) else neg)['fhv'].append((g, d_f[g])); (rec if hc.get(g) else neg)['amax'].append((g, d_a[g]))
            pooled.append(float(j.fhv_c.abs().median() - j.fhv_w.abs().median()))
        out = {}
        for k in ['fhv', 'amax']:
            df = pd.DataFrame(rec[k], columns=['basin', 'd']).dropna(); grp = {b: x.d.values for b, x in df.groupby('basin')}; keys = list(grp)
            rr = np.random.default_rng(0); boot = [np.median(np.concatenate([grp[keys[i]] for i in rr.integers(0, len(keys), len(keys))])) for _ in range(10000)]
            out[k] = dict(median=float(df.d.median()), ci=[float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))], n=len(df), basins=len(keys),
                          negative_control=float(pd.DataFrame(neg[k], columns=['b', 'd']).d.median()))
        p = np.array(pooled); h = stats.t.ppf(0.975, 4) * p.std(ddof=1) / np.sqrt(5)
        out['pooled_fhv'] = dict(per_seed=list(map(float, p)), mean=float(p.mean()), ci=[float(p.mean() - h), float(p.mean() + h)])
        S[ctrl] = out
    m = S['M']
    S['reading'] = dict(fhv='material' if (m['fhv']['median'] >= 5 and m['fhv']['ci'][0] > 0) else 'not material',
                        amax='material' if (m['amax']['median'] >= 0.05 and m['amax']['ci'][0] > 0) else 'not material')
    S['median_abs_fhv'] = {t: float(R[R.tag == t].fhv.abs().median()) for t in tags}
    json.dump(S, open(OUT / 'x2_summary.json', 'w'), indent=1); print(json.dumps(S, indent=1))
