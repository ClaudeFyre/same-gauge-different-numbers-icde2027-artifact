"""PLAN_E4_SPLITS.md (frozen 2026-10-20, md5 4135461d...): random vs lineage-aware basin splits.
Model/training/evaluation code identical to g3_lstm.py (copied unchanged); only the pool and split construction differ."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import sys, json, time, zipfile
from pathlib import Path
import numpy as np, pandas as pd, torch
from concurrent.futures import ProcessPoolExecutor
from scipy import stats
sys.path.insert(0, str(ART / 'src'))
import e4s_load as L

CAR = L.CAR; GZ = zipfile.ZipFile(L.GZP)
OUT = ART / 'out/e4splits'; OUT.mkdir(parents=True, exist_ok=True)
SUBS = ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']
FORC = L.FORC; ND = len(L.DAYS); dev = torch.device('cuda')

if __name__ == '__main__':
    t0 = time.time()
    stat = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_caravan_{s}.csv') for s in SUBS] +
                     [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_caravan_grdc.csv'))]).drop_duplicates('gauge_id').set_index('gauge_id')
    SCOLS = list(stat.columns)
    allids = sorted(stat.index)
    # ---- validity over the whole pool (cached)
    vf = OUT / 'valid.json'
    if vf.exists(): valid = set(json.load(open(vf)))
    else:
        valid = set()
        with ProcessPoolExecutor(12) as ex:
            for i, (g, ok) in enumerate(ex.map(L.validity, allids, chunksize=40)):
                if ok: valid.add(g)
                if i % 3000 == 0: print('validity', i, len(allids), round(time.time() - t0), 's', flush=True)
        json.dump(sorted(valid), open(vf, 'w'))
    print('valid basins', len(valid), 'of', len(allids), flush=True)
    # ---- lineage classes from G1 P1/P2 keyed pairs (union-find)
    g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv'); g1 = g1[g1.pair.str.startswith(('P1', 'P2'))]
    par = {}
    def find(x):
        par.setdefault(x, x)
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b in zip(g1.a, g1.b): par[find(a)] = find(b)
    cls = {}
    for g in sorted(valid): cls.setdefault(find(g), []).append(g)
    classes = sorted(cls.values(), key=lambda m: m[0])
    rng = np.random.default_rng(0)
    pick = [classes[i] for i in sorted(rng.choice(len(classes), 2500, replace=False))]
    basins = sorted(g for m in pick for g in m); cls_of = {g: i for i, m in enumerate(pick) for g in m}
    print('classes', len(classes), 'sampled basins', len(basins), 'multi-member classes', sum(len(m) > 1 for m in pick), flush=True)
    # ---- load data for sampled basins
    DATA = {}
    with ProcessPoolExecutor(12) as ex:
        for g, X, y in ex.map(L.load, basins, chunksize=20): DATA[g] = (X, y)
    print('loaded', len(DATA), round(time.time() - t0), 's', flush=True)

    class Net(torch.nn.Module):
        def __init__(s, nin):
            super().__init__(); s.lstm = torch.nn.LSTM(nin, 64, num_layers=2, batch_first=True); s.drop = torch.nn.Dropout(0.4); s.head = torch.nn.Linear(64, 1)
        def forward(s, x):
            o, _ = s.lstm(x); return s.head(s.drop(o[:, -1])).squeeze(-1)
    def build(ids):
        return np.stack([DATA[g][0] for g in ids]), np.stack([DATA[g][1] for g in ids]), stat.loc[ids, SCOLS].values.astype(np.float32)
    def run(train_ids, test_ids, seed, tag):
        torch.manual_seed(seed); r = np.random.default_rng(seed)
        X, Y, St = build(train_ids)
        xm, xs = np.nanmean(X, (0, 1)), np.nanstd(X, (0, 1)) + 1e-6
        sm, ss = np.nanmean(St, 0), np.nanstd(St, 0) + 1e-6
        ym, ysd = np.nanmean(Y), np.nanstd(Y); qstd = np.nanstd(Y, 1)
        Xn = np.nan_to_num((X - xm) / xs); Sn = np.nan_to_num((St - sm) / ss); Yn = (Y - ym) / ysd
        valid_w = np.array([(i, t) for i in range(len(train_ids)) for t in np.where(np.isfinite(Yn[i, 364:]))[0] + 364])
        Xg = torch.tensor(Xn, device=dev); Sg = torch.tensor(Sn, device=dev); Yg = torch.tensor(np.nan_to_num(Yn), device=dev)
        wg = torch.tensor(1 / (qstd / ysd + 0.1) ** 2, device=dev, dtype=torch.float32)
        net = Net(len(FORC) + len(SCOLS)).to(dev); opt = torch.optim.Adam(net.parameters(), 1e-3)
        ar = torch.arange(-364, 1, device=dev)
        for ep in range(15):
            net.train(); tl = 0
            for _ in range(800):
                b = valid_w[r.integers(0, len(valid_w), 256)]
                bi = torch.tensor(b[:, 0], device=dev); bt = torch.tensor(b[:, 1], device=dev)
                idx = bt[:, None] + ar[None, :]
                x = torch.cat([Xg[bi[:, None], idx], Sg[bi][:, None, :].expand(-1, 365, -1)], -1)
                loss = (wg[bi] * (net(x) - Yg[bi, bt]) ** 2).mean()
                opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); tl += loss.item()
        print(tag, 'trained', round(tl / 800, 4), round(time.time() - t0), 's', flush=True)
        del Xg, Yg; torch.cuda.empty_cache()
        net.eval(); out = {}
        Xt, Yt, Stt = build(test_ids)
        Xtn = torch.tensor(np.nan_to_num((Xt - xm) / xs), device=dev); Stn = torch.tensor(np.nan_to_num((Stt - sm) / ss), device=dev)
        with torch.no_grad():
            for i, g in enumerate(test_ids):
                ts = torch.arange(365, ND, device=dev); preds = []
                for c in range(0, len(ts), 2048):
                    tt = ts[c:c + 2048]; idx = tt[:, None] + ar[None, :]
                    x = torch.cat([Xtn[i][idx], Stn[i][None, None, :].expand(len(tt), 365, -1)], -1)
                    preds.append(net(x).cpu().numpy())
                p = np.concatenate(preds) * ysd + ym; o = Yt[i, 365:]; m = np.isfinite(o)
                out[g] = float(1 - ((p[m] - o[m]) ** 2).sum() / ((o[m] - o[m].mean()) ** 2).sum()) if m.sum() > 365 else np.nan
        return out

    res = json.load(open(OUT / 'nse.json')) if (OUT / 'nse.json').exists() else {}
    meta = {}
    for seed in range(1, 6):
        rb = np.random.default_rng(seed).permutation(basins); nte = int(round(0.2 * len(basins)))
        R_test, R_train = sorted(rb[:nte]), sorted(rb[nte:])
        rc = np.random.default_rng(seed + 100).permutation(len(pick)); ntc = int(round(0.2 * len(pick)))
        test_cls = set(rc[:ntc]); L_test = sorted(g for g in basins if cls_of[g] in test_cls); L_train = sorted(g for g in basins if cls_of[g] not in test_cls)
        trainR = set(R_train)
        has_copy = {g: any(h in trainR for h in pick[cls_of[g]] if h != g) for g in R_test}
        meta[seed] = dict(R_test=len(R_test), L_test=len(L_test), R_with_copy=int(sum(has_copy.values())), R_has_copy=has_copy)
        for tag, tr, te in [(f'R{seed}', R_train, R_test), (f'L{seed}', L_train, L_test)]:
            if tag in res: continue
            res[tag] = run(tr, te, seed, tag); json.dump(res, open(OUT / 'nse.json', 'w'))
    json.dump({k: {kk: vv for kk, vv in v.items() if kk != 'R_has_copy'} for k, v in meta.items()}, open(OUT / 'meta.json', 'w'), indent=1)
    rows, sec = [], []
    for seed in range(1, 6):
        R = pd.Series(res[f'R{seed}']); Lr = pd.Series(res[f'L{seed}'])
        rows.append(R.median() - Lr.median())
        hc = pd.Series(meta[seed]['R_has_copy'])
        sec.append(dict(seed=seed, R_med=R.median(), L_med=Lr.median(), R_med_with=R[hc[hc].index].median(), R_med_without=R[hc[~hc].index].median(),
                        share_with=hc.mean()))
    d = np.array(rows); m = d.mean(); h = stats.t.ppf(0.975, len(d) - 1) * d.std(ddof=1) / np.sqrt(len(d))
    summ = dict(delta_per_seed=list(map(float, d)), mean_delta=float(m), ci95=[float(m - h), float(m + h)],
                readout='random splits inflate the overall median NSE' if m - h > 0 else 'no detectable overall inflation',
                secondary=sec, n_basins=len(basins))
    json.dump(summ, open(OUT / 'summary.json', 'w'), indent=1, default=float)
    print(json.dumps(summ, indent=1, default=float))
