"""E5 (PLAN_E5_WEATHER.md, frozen 2026-11-06, md5 df8ab1bc1cdc822e92e46c3aa64f46ab): E1-W fidelity and E2-W attribution.
Implementation choices fixed BEFORE running (the plan leaves them open):
- Values are compared as published, in mm and degC; missing codes removed (GHCN -9999, DWD -999, ECA&D Q=9). QC flags
  (GHCN Q_FLAG non-blank, ECA&D Q=1, DWD QN) are kept and reported as a descriptive breakdown of divergent days, not a cause.
- Period 1951-01-01 .. 2025-12-31 for every pair.
- Repository pairs (a = downstream copy, b = upstream copy):
    key-linked:      GHCN(E-flag days) / ECA-nonblend  [RR TX TN];  ECA-blend / ECA-nonblend  [RR TX TN TG]
    metadata-linked: ECA-nonblend / DWD [RR TX TN TG];  GHCN(all days) / DWD [RR TX TN];  ECA-blend / DWD [RR TX TN TG]
  ECA-blend is paired with the station's selected non-blended source through the blend files' per-day SOUID column only
  when the STAID lists that SOUID (the blend series is a copy of several sources).
- RR uses Sec. III exactly (scale constant, IQR <= 0.01, tau = max(0.02|kb|, 2(h_a + k h_b)), +-1 day shift rule).
  TX/TN/TG use plan Sec. 4 (k = 1 after unit conversion, offset c = median(a-b), stable if |c| <= 0.05 and IQR(a-b-c) <= 0.1,
  tau = 2(h_a + h_b), +-1 day shift rule). q(x) = smallest positive difference between distinct values.
- E2-W attributes the union of divergent and shift-explained days (W1 = shift-explained) of stable pairs, tests in order
  W1 shift (+-1 d), W2 daily-mean formula (TG only), W3 blending (blend pairs only: the day's SOUID differs from the paired
  source), W4 edge localisation with the third copy of the triplet (DWD, ECA-nonblend, GHCN) or (DWD, ECA-nonblend, ECA-blend)
  for TG; placebo for W1: shifts +-2 and +-3 days applied to the same days.
"""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import sys, json, zipfile, gzip, io
from pathlib import Path
import numpy as np, pandas as pd
D = (ROOT / 'data/Expansion_2026-11-06/weather/series')
OUT = (ART / 'out/e5')
DAYS = pd.date_range('1951-01-01', '2025-12-31')
EL = ['RR', 'TX', 'TN', 'TG']

def ser(d):  # dict date->value to aligned float array
    s = pd.Series(d, dtype=float); s.index = pd.to_datetime(s.index, format='%Y%m%d'); return s.reindex(DAYS).values

def load_ghcn(g):
    df = pd.read_csv(D / 'ghcn' / f'{g}.csv.gz', header=None, names=['id', 'date', 'el', 'v', 'm', 'q', 's', 't'], dtype={'date': str, 'm': str, 'q': str, 's': str})
    out = {}
    for el, ge in [('RR', 'PRCP'), ('TX', 'TMAX'), ('TN', 'TMIN')]:
        x = df[(df.el == ge) & (df.v != -9999)]
        v = x.v / 10.0
        out[el] = dict(all=ser(dict(zip(x.date, v))), E=ser(dict(zip(x[x.s == 'E'].date, v[x.s == 'E']))),
                       q=ser(dict(zip(x.date, x.q.notna().astype(float)))), sflag=dict(x.s.value_counts()))
    return out

def load_dwd(zpath):
    z = zipfile.ZipFile(zpath); nm = [n for n in z.namelist() if n.startswith('produkt_klima_tag')][0]
    df = pd.read_csv(io.BytesIO(z.read(nm)), sep=';', skipinitialspace=True, dtype={'MESS_DATUM': str})
    df.columns = [c.strip() for c in df.columns]
    out = {}
    for el, c in [('RR', 'RSK'), ('TX', 'TXK'), ('TN', 'TNK'), ('TG', 'TMK')]:
        x = df[df[c] > -999]; out[el] = ser(dict(zip(x.MESS_DATUM, x[c])))
    return out

def load_eca(path, blend=False):
    lines = path.read_text(encoding='latin1').splitlines()
    i = next(k for k, l in enumerate(lines) if l.replace(' ', '').startswith(('SOUID,DATE', 'STAID,SOUID,DATE')))
    df = pd.read_csv(io.StringIO('\n'.join(lines[i:])), skipinitialspace=True, dtype=str)
    df.columns = [c.strip() for c in df.columns]
    vcol = [c for c in df.columns if c not in ('STAID', 'SOUID', 'DATE') and not c.startswith('Q_')][0]
    v = df[vcol].astype(float); q = df['Q_' + vcol].astype(int); keep = q != 9
    r = dict(v=ser(dict(zip(df.DATE[keep], v[keep] / 10.0))), q1=ser(dict(zip(df.DATE[keep], (q[keep] == 1).astype(float)))))
    if blend: r['sou'] = ser(dict(zip(df.DATE[keep], df.SOUID[keep].astype(float))))
    return r

def qstep(x):
    u = np.unique(np.round(x[np.isfinite(x)], 4)); d = np.diff(u); d = d[d > 1e-9]
    return float(d.min()) if len(d) else np.nan

def compare(a, b, el):
    m = np.isfinite(a) & np.isfinite(b); n = int(m.sum())
    res = dict(n=n)
    if n < 365: return res
    ha, hb = qstep(a) / 2, qstep(b) / 2
    if el == 'RR':
        p = m & (b > 0)
        if p.sum() < 365: return res
        k = float(np.median(a[p] / b[p])); r = a[p] / (k * b[p]); iqr = float(np.subtract(*np.percentile(r, [75, 25])))
        stable = iqr <= 0.01; kb = k * b; tau = np.maximum(0.02 * np.abs(kb), 2 * (ha + k * hb))
        res.update(k=k, iqr=iqr, stable=bool(stable))
    else:
        dd = a[m] - b[m]; c = float(np.median(dd)); iqr = float(np.subtract(*np.percentile(dd - c, [75, 25])))
        stable = abs(c) <= 0.05 and iqr <= 0.1; kb = b + c; tau = np.full(len(a), 2 * (ha + hb))
        res.update(c=c, iqr=iqr, stable=bool(stable))
    out = m & (np.abs(a - kb) > tau)
    def near(sh):
        s = np.roll(kb, sh); t = np.roll(tau, sh)
        return np.isfinite(s) & (np.abs(a - s) <= np.maximum(tau, t))
    shift = out & (near(1) | near(-1))
    div = out & ~shift
    res.update(div=div, shift=shift, out=out, kb=kb, tau=tau, n_div=int(div.sum()), n_shift=int(shift.sum()), placebo={s: out & (near(s) | near(-s)) for s in (2, 3)})
    return res

if __name__ == '__main__':
    plan = json.load(open(OUT / 'fetch_plan.json')); sel = pd.read_csv(OUT / 'selection.csv'); sel = sel[sel.ghcn.isin(plan['ghcn'])]
    dwdfiles = {p.name.split('_')[2]: p for p in (D / 'dwd').glob('*.zip')}
    # SOUID -> STAIDs whose blended series list that source (from the blended source tables; metadata only)
    MD = (ROOT / 'data/Expansion_2026-11-06/weather/meta'); BLEND_OF = {}
    for el_ in EL:
        for l in open(MD / f'ECA_blend_source_{el_.lower()}.txt', encoding='latin1'):
            q_ = l.split(',')
            if len(q_) > 10 and q_[0].strip().isdigit() and q_[1].strip().isdigit():
                BLEND_OF.setdefault((el_, int(q_[1])), set()).add(int(q_[0]))
    rows, attrib = [], []
    for g in plan['ghcn']:
        s = sel[sel.ghcn == g]; dwd_id = str(int(s[s.el == 'TX'].dwd.iloc[0])).zfill(5)
        if dwd_id not in dwdfiles: continue
        G = load_ghcn(g); W = load_dwd(dwdfiles[dwd_id])
        for el in EL:
            sou = int(s[s.el == el].souid.iloc[0]) if el != 'TG' else plan['tg'].get(g)
            if sou is None: continue
            pn = D / 'eca_nonblend' / f'{el}_SOUID{sou}.txt'
            if not pn.exists(): continue
            N = load_eca(pn)
            B = None
            for st in sorted(BLEND_OF.get((el, sou), [])):
                pb = D / 'eca_blend' / f'{el}_STAID{st:06d}.txt'
                if pb.exists(): B = load_eca(pb, blend=True); break
            copies = dict(DWD=W[el], NB=N['v'])
            if el != 'TG': copies.update(GHCN_E=G[el]['E'], GHCN=G[el]['all'])
            if B is not None: copies['BL'] = B['v']
            pairs = [('GHCN_E', 'NB', 'key'), ('BL', 'NB', 'key'), ('NB', 'DWD', 'meta'), ('GHCN', 'DWD', 'meta'), ('BL', 'DWD', 'meta')]
            for an, bn, lk in pairs:
                if an not in copies or bn not in copies: continue
                r = compare(copies[an], copies[bn], el)
                row = dict(station=g, el=el, a=an, b=bn, link=lk, **{k: v for k, v in r.items() if k in ('n', 'k', 'c', 'iqr', 'stable', 'n_div', 'n_shift')})
                rows.append(row)
                if not r.get('stable') or 'out' not in r: continue
                # ---- E2-W attribution on divergent + shift-explained days
                U = r['out']; cause = np.full(len(U), '', dtype=object)
                cause[r['shift']] = 'W1 shift'
                if el == 'TG' and 'DWD' in (an, bn):
                    txn = (W['TX'] + W['TN']) / 2
                    other = copies[an] if bn == 'DWD' else copies[bn]
                    w2 = U & (cause == '') & (np.abs(other - txn) <= r['tau'])
                    cause[w2] = 'W2 (TX+TN)/2'
                if an == 'BL' and B is not None:
                    w3 = U & (cause == '') & np.isfinite(B['sou']) & (B['sou'] != sou)
                    cause[w3] = 'W3 blending'
                third = {('GHCN_E', 'NB'): 'DWD', ('GHCN', 'DWD'): 'NB', ('NB', 'DWD'): 'GHCN' if el != 'TG' else 'BL', ('BL', 'NB'): 'DWD', ('BL', 'DWD'): 'NB'}[(an, bn)]
                if third in copies:
                    c3 = copies[third]
                    tol = r['tau'] + (0.05 if el != 'RR' else 0)
                    agree_a = np.abs(copies[an] - c3) <= np.maximum(tol, 0.02 * np.abs(c3)) if el == 'RR' else np.abs(copies[an] - c3) <= tol
                    agree_b = np.abs(copies[bn] - c3) <= np.maximum(tol, 0.02 * np.abs(c3)) if el == 'RR' else np.abs(copies[bn] - c3) <= tol
                    w4a = U & (cause == '') & np.isfinite(c3) & agree_b & ~agree_a
                    w4b = U & (cause == '') & np.isfinite(c3) & agree_a & ~agree_b
                    cause[w4a] = f'W4 edge into {an}'; cause[w4b] = f'W4 edge into {bn}'
                cause[U & (cause == '')] = 'unresolved'
                yrs = DAYS.year.values
                for cz in np.unique(cause[U]):
                    msk = U & (cause == cz)
                    attrib.append(dict(station=g, el=el, a=an, b=bn, link=lk, cause=cz, days=int(msk.sum()),
                                       pre2001=int((msk & (DAYS < '2001-04-01')).sum())))
                for sp in (2, 3):
                    attrib.append(dict(station=g, el=el, a=an, b=bn, link=lk, cause=f'placebo +-{sp}d', days=int((U & r['placebo'][sp] & ~r['shift']).sum() + 0), pre2001=0))
        print('done', g, len(rows), flush=True)
    R = pd.DataFrame(rows); A = pd.DataFrame(attrib)
    R.to_csv(OUT / 'e5_pairs.csv', index=False); A.to_csv(OUT / 'e5_attrib.csv', index=False)
    # ---- summaries per (pair, element)
    summ = []
    for (an, bn, lk, el), x in R.groupby(['a', 'b', 'link', 'el']):
        st = x[x.stable == True]; ov = st.n.sum()
        summ.append(dict(a=an, b=bn, link=lk, el=el, pairs=len(x[x.n >= 365]), stable=len(st), overlap_days=int(ov),
                         rate=float(st.n_div.sum() / ov) if ov else np.nan, shift_share=float(st.n_shift.sum() / max(1, st.n_div.sum() + st.n_shift.sum())),
                         gauges_ge1=float((st.n_div / st.n >= 0.01).mean()) if len(st) else np.nan,
                         low=float(st.n_div.sum() / x[x.n >= 365].n.sum()) if len(x[x.n >= 365]) else np.nan))
    S = pd.DataFrame(summ); S.to_csv(OUT / 'e5_summary.csv', index=False)
    print(S.to_string())
