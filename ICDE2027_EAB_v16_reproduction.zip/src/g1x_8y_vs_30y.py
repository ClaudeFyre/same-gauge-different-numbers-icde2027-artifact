"""Exploratory (not a gate): GlobalRiverWSE 8y vs 30y file, same provider-station, VT/NH + all USGS/GRDC common ids."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, zipfile, numpy as np, pandas as pd
src = open(ART / 'src/g1.py', encoding='utf-8').read().split('# ---------- loaders')[0]
exec(compile(src, 'g1', 'exec'))
z = zipfile.ZipFile(GWSE)
def load(name):
    d = {}
    for r in stream_array(z.open(f'Result datasets/Validation dataset/globe_gauge_discharge_data_{name}.json')):
        d[(str(r['agency']), str(r['id']))] = pd.Series(np.asarray(r['discharge'], float), index=pd.to_datetime(r['time']))
    return d
a, b = load('8y'), load('30y')
vtnh = set(pd.read_parquet(ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet').site.astype(str))
rows = []
for key in set(a) & set(b):
    r = compare(a[key], b[key])
    if r is None: continue
    rows.append(dict(agency=key[0], id=key[1], vtnh=key[1] in vtnh, n=r['n'], k=r['k'], iqr=r['iqr'], real=r['real']))
d = pd.DataFrame(rows); d.to_csv(OUT / 'g1x_8y_vs_30y.csv', index=False)
d['rate'] = d.real / d.n
print(d.groupby(['agency', 'vtnh']).agg(gauges=('id', 'size'), k_med=('k', 'median'), pooled=('real', 'sum'), n=('n', 'sum'), med_rate=('rate', 'median')).assign(pooled_rate=lambda x: x.pooled / x.n))
