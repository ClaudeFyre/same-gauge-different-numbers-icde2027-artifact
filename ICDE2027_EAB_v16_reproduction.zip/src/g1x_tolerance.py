"""Descriptive sensitivity of E1 divergence rates to the tolerance (NOT a gate; the frozen tau stays the reported value).
For every scale-stable copy pair (G1 definition), count non-shift divergent days under:
  floor in {1%, 2% (frozen), 5%, 10%} with the rounding term, and 'naive 2%' without the rounding term.
Also writes the per-pair results so figures can be drawn."""
import json, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART
import numpy as np, pandas as pd
src = open(ART / 'src/g1.py', encoding='utf-8').read().split('# P4/P5')[0]
G = {'__file__': __file__}; exec(compile(src, 'g1', 'exec'), G)
caravan, grdc, lamah, qstep, ROOT, OUT = G['caravan'], G['grdc'], G['lamah'], G['qstep'], G['ROOT'], G['OUT']
src2 = open(ART / 'src/g1.py', encoding='utf-8').read()
loaders = src2[src2.index('# P4/P5'):src2.index('summary, rows = {}, []')]
exec(compile(loaders, 'g1b', 'exec'), G)
pairs, load = G['pairs'], G['load']
FLOORS = [('f01', 0.01, True), ('f02', 0.02, True), ('f05', 0.05, True), ('f10', 0.10, True), ('naive02', 0.02, False)]

def rates(a, b):
    j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna()
    if len(j) < 365: return None
    pos = j[j.b > 0]
    if len(pos) < 30: return None
    k = float((pos.a / pos.b).median())
    if not np.isfinite(k) or k <= 0: return None
    rr = pos.a / (k * pos.b)
    if rr.quantile(.75) - rr.quantile(.25) > 0.01: return None   # scale-unstable: excluded as in G1
    ha, hb = qstep(j.a.values) / 2, qstep(j.b.values) / 2
    kb = k * j.b
    bfull = b.reindex(pd.date_range(j.index.min() - pd.Timedelta(days=1), j.index.max() + pd.Timedelta(days=1)))
    sh = [k * bfull.shift(L).reindex(j.index) for L in (-1, 1)]
    out = dict(n=len(j))
    for name, f, rnd in FLOORS:
        tau = np.maximum(f * kb.abs(), 2 * (ha + k * hb)) if rnd else f * kb.abs()
        div = (j.a - kb).abs() > tau
        ok_shift = np.zeros(len(j), bool)
        for s in sh: ok_shift |= ((j.a - s).abs() <= tau).fillna(False).values
        out[name] = int((div.values & ~ok_shift).sum())
    return out

rows = []
for pname, lst in pairs.items():
    for a_id, b_id in lst:
        a, b = load(pname, a_id, 'a'), load(pname, b_id, 'b')
        if a is None or b is None: continue
        r = rates(a, b)
        if r is None: continue
        rows.append(dict(pair=pname, a=str(a_id), b=str(b_id), **r))
    print(pname, 'done', flush=True)
D = pd.DataFrame(rows); D.to_csv(OUT / 'g1x_tolerance_pairs.csv', index=False)
S = D.groupby('pair')[[f for f, _, _ in FLOORS] + ['n']].sum()
for f, _, _ in FLOORS: S[f] = S[f] / S['n']
S.to_csv(OUT / 'g1x_tolerance_summary.csv'); print(S.round(4))
