"""PLAN_E3_VERIFY.md (frozen 2026-10-20, md5 8a181f0e...): metadata-only verification of E3 negatives that rules call copies,
and precision/recall bounds under incomplete truth. Rules R1-R4 applied mechanically in order."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import json, re, ast, math, sys, time, urllib.request, zipfile, pickle
from pathlib import Path
import numpy as np, pandas as pd
from pyproj import Transformer

R = ROOT; P = ART; OUT = P / 'out/e3verify'; OUT.mkdir(parents=True, exist_ok=True)
CAR = R / 'data/Caravan/extracted/Caravan-nc/attributes'
gz = zipfile.ZipFile(R / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip')
lab = pd.read_csv(ART / 'labels/discovery_pairs.csv', low_memory=False, dtype={'id_a': str, 'id_b': str})
neg = lab[lab.label == 0].copy()
rules = [f'rule_M{i}_unperturbed' for i in range(5)]
scope = neg[neg.flag_subkm_unmatched_key | neg.flag_near_identical_series | neg[rules].any(axis=1)].copy()
assert len(scope) == 581, len(scope)   # count fixed in the plan

# ---------------- metadata
car = pd.concat([pd.read_csv(CAR / f'{s}/attributes_other_{s}.csv') for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']]).set_index('gauge_id')
go = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv')).set_index('gauge_id')
ga = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_additional_grdc.csv')).set_index('gauge_id')
la = pd.read_csv(R / 'icde_probe/raw/lamah/D_gauges/1_attributes/Gauge_attributes.csv', sep=';').set_index('ID')

def usgs_id(repo, i):
    if repo == 'gwse_usgs': return i.split('_', 1)[1]
    if repo in ('car_camels', 'car_hysets'):
        s = i.split('_', 1)[1]
        return s if s.isdigit() and len(s) >= 8 else None
    return None
usgs = sorted({u for r, i in list(zip(scope.repo_a, scope.id_a)) + list(zip(scope.repo_b, scope.id_b)) if (u := usgs_id(r, i))})
nwis = {}
# 2026-10-26: reuse the shipped site list unless --refetch (a clean-clone run hit transient NWIS failures that the
# original loop swallowed); a failed batch now aborts instead of silently dropping sites.
if '--refetch' not in sys.argv and (OUT / 'nwis_sites.json').exists():
    nwis = json.load(open(OUT / 'nwis_sites.json'))
for k in (range(0, len(usgs), 100) if not nwis else []):
    url = 'https://waterservices.usgs.gov/nwis/site/?format=rdb&siteOutput=expanded&siteStatus=all&sites=' + ','.join(usgs[k:k + 100])
    for attempt in range(3):
        try:
            txt = urllib.request.urlopen(url, timeout=120).read().decode('utf-8', 'replace'); break
        except Exception as e:
            txt = ''; time.sleep(10 * (attempt + 1))
    if not txt: sys.exit(f'NWIS batch {k} failed after 3 attempts; rerun later')
    lines = [l for l in txt.split('\n') if l and not l.startswith('#')]
    if len(lines) > 2:
        cols = lines[0].split('\t')
        for l in lines[2:]:
            r = dict(zip(cols, l.split('\t')))
            try: area = float(r.get('drain_area_va', '')) * 2.58999
            except ValueError: area = np.nan
            nwis[r['site_no']] = dict(name=r.get('station_nm', ''), area=area)
    time.sleep(1)
if '--refetch' in sys.argv or not (OUT / 'nwis_sites.json').exists(): json.dump(nwis, open(OUT / 'nwis_sites.json', 'w'), indent=0)
print('USGS ids', len(usgs), 'NWIS records', len(nwis), flush=True)

grdc_nat = ga['nat_id'].astype(str).to_dict()
def side(repo, i):
    """name, river, area_km2, national id"""
    name = river = None; area = np.nan; nat = None
    if repo.startswith('car_'):
        if i in car.index: name, area = str(car.loc[i, 'gauge_name']), float(car.loc[i, 'area'])
        nat = i.split('_', 1)[1]
    elif repo == 'grdc_caravan':
        if i in go.index: name, area = str(go.loc[i, 'gauge_name']), float(go.loc[i, 'area'])
        nat = grdc_nat.get(i)
    elif repo == 'lamah_ce':
        j = int(float(i)); name, river, area = str(la.loc[j, 'name']), str(la.loc[j, 'river']), float(la.loc[j, 'area_gov']); nat = str(la.loc[j, 'govnr'])
    elif repo == 'gwse_grdc':
        g = 'GRDC_' + i.split('_', 1)[1]
        if g in go.index: name, area = str(go.loc[g, 'gauge_name']), float(go.loc[g, 'area']); nat = grdc_nat.get(g)
        else: nat = i.split('_', 1)[1]
    elif repo == 'gwse_usgs':
        nat = i.split('_', 1)[1]
    u = usgs_id(repo, i)
    if u and u in nwis:
        name = nwis[u]['name'] or name
        if np.isfinite(nwis[u]['area']): area = nwis[u]['area']
    return name, river, area, nat, (u in nwis) if u else False

BOIL = {'river', 'at', 'near', 'nr', 'bei', 'rio', 'ribeirao', 'creek', 'ck', 'r'}
STATES = {'al', 'ak', 'az', 'ar', 'ca', 'co', 'ct', 'de', 'fl', 'ga', 'hi', 'id', 'il', 'in', 'ia', 'ks', 'ky', 'la', 'me', 'md', 'ma', 'mi', 'mn', 'ms', 'mo',
          'mt', 'ne', 'nv', 'nh', 'nj', 'nm', 'ny', 'nc', 'nd', 'oh', 'ok', 'or', 'pa', 'ri', 'sc', 'sd', 'tn', 'tx', 'ut', 'vt', 'va', 'wa', 'wv', 'wi', 'wy',
          'alabama', 'alaska', 'arizona', 'arkansas', 'california', 'colorado', 'connecticut', 'delaware', 'florida', 'georgia', 'hawaii', 'idaho',
          'illinois', 'indiana', 'iowa', 'kansas', 'kentucky', 'louisiana', 'maine', 'maryland', 'massachusetts', 'michigan', 'minnesota', 'mississippi',
          'missouri', 'montana', 'nebraska', 'nevada', 'hampshire', 'jersey', 'mexico', 'york', 'carolina', 'dakota', 'ohio', 'oklahoma', 'oregon',
          'pennsylvania', 'rhode', 'island', 'tennessee', 'texas', 'utah', 'vermont', 'virginia', 'washington', 'wisconsin', 'wyoming', 'new', 'north',
          'south', 'west', 'brazil', 'australia', 'austria', 'germany', 'czech', 'switzerland', 'canada', 'qc', 'on', 'bc', 'ab', 'nb', 'ns'}
def toks(s):
    if not s or s == 'nan': return []
    t = re.sub(r'[^a-z0-9 ]', ' ', s.lower()).split()
    return [w for w in t if w not in BOIL and w not in STATES]
def namematch(a, b):
    ta, tb = toks(a), toks(b)
    if not ta or not tb: return None
    sa, sb = set(ta), set(tb)
    if len(sa & sb) >= 0.5 * min(len(sa), len(sb)): return True
    ja, jb = ' '.join(ta), ' '.join(tb)
    return ja in jb or jb in ja
def normid(x):
    return re.sub(r'[^A-Z0-9]', '', str(x).upper()).lstrip('0') if x is not None else None

rows = []
for _, r in scope.iterrows():
    na, ra, aa, xa, ua = side(r.repo_a, r.id_a); nb, rb, ab, xb, ub = side(r.repo_b, r.id_b)
    d = float(r.dist_km)
    A = max(aa, ab) / min(aa, ab) if (np.isfinite(aa) and np.isfinite(ab) and min(aa, ab) > 0) else np.nan
    full_a = ' '.join(x for x in [na, ra] if x); full_b = ' '.join(x for x in [nb, rb] if x)
    N = namematch(full_a, full_b)
    if xa and xb and normid(xa) == normid(xb) and d < 1: rule = 'R1'
    elif d < 1 and N is True and (not np.isfinite(A) or A <= 1.05): rule = 'R2'
    elif (np.isfinite(A) and A > 1.10) or (d >= 5 and N is False) or (ua and ub and normid(xa) != normid(xb) and N is False): rule = 'R3'
    else: rule = 'R4'
    rows.append(dict(region=r.region, repo_a=r.repo_a, id_a=r.id_a, repo_b=r.repo_b, id_b=r.id_b, dist_km=d, name_a=na, name_b=nb,
                     area_a=aa, area_b=ab, area_ratio=A, name_match=N, natid_a=xa, natid_b=xb, rule=rule,
                     subkm=r.flag_subkm_unmatched_key, near_identical=r.flag_near_identical_series, **{m: r[m] for m in rules}))
V = pd.DataFrame(rows); V.to_csv(OUT / 'verify_pairs.csv', index=False)
print(V.rule.value_counts().to_dict(), flush=True)
# spot-check sample for the authors (30 per group, seed 0)
grp = {'copy (R1/R2)': V[V.rule.isin(['R1', 'R2'])], 'non-copy (R3)': V[V.rule == 'R3'], 'unresolved (R4)': V[V.rule == 'R4']}
pd.concat([g.sample(min(30, len(g)), random_state=0).assign(group=k) for k, g in grp.items()]).to_csv(OUT / 'spotcheck_sample.csv', index=False)

# ---------------- precision/recall bounds on all classes (g2 rows), relabelling verified pairs
G = pd.read_parquet(P / 'out/g2/g2_rows.parquet')
meta = pickle.load(open(P / 'cache/g2_meta.pkl', 'rb'))['meta']
def nodekey(repo, i):
    kind = 'car' if repo.startswith('car_') else 'grdc' if repo == 'grdc_caravan' else 'lamah' if repo == 'lamah_ce' else 'gwse'
    return str((kind, int(float(i)) if kind == 'lamah' else i))
V['ka'] = [nodekey(a, b) for a, b in zip(V.repo_a, V.id_a)]; V['kb'] = [nodekey(a, b) for a, b in zip(V.repo_b, V.id_b)]
copy_set = set(zip(V[V.rule.isin(['R1', 'R2'])].ka, V[V.rule.isin(['R1', 'R2'])].kb))
unres_set = set(zip(V[V.rule == 'R4'].ka, V[V.rule == 'R4'].kb))
assert set(zip(V.ka, V.kb)) <= set(zip(G.a, G.b)), 'scope pairs must exist in g2 rows'
res = {}
for c in ['c1', 'c2', 'c3', 'c4', 'c5']:
    D = G[G.cls == c].copy(); key = list(zip(D.a, D.b))
    is_copy = pd.Series([k in copy_set for k in key], index=D.index); is_unres = pd.Series([k in unres_set for k in key], index=D.index)
    for bound, lab_ in [('lower', (D.label == 1) | is_copy), ('upper', (D.label == 1) | is_copy | is_unres)]:
        for m in ['M0', 'M1', 'M2', 'M3', 'M4']:
            tp = int((D[m] & lab_).sum()); fp = int((D[m] & ~lab_).sum()); Pn = int(lab_.sum())
            res.setdefault(c, {}).setdefault(m, {})[bound] = dict(precision=tp / (tp + fp) if tp + fp else None, recall=tp / Pn, tp=tp, fp=fp)
reach_low = [(c, m) for c in res for m in res[c] if (res[c][m]['lower']['precision'] or 0) >= 0.99]
reach_up = [(c, m) for c in res for m in res[c] if (res[c][m]['upper']['precision'] or 0) >= 0.99]
verdict = ('the original E3 conclusion does not hold for ' + str(reach_low)) if reach_low else \
          ('the gap may be an artefact of label incompleteness; truth-dependent: ' + str(reach_up)) if reach_up else \
          'the precision gap is robust to label incompleteness'
summ = dict(counts=V.rule.value_counts().to_dict(), by_region=V.groupby(['region', 'rule']).size().unstack(fill_value=0).to_dict('index'),
            nwis_records=len(nwis), usgs_ids=len(usgs), bounds=res, reach_lower=reach_low, reach_upper=reach_up, verdict=verdict)
json.dump(summ, open(OUT / 'summary.json', 'w'), indent=1, default=float)
print(json.dumps(dict(counts=summ['counts'], verdict=verdict), default=float))
for c in res: print(c, {m: (round(res[c][m]['lower']['precision'], 3), round(res[c][m]['upper']['precision'], 3)) for m in res[c] if res[c][m]['lower']['precision'] is not None})
