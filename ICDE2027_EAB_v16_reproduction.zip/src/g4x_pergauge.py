"""Per-gauge share of divergent days reproduced by the shifted (-1 h) window, on the same fixed 25-gauge sample as g4x_checks.py
(descriptive; answers whether 80.7% is driven by a few gauges)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import json, numpy as np, pandas as pd, warnings
from pathlib import Path
warnings.filterwarnings('ignore')
s = open(ART / 'src/g4.py', encoding='utf-8').read()
exec(compile(s.split('rows, unstable = [], []')[0], 'g4', 'exec'), globals())
D = pd.read_parquet(OUT / 'g4_days.parquet'); D['day'] = pd.to_datetime(D['day'])
P3 = D[D.chain == 'LamaH-P3']
gauges = pd.Series(P3.b.unique()).sample(25, random_state=0).tolist()   # identical sample to g4x_checks.py
rows = []
for b_id in gauges:
    a = caravan(P3[P3.b == b_id].a.iloc[0])
    d = pd.read_csv(Path(HOURLY[0]) / f'ID_{b_id}.csv', sep=';')
    q = pd.Series(d.qobs.values.astype(float), index=pd.to_datetime(dict(year=d.YYYY, month=d.MM, day=d.DD, hour=d.hh, minute=d.mm))); q[q < 0] = np.nan
    days = pd.DatetimeIndex(P3[P3.b == b_id].day)
    m = match(a, q.copy().set_axis(q.index + pd.Timedelta(hours=1)).resample('D').mean())
    rows.append(dict(gauge=b_id, div_days=len(days), share=float(m.reindex(days).fillna(False).mean()) if m is not None else np.nan))
G = pd.DataFrame(rows); G.to_csv(OUT / 'g4x_pergauge.csv', index=False)
pooled = (G.share * G.div_days).sum() / G.div_days.sum()
out = dict(n=len(G), pooled=pooled, median=G.share.median(), q25=G.share.quantile(.25), q75=G.share.quantile(.75), min=G.share.min(),
           ge50=int((G.share >= 0.5).sum()), top5_share_of_days=float(G.sort_values('div_days', ascending=False).head(5).div_days.sum() / G.div_days.sum()))
json.dump(out, open(OUT / 'g4x_pergauge.json', 'w'), indent=1); print(out)
