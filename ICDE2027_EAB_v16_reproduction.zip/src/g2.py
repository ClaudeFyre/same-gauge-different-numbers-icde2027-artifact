"""G2 ID-free discovery per PLAN_G1_G4.md (frozen). Implementation choices fixed BEFORE running (not in the plan text):
- M0..M4 are binary rules; "recall at precision >= 0.99" := recall if the rule's precision >= 0.99, else 0 (rule cannot operate there).
- Primary evaluation pools all four regions per class; per-region numbers are reported, not used for the verdict.
- Positives = G1 compared copy pairs within a region (P1, P2-*, P3, P4, P5; Canada/other countries outside the 4 regions dropped).
  Classes: c1 stable & G1 rate<5% (as is); c2 = c1 with copy a rounded to 2 significant digits; c3 = c1 with a truncated to a
  random contiguous 40% window; c4 stable & rate>=5% (as is); c5 = c1 with a's names removed and coordinates jittered 0-5 km.
  Unstable positives = c6, reported only. Negatives get the same perturbation of their a-side as the class.
- Negatives: cross-repository pairs with repository combinations that occur among the region's positives and different lineage
  class (lineage = national id, unioned through GRDC nat_id). Hard: < 50 km and Pearson r >= 0.9 (>= 365 overlap days), plus
  LamaH NEXTDOWNID neighbours. Easy: random, min(100 x positives, 50,000) per region, seed 0.
- Minimum overlap for any rule: 30 days (else no match). k = median(a/b) on b>0.
- M2 metadata score = mean of available components among {JW distance of river names, JW distance of station names,
  min(dist_km/10, 1)}; candidate if < 0.25; then R^2 >= 0.90 => identical (0.90-0.99 band counted identical, no visual step).
- M3: round a and k*b to the coarser grid g = max(step_a, k*step_b); match iff every overlap day is equal.
- M4: share of overlap days with |a-kb| <= tau (G1 tau) >= 0.9.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, json, zipfile, math, random
from pathlib import Path
import numpy as np, pandas as pd, xarray as xr
from scipy.spatial import cKDTree
from pyproj import Transformer

CAR = ROOT / 'data/Caravan/extracted/Caravan-nc'
GZIP = ROOT / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip'
LAMAH = ROOT / 'icde_probe/raw/lamah'
GWSE = ROOT / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip'
OUT = ART / 'out/g2'; OUT.mkdir(parents=True, exist_ok=True)
from _stream import stream_array

T0 = pd.Timestamp('1950-01-01'); IDX = pd.date_range(T0, '2024-12-31'); ND = len(IDX)
def to_arr(s):
    a = np.full(ND, np.nan, np.float32)
    s = s[(s.index >= T0) & (s.index <= IDX[-1])]
    a[(s.index - T0).days.values] = s.values.astype(np.float32)
    return a

REG_BOX = {'US': (24, 50, -125, -66), 'EU': (44, 52, 5, 25), 'BR': (-34, 6, -75, -34), 'AU': (-45, -10, 110, 155)}
def region_of(lat, lon):
    for r, (a, b, c, d) in REG_BOX.items():
        if a <= lat <= b and c <= lon <= d: return r
    return None

def norm(s): return str(s).strip().upper().lstrip('0')

# ---------------- metadata + series
meta = {}   # node -> dict(repo, lat, lon, area, name, river, lineage, region)
ser = {}
def split_name(n):
    if not isinstance(n, str): return None, None
    for sep in [' at ', ' near ', ' below ', ' above ', ' bei ', ', ']:
        if sep in n.lower():
            i = n.lower().index(sep); return n[:i].strip().lower(), n[i + len(sep):].strip().lower()
    return None, n.strip().lower()

core_att = {}
for s in ['camels', 'camelsaus', 'camelsbr', 'hysets', 'lamah']:
    a = pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv'); core_att[s] = a
lin_prefix = {'camels': 'US', 'hysets': None, 'camelsaus': 'AU', 'camelsbr': 'BR', 'lamah': 'LA'}

def add(node, repo, lat, lon, area, name, lineage, river=None):
    reg = region_of(lat, lon)
    if reg is None: return False
    r0, st = split_name(name)
    meta[node] = dict(repo=repo, lat=lat, lon=lon, area=area, river=river if river else r0, station=st, lineage=lineage, region=reg)
    return True

vtnh = set(pd.read_parquet(ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet').site.astype(str))
for s, a in core_att.items():
    for _, r in a.iterrows():
        gid = r.gauge_id; code = gid.split('_', 1)[1]
        if s == 'hysets':
            if r.country != 'United States of America': continue
            lin = 'US:' + norm(code)
        else:
            lin = f'{lin_prefix[s]}:' + norm(code)
        if lin.startswith('US:') and code in vtnh: continue
        add(('car', gid), 'car_' + s, r.gauge_lat, r.gauge_lon, r.area, r.gauge_name, lin)

gz = zipfile.ZipFile(GZIP)
gadd = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_additional_grdc.csv'))
goth = pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv')).set_index('gauge_id')
cty_pref = {'US': 'US', 'BR': 'BR', 'AU': 'AU'}
lamah_cty = {'AT', 'DE', 'CZ', 'CH', 'IT', 'SI', 'HU', 'SK', 'LI'}
grdc_lin = {}
for _, r in gadd.iterrows():
    num = r.gauge_id.split('_', 1)[1]
    pre = cty_pref.get(r.country, 'LA' if r.country in lamah_cty else None)
    lin = f'{pre}:' + norm(r.nat_id) if (pre and isinstance(r.nat_id, str)) else 'GRDC:' + num
    if r.country == 'US' and isinstance(r.nat_id, str) and r.nat_id in vtnh: continue
    grdc_lin[num] = lin
    if r.gauge_id not in goth.index: continue
    o = goth.loc[r.gauge_id]
    nm = o.gauge_name if isinstance(o.gauge_name, str) else ''
    riv, st = (nm.split(',', 1) + [''])[:2] if ',' in nm else (None, nm)
    if add(('grdc', r.gauge_id), 'grdc_caravan', o.gauge_lat, o.gauge_lon, o.area, None, lin, river=(riv or '').strip().lower() or None):
        meta[('grdc', r.gauge_id)]['station'] = st.strip().lower() or None

lat_att = pd.read_csv(LAMAH / 'D_gauges/1_attributes/Gauge_attributes.csv', sep=';')
tr = Transformer.from_crs('EPSG:3035', 'EPSG:4326', always_xy=True)
for _, r in lat_att.iterrows():
    lon, lat = tr.transform(r.lon, r.lat)
    add(('lamah', int(r.ID)), 'lamah_ce', lat, lon, r.area_gov, None, 'LA:' + norm(r.govnr), river=str(r.river).lower())
    if ('lamah', int(r.ID)) in meta: meta[('lamah', int(r.ID))]['station'] = str(r['name']).lower()

print('metadata nodes', len(meta), flush=True)

import pickle
_c = pickle.load(open(ART / 'cache/g2_meta.pkl', 'rb'))
_arr = np.load(ART / 'cache/g2_series.npy', mmap_mode='r')
meta = _c['meta']; ser = {k: _arr[i] for i, k in enumerate(_c['keys'])}
print('series', len(ser), flush=True)

# ---------------- positives from G1
g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv')
g1['rate'] = g1.real / g1.n
def node_a(p, a):
    if p.startswith(('P4', 'P5')):
        t = eval(a); return ('gwse', f'{t[0]}_{t[1]}')
    if p.startswith('P2'): return ('grdc', a)
    return ('car', a)
def node_b(p, b):
    if p.startswith('P4'): return ('grdc', b)
    if p.startswith('P3'): return ('lamah', int(b))
    return ('car', b)
pos = []
for _, r in g1.iterrows():
    na, nb = node_a(r.pair, r.a), node_b(r.pair, r.b)
    if na not in ser or nb not in ser: continue
    if meta[na]['region'] != meta[nb]['region']: continue
    cls = 'c6' if not r.stable else ('c4' if r.rate >= 0.05 else 'c1')
    pos.append((na, nb, cls, r.pair))
print('positives', len(pos), pd.Series([p[2] for p in pos]).value_counts().to_dict(), flush=True)

# ---------------- array helpers
def qstep(x):
    u = np.unique(x[np.isfinite(x)]); d = np.diff(u); d = d[d > 0]
    return float(d.min()) if len(d) else 0.0
def pearson(a, b, minov=30):
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() < minov: return np.nan, int(m.sum())
    x, y = a[m].astype(float), b[m].astype(float)
    if x.std() == 0 or y.std() == 0: return np.nan, int(m.sum())
    return float(np.corrcoef(x, y)[0, 1]), int(m.sum())

def jw(s1, s2):
    if not s1 or not s2: return None
    if s1 == s2: return 1.0
    l1, l2 = len(s1), len(s2); md = max(l1, l2) // 2 - 1
    f1, f2 = [False] * l1, [False] * l2; mt = 0
    for i, c in enumerate(s1):
        for j in range(max(0, i - md), min(l2, i + md + 1)):
            if not f2[j] and s2[j] == c: f1[i] = f2[j] = True; mt += 1; break
    if mt == 0: return 0.0
    t = 0; k = 0
    for i in range(l1):
        if f1[i]:
            while not f2[k]: k += 1
            if s1[i] != s2[k]: t += 1
            k += 1
    jaro = (mt / l1 + mt / l2 + (mt - t / 2) / mt) / 3
    p = 0
    for i in range(min(4, l1, l2)):
        if s1[i] == s2[i]: p += 1
        else: break
    return jaro + p * 0.1 * (1 - jaro)

def hav(lat1, lon1, lat2, lon2):
    R = 6371.0; p = math.pi / 180
    a = math.sin((lat2 - lat1) * p / 2) ** 2 + math.cos(lat1 * p) * math.cos(lat2 * p) * math.sin((lon2 - lon1) * p / 2) ** 2
    return 2 * R * math.asin(math.sqrt(min(1, a)))

STEP = {}
def step(node, arr=None):
    if arr is not None: return qstep(arr)
    if node not in STEP: STEP[node] = qstep(ser[node])
    return STEP[node]

def evaluate(a, b, ma, mb, sa, sb):
    """returns dict of M0..M4 booleans"""
    res = {}
    d = hav(ma['lat'], ma['lon'], mb['lat'], mb['lon'])
    ar = (ma['area'] / mb['area']) if (np.isfinite(ma.get('area', np.nan)) and np.isfinite(mb.get('area', np.nan)) and mb['area'] > 0) else None
    res['M0'] = d <= 1.0 and (ar is None or 0.9 <= ar <= 1.1)
    r, ov = pearson(a, b)
    r2 = r * r if np.isfinite(r) else 0.0
    res['M1'] = ov >= 30 and r2 > 0.99
    comps = [min(d / 10, 1)]
    for x, y in [(ma.get('river'), mb.get('river')), (ma.get('station'), mb.get('station'))]:
        s = jw(x, y)
        if s is not None: comps.append(1 - s)
    res['M2'] = (np.mean(comps) < 0.25) and ov >= 30 and r2 >= 0.90
    m = np.isfinite(a) & np.isfinite(b)
    res['M3'] = res['M4'] = False
    if m.sum() >= 30:
        x, y = a[m].astype(float), b[m].astype(float)
        pp = y > 0
        if pp.sum() >= 30:
            k = float(np.median(x[pp] / y[pp]))
            if np.isfinite(k) and k > 0:
                g = max(sa, k * sb)
                if g > 0:
                    res['M3'] = bool(np.all(np.round(x / g) == np.round(k * y / g)))
                else:
                    res['M3'] = bool(np.all(x == k * y))
                tau = np.maximum(0.02 * np.abs(k * y), 2 * (sa / 2 + k * sb / 2))
                res['M4'] = float(np.mean(np.abs(x - k * y) <= tau)) >= 0.9
    return res

rng = np.random.default_rng(0)
REGION = sys.argv[1] if len(sys.argv) > 1 else None
def perturb(cls, node, a, ma, seed):
    r = np.random.default_rng(seed)
    if cls == 'c2':
        x = a.astype(float).copy(); f = np.isfinite(x) & (x != 0)
        mag = np.floor(np.log10(np.abs(x[f]))); x[f] = np.round(x[f] / 10 ** (mag - 1)) * 10 ** (mag - 1)
        return x.astype(np.float32), ma, qstep(x)
    if cls == 'c3':
        fi = np.where(np.isfinite(a))[0]
        if len(fi) < 10: return a, ma, step(node)
        L = int(0.4 * (fi[-1] - fi[0] + 1)); st = r.integers(fi[0], fi[-1] - L + 2)
        x = np.full_like(a, np.nan); x[st:st + L] = a[st:st + L]
        return x, ma, step(node)
    if cls == 'c5':
        m2 = dict(ma); m2['river'] = m2['station'] = None
        dist = r.uniform(0, 5); ang = r.uniform(0, 2 * math.pi)
        m2['lat'] = ma['lat'] + dist / 111.0 * math.cos(ang)
        m2['lon'] = ma['lon'] + dist / (111.0 * max(0.1, math.cos(ma['lat'] * math.pi / 180))) * math.sin(ang)
        return a, m2, step(node)
    return a, ma, step(node)

# ---------------- negatives per region
lamah_nd = pd.read_csv(LAMAH / 'B_basins_intermediate_all/1_attributes/Stream_dist.csv', sep=';')
gov_of = dict(zip(lat_att.ID, lat_att.govnr))
car_lamah_by_id = {i: ('car', f'lamah_{g}') for i, g in gov_of.items()}

neg = []  # (na, nb, kind)
for reg in REG_BOX:
    if REGION and reg != REGION: continue
    P = [p for p in pos if meta[p[0]]['region'] == reg]
    if not P: continue
    combos = {(meta[a]['repo'], meta[b]['repo']) for a, b, _, _ in P}
    nodes = [n for n in ser if meta[n]['region'] == reg]
    by_repo = {}
    for n in nodes: by_repo.setdefault(meta[n]['repo'], []).append(n)
    hard = set()
    for ra, rb in combos:
        A, B = by_repo.get(ra, []), by_repo.get(rb, [])
        if not A or not B: continue
        def xyz(ns):
            la = np.radians([meta[n]['lat'] for n in ns]); lo = np.radians([meta[n]['lon'] for n in ns])
            return np.c_[np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]
        tb = cKDTree(xyz(B))
        for i, lst in enumerate(tb.query_ball_point(xyz(A), r=50 / 6371.0)):
            na = A[i]
            for j in lst:
                nb = B[j]
                if meta[na]['lineage'] == meta[nb]['lineage']: continue
                r, ov = pearson(ser[na], ser[nb], 365)
                if np.isfinite(r) and r >= 0.9: hard.add((na, nb))
    if reg == 'EU':
        for _, r in lamah_nd.iterrows():
            i, j = int(r.ID), int(r.NEXTDOWNID)
            for na, nb in [(car_lamah_by_id.get(i), ('lamah', j)), (car_lamah_by_id.get(j), ('lamah', i))]:
                if na in ser and nb in ser and ('car_lamah', 'lamah_ce') in combos and meta[na]['lineage'] != meta[nb]['lineage']:
                    hard.add((na, nb))
    n_easy = min(100 * len(P), 50000)
    easy = set(); combos_l = sorted(combos); tries = 0
    while len(easy) < n_easy and tries < n_easy * 20:
        tries += 1
        ra, rb = combos_l[rng.integers(len(combos_l))]
        A, B = by_repo.get(ra, []), by_repo.get(rb, [])
        if not A or not B: continue
        na, nb = A[rng.integers(len(A))], B[rng.integers(len(B))]
        if meta[na]['lineage'] == meta[nb]['lineage'] or (na, nb) in hard: continue
        easy.add((na, nb))
    neg += [(a, b, 'hard') for a, b in sorted(hard)] + [(a, b, 'easy') for a, b in sorted(easy)]  # sorted: 2026-10-26, perturbation seeds must not depend on the hash seed
    print(reg, 'positives', len(P), 'hard', len(hard), 'easy', len(easy), flush=True)

# ---------------- evaluate
rows = []
classes = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6']
pert_cls = {'c2', 'c3', 'c5'}
for idx, (na, nb, cls, pair) in enumerate(pos):
    if REGION and meta[na]['region'] != REGION: continue
    for c in ([cls] + (['c2', 'c3', 'c5'] if cls == 'c1' else [])):
        a, ma, sa = perturb(c, na, ser[na], meta[na], idx * 7 + classes.index(c))
        res = evaluate(a, ser[nb], ma, meta[nb], sa, step(nb))
        rows.append(dict(cls=c, label=1, kind='pos', region=meta[na]['region'], pair=pair, a=str(na), b=str(nb), **res))
    if idx % 1000 == 0: print('pos eval', idx, flush=True)
for idx, (na, nb, kind) in enumerate(neg):
    base = evaluate(ser[na], ser[nb], meta[na], meta[nb], step(na), step(nb))
    for c in classes:
        if c in pert_cls:
            a, ma, sa = perturb(c, na, ser[na], meta[na], 10_000_000 + idx * 7 + classes.index(c))
            res = evaluate(a, ser[nb], ma, meta[nb], sa, step(nb))
        else:
            res = base
        rows.append(dict(cls=c, label=0, kind=kind, region=meta[na]['region'], pair='neg', a=str(na), b=str(nb), **res))
    if idx % 10000 == 0: print('neg eval', idx, flush=True)
R = pd.DataFrame(rows)
if REGION:
    R.to_parquet(OUT / f'g2_rows_{REGION}.parquet', index=False); print('region done', REGION, len(R)); sys.exit(0)
R.to_parquet(OUT / 'g2_rows.parquet', index=False)

M = ['M0', 'M1', 'M2', 'M3', 'M4']
def score(df):
    out = {}
    for m in M:
        tp = int((df[m] & (df.label == 1)).sum()); fp = int((df[m] & (df.label == 0)).sum()); P = int((df.label == 1).sum())
        prec = tp / (tp + fp) if tp + fp else float('nan'); rec = tp / P if P else float('nan')
        out[m] = dict(precision=prec, recall=rec, recall_at_p99=(rec if (tp + fp and prec >= 0.99) else 0.0), tp=tp, fp=fp, P=P)
    return out
summary = {'pooled': {}, 'by_region': {}}
for c in classes:
    d = R[R.cls == c]
    if (d.label == 1).sum() == 0: continue
    summary['pooled'][c] = score(d)
    for reg, dr in d.groupby('region'):
        if (dr.label == 1).sum(): summary['by_region'][f'{c}_{reg}'] = score(dr)
hits = []
for c in ['c1', 'c2', 'c3', 'c4', 'c5']:
    if c not in summary['pooled']: continue
    s = summary['pooled'][c]
    best_base = max(s[m]['recall_at_p99'] for m in ['M0', 'M1', 'M2'])
    best_ours = max(s[m]['recall_at_p99'] for m in ['M3', 'M4'])
    if best_base < 0.90 and best_ours - best_base >= 0.10: hits.append(dict(cls=c, best_base=best_base, best_ours=best_ours))
summary['gate'] = dict(classes_passing=hits, verdict='PASS (method contribution kept)' if hits else 'NO METHOD CONTRIBUTION (measurement only)')
summary['counts'] = dict(positives=len(pos), negatives=len(neg), hard=sum(k == 'hard' for *_, k in neg))
(OUT / 'g2_summary.json').write_text(json.dumps(summary, indent=1, default=float))
for c, s in summary['pooled'].items():
    print(c, {m: (round(v['precision'], 3), round(v['recall'], 3), round(v['recall_at_p99'], 3)) for m, v in s.items()})
print(json.dumps(summary['gate']), json.dumps(summary['counts']))
