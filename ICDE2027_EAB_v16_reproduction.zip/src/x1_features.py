"""X1 of PLAN_R3_EXTENSIONS.md (frozen 2026-11-07, md5 63d98013...): features for the learned matcher, per region.
Runs g2.py's own setup (cache, positives, sorted negatives, perturb) by executing its source up to the evaluation loop, so pairs,
classes and perturbation seeds are exactly those of E3. Also recomputes M0-M4 with g2's evaluate() as an alignment check.
Features fixed before running: log10 overlap; log|k|; IQR of a/(kb); share within tau; R^2; exact-match share on the coarser grid;
share of off-tolerance days explained by a +-1 day shift; log ratio of quantisation steps; log10 distance km; |log area ratio|;
1 - JW similarity of river and of station names (NaN if missing); repository pair (categorical)."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import sys, math, json
from pathlib import Path
import numpy as np, pandas as pd
REGION = sys.argv[1]
P = ART
src = open(P / 'src/g2.py', encoding='utf-8').read()
head = src.split('# ---------------- evaluate')[0]
sys.argv = ['g2.py', REGION]
G = {'__name__': 'g2feat', '__file__': str(P / 'src/g2.py')}
exec(compile(head, 'g2', 'exec'), G)
pos, neg, ser, meta, perturb, evaluate, step, pearson, jw, hav = (G[k] for k in ['pos', 'neg', 'ser', 'meta', 'perturb', 'evaluate', 'step', 'pearson', 'jw', 'hav'])

def feats(a, b, ma, mb, sa, sb):
    f = {}
    d = hav(ma['lat'], ma['lon'], mb['lat'], mb['lon']); f['logdist'] = math.log10(d + 0.01)
    ar = (ma['area'] / mb['area']) if (np.isfinite(ma.get('area', np.nan)) and np.isfinite(mb.get('area', np.nan)) and mb['area'] > 0 and ma['area'] > 0) else np.nan
    f['logarea'] = abs(math.log(ar)) if np.isfinite(ar) else np.nan
    for nm in ['river', 'station']:
        s = jw(ma.get(nm), mb.get(nm)); f['jw_' + nm] = (1 - s) if s is not None else np.nan
    r, ov = pearson(a, b); f['r2'] = r * r if np.isfinite(r) else np.nan; f['logov'] = math.log10(ov + 1)
    for k_ in ['logk', 'iqr', 'within', 'exact', 'shift', 'logq']: f[k_] = np.nan
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() >= 30:
        x, y = a[m].astype(float), b[m].astype(float); pp = y > 0
        if pp.sum() >= 30:
            k = float(np.median(x[pp] / y[pp]))
            if np.isfinite(k) and k > 0:
                f['logk'] = math.log10(k); rr = x[pp] / (k * y[pp]); f['iqr'] = float(np.subtract(*np.percentile(rr, [75, 25])))
                tau = np.maximum(0.02 * np.abs(k * y), 2 * (sa / 2 + k * sb / 2)); w = np.abs(x - k * y) <= tau
                f['within'] = float(w.mean()); g = max(sa, k * sb)
                f['exact'] = float(np.mean(np.round(x / g) == np.round(k * y / g))) if g > 0 else float(np.mean(x == k * y))
                ya = np.where(m)[0]; bb = b.astype(float)
                if (~w).sum():
                    idx = ya[~w]; sh = np.zeros(len(idx), bool)
                    for s_ in (-1, 1):
                        j = np.clip(idx + s_, 0, len(bb) - 1); sh |= np.isfinite(bb[j]) & (np.abs(a[idx] - k * bb[j]) <= tau[~w])
                    f['shift'] = float(sh.mean())
                else: f['shift'] = 0.0
                f['logq'] = math.log10((sa + 1e-9) / (k * sb + 1e-9))
    return f

rows = []
classes = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6']; pert_cls = {'c2', 'c3', 'c5'}
for idx, (na, nb, cls, pair) in enumerate(pos):
    if meta[na]['region'] != REGION: continue
    for c in ([cls] + (['c2', 'c3', 'c5'] if cls == 'c1' else [])):
        a, ma, sa = perturb(c, na, ser[na], meta[na], idx * 7 + classes.index(c))
        f = feats(a, ser[nb], ma, meta[nb], sa, step(nb)); r = evaluate(a, ser[nb], ma, meta[nb], sa, step(nb))
        rows.append(dict(cls=c, label=1, kind='pos', region=REGION, pair=pair, a=str(na), b=str(nb), repo=f"{meta[na]['repo']}|{meta[nb]['repo']}", **f, **r))
for idx, (na, nb, kind) in enumerate(neg):
    fb = feats(ser[na], ser[nb], meta[na], meta[nb], step(na), step(nb)); rb = evaluate(ser[na], ser[nb], meta[na], meta[nb], step(na), step(nb))
    for c in classes:
        if c in pert_cls:
            a, ma, sa = perturb(c, na, ser[na], meta[na], 10_000_000 + idx * 7 + classes.index(c))
            f = feats(a, ser[nb], ma, meta[nb], sa, step(nb)); r = evaluate(a, ser[nb], ma, meta[nb], sa, step(nb))
        else: f, r = fb, rb
        rows.append(dict(cls=c, label=0, kind=kind, region=REGION, pair='neg', a=str(na), b=str(nb), repo=f"{meta[na]['repo']}|{meta[nb]['repo']}", **f, **r))
    if idx % 20000 == 0: print(REGION, 'neg', idx, len(neg), flush=True)
df = pd.DataFrame(rows); (P / 'out/x1').mkdir(parents=True, exist_ok=True)
df.to_parquet(P / f'out/x1/features_{REGION}.parquet', index=False)
old = pd.read_parquet(P / f'out/g2/g2_rows_{REGION}.parquet')
key = ['cls', 'label', 'kind', 'a', 'b']
mm = df.merge(old[key + ['M0', 'M1', 'M2', 'M3', 'M4']], on=key, suffixes=('', '_g2'), how='left')
agree = {m: float((mm[m] == mm[m + '_g2']).mean()) for m in ['M0', 'M1', 'M2', 'M3', 'M4']}
print(REGION, 'rows', len(df), 'missing in g2', int(mm.M0_g2.isna().sum()), 'rule agreement', agree, flush=True)
