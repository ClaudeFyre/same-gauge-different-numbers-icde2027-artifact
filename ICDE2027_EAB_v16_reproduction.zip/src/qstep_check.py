"""Descriptive check of the quantisation-step estimator q(x) (smallest positive difference between distinct values).
Per repository: median q, share of series whose q is a power of ten (fixed-decimal grid), and the largest relative half-step
h/x at the series' median flow, to show when the rounding term or the 2% floor dominates tau."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import pickle, json, numpy as np, pandas as pd
from pathlib import Path
P = ART
meta = pickle.load(open(P / 'cache/g2_meta.pkl', 'rb')); keys = meta['keys']; M = meta['meta']
arr = np.load(P / 'cache/g2_series.npy', mmap_mode='r')
rng = np.random.default_rng(0); rows = []
by_repo = {}
for i, k in enumerate(keys): by_repo.setdefault(M[k]['repo'], []).append(i)
for repo, idx in by_repo.items():
    for i in rng.choice(idx, min(200, len(idx)), replace=False):
        x = np.asarray(arr[i], float); x = x[np.isfinite(x)]
        if len(x) < 365: continue
        u = np.unique(x); d = np.diff(u); d = d[d > 0]
        if not len(d): continue
        q = d.min(); med = np.median(x[x > 0]) if (x > 0).any() else np.nan
        pow10 = abs(np.log10(q) - round(np.log10(q))) < 0.005
        rows.append(dict(repo=repo, q=q, pow10=pow10, rel_half_at_median=(q / 2) / med if med and med > 0 else np.nan))
D = pd.DataFrame(rows)
S = D.groupby('repo').agg(n=('q', 'size'), q_median=('q', 'median'), share_pow10=('pow10', 'mean'),
                          rel_half_med=('rel_half_at_median', 'median'), rel_half_p90=('rel_half_at_median', lambda s: s.quantile(.9)))
print(S.to_string())
S.to_csv(P / 'out/g1/qstep_check.csv')
