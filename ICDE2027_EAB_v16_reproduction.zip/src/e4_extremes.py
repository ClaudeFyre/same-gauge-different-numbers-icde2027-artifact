"""X2 of PLAN_R3_EXTENSIONS.md (frozen 2026-11-07, md5 63d98013...): retrain W (=R1-R5 of PLAN_E4_SPLITS), M1-M5 and U1-U5 with the
frozen code of e4_fixedtest.py/e4_splits.py and seeds, saving daily test predictions (out/e4extremes/pred_<tag>.npz).
Stops if any per-basin NSE differs from the stored value by more than 1e-6. Metrics are computed by e4_extremes_eval.py."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART

import sys, json, time, zipfile
from pathlib import Path
import numpy as np, pandas as pd, torch
from concurrent.futures import ProcessPoolExecutor
from scipy import stats
from scipy.spatial import cKDTree
sys.path.insert(0, str(ART / 'src'))
import e4s_load as L

CAR = L.CAR; GZ = zipfile.ZipFile(L.GZP)
SPL = ART / 'out/e4splits'
OUT = ART / 'out/e4extremes'; OUT.mkdir(parents=True, exist_ok=True)
FIX = ART / 'out/e4fixed'
SUBS = ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']
FORC = L.FORC; ND = len(L.DAYS); dev = torch.device('cuda')

if __name__ == '__main__':
    t0 = time.time()
    stat = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_caravan_{s}.csv') for s in SUBS] +
                     [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_caravan_grdc.csv'))]).drop_duplicates('gauge_id').set_index('gauge_id')
    SCOLS = list(stat.columns)
    oth = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon', 'area']] for s in SUBS] +
                    [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon', 'area']]]).drop_duplicates('gauge_id').set_index('gauge_id')
    valid = set(json.load(open(SPL / 'valid.json')))
    # ---- identical lineage classes, class sample and splits as PLAN_E4_SPLITS
    g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv'); g1 = g1[g1.pair.str.startswith(('P1', 'P2'))]
    par = {}
    def find(x):
        par.setdefault(x, x)
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b in zip(g1.a, g1.b): par[find(a)] = find(b)
    cls = {}
    for g in sorted(valid): cls.setdefault(find(g), []).append(g)
    classes = sorted(cls.values(), key=lambda m: m[0])
    rng = np.random.default_rng(0)
    pick = [classes[i] for i in sorted(rng.choice(len(classes), 2500, replace=False))]
    basins = sorted(g for m in pick for g in m); cls_of = {g: i for i, m in enumerate(pick) for g in m}; pool = set(basins)
    assert len(basins) == 3060, len(basins)
    # all-keyed class sizes (copies anywhere, valid or not)
    allsize = {}
    for x in list(par): allsize[find(x)] = allsize.get(find(x), 0) + 1
    single = lambda g: (g not in par) or allsize[find(g)] == 1
    cand_all = sorted(g for g in valid if g not in pool and single(g) and g in oth.index and g in stat.index)
    subset = lambda g: 'GRDC' if g.startswith('GRDC_') else g.split('_')[0]
    feat = pd.DataFrame(stat.loc[list(pool) + cand_all, SCOLS]); feat['logarea'] = np.log10(oth.loc[feat.index, 'area'].clip(lower=1e-3))
    feat = (feat - feat.mean()) / (feat.std() + 1e-9); feat = feat.fillna(0)
    def xyz(ids):
        la = np.radians(oth.loc[ids, 'gauge_lat'].values); lo = np.radians(oth.loc[ids, 'gauge_lon'].values)
        return np.c_[np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]
    print('pool', len(basins), 'candidates', len(cand_all), round(time.time() - t0), 's', flush=True)

    DATA = {}
    def ensure(ids):
        need = [g for g in ids if g not in DATA]
        if need:
            with ProcessPoolExecutor(12) as ex:
                for g, X, y in ex.map(L.load, need, chunksize=20): DATA[g] = (X, y)
    ensure(basins); print('pool loaded', round(time.time() - t0), 's', flush=True)

    class Net(torch.nn.Module):
        def __init__(s, nin):
            super().__init__(); s.lstm = torch.nn.LSTM(nin, 64, num_layers=2, batch_first=True); s.drop = torch.nn.Dropout(0.4); s.head = torch.nn.Linear(64, 1)
        def forward(s, x):
            o, _ = s.lstm(x); return s.head(s.drop(o[:, -1])).squeeze(-1)
    def build(ids):
        return np.stack([DATA[g][0] for g in ids]), np.stack([DATA[g][1] for g in ids]), stat.loc[ids, SCOLS].values.astype(np.float32)
    def run(train_ids, test_ids, seed, tag):
        torch.manual_seed(seed); r = np.random.default_rng(seed)
        X, Y, St = build(train_ids)
        xm, xs = np.nanmean(X, (0, 1)), np.nanstd(X, (0, 1)) + 1e-6
        sm, ss = np.nanmean(St, 0), np.nanstd(St, 0) + 1e-6
        ym, ysd = np.nanmean(Y), np.nanstd(Y); qstd = np.nanstd(Y, 1)
        Xn = np.nan_to_num((X - xm) / xs); Sn = np.nan_to_num((St - sm) / ss); Yn = (Y - ym) / ysd
        valid_w = np.array([(i, t) for i in range(len(train_ids)) for t in np.where(np.isfinite(Yn[i, 364:]))[0] + 364])
        Xg = torch.tensor(Xn, device=dev); Sg = torch.tensor(Sn, device=dev); Yg = torch.tensor(np.nan_to_num(Yn), device=dev)
        wg = torch.tensor(1 / (qstd / ysd + 0.1) ** 2, device=dev, dtype=torch.float32)
        net = Net(len(FORC) + len(SCOLS)).to(dev); opt = torch.optim.Adam(net.parameters(), 1e-3)
        ar = torch.arange(-364, 1, device=dev)
        for ep in range(15):
            net.train(); tl = 0
            for _ in range(800):
                b = valid_w[r.integers(0, len(valid_w), 256)]
                bi = torch.tensor(b[:, 0], device=dev); bt = torch.tensor(b[:, 1], device=dev)
                idx = bt[:, None] + ar[None, :]
                x = torch.cat([Xg[bi[:, None], idx], Sg[bi][:, None, :].expand(-1, 365, -1)], -1)
                loss = (wg[bi] * (net(x) - Yg[bi, bt]) ** 2).mean()
                opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); tl += loss.item()
        print(tag, 'trained', round(tl / 800, 4), round(time.time() - t0), 's', flush=True)
        del Xg, Yg; torch.cuda.empty_cache()
        net.eval(); out = {}; P = {}
        Xt, Yt, Stt = build(test_ids)
        Xtn = torch.tensor(np.nan_to_num((Xt - xm) / xs), device=dev); Stn = torch.tensor(np.nan_to_num((Stt - sm) / ss), device=dev)
        with torch.no_grad():
            for i, g in enumerate(test_ids):
                ts = torch.arange(365, ND, device=dev); preds = []
                for c in range(0, len(ts), 2048):
                    tt = ts[c:c + 2048]; idx = tt[:, None] + ar[None, :]
                    x = torch.cat([Xtn[i][idx], Stn[i][None, None, :].expand(len(tt), 365, -1)], -1)
                    preds.append(net(x).cpu().numpy())
                p = np.concatenate(preds) * ysd + ym; o = Yt[i, 365:]; m = np.isfinite(o); P[g] = p.astype(np.float32)
                out[g] = float(1 - ((p[m] - o[m]) ** 2).sum() / ((o[m] - o[m].mean()) ** 2).sum()) if m.sum() > 365 else np.nan
        np.savez_compressed(OUT / f'pred_{tag}.npz', **P); return out

    W = json.load(open(SPL / 'nse.json'))
    res = {}; REF = dict(W); REF.update(json.load(open(FIX / 'nse.json')))
    def check(tag, got, ref):
        bad = [g for g in ref if not (np.isnan(ref[g]) and np.isnan(got.get(g, np.nan))) and abs(got.get(g, np.nan) - ref[g]) > 1e-6]
        if bad: sys.exit(f'STOP: {tag} differs from stored NSE on {len(bad)} basins, e.g. {bad[:3]}')
        print(tag, 'NSE identical to stored', flush=True)
    info = {}
    for seed in range(1, 6):
        rb = np.random.default_rng(seed).permutation(basins); nte = int(round(0.2 * len(basins)))
        R_test, R_train = sorted(rb[:nte]), sorted(rb[nte:])
        test_cls = {cls_of[g] for g in R_test}
        leak = sorted(g for g in R_train if cls_of[g] in test_cls)
        trainR = set(R_train)
        has_copy = {g: any(h in trainR for h in pick[cls_of[g]] if h != g) for g in R_test}
        dmin, _ = cKDTree(xyz(R_test)).query(xyz(cand_all), k=1)
        cands = [g for g, d in zip(cand_all, dmin) if d * 6371 > 5]
        # matched replacements (nearest neighbour in standardised attributes, same subset, without replacement)
        used, M_rep, cross = set(), [], 0
        for g in leak:
            same = [c for c in cands if subset(c) == subset(g) and c not in used]
            pool_c = same if same else [c for c in cands if c not in used]
            if not same: cross += 1
            d = ((feat.loc[pool_c].values - feat.loc[g].values) ** 2).sum(1)
            best = pool_c[int(np.argmin(d))]; used.add(best); M_rep.append(best)
        U_rep = list(np.random.default_rng(seed).choice(cands, len(leak), replace=False))
        ensure(M_rep + U_rep)
        base = [g for g in R_train if g not in set(leak)]
        info[seed] = dict(n_test=len(R_test), n_with_copy=int(sum(has_copy.values())), n_leak_removed=len(leak), cross_subset_matches=cross,
                          has_copy=has_copy)
        for tag, ref, tr in [(f'W{seed}', f'R{seed}', R_train), (f'M{seed}', f'M{seed}', sorted(base + M_rep)), (f'U{seed}', f'U{seed}', sorted(base + U_rep))]:
            if (OUT / f'pred_{tag}.npz').exists(): continue
            res[tag] = run(tr, R_test, seed, tag); check(tag, res[tag], {k: (np.nan if v is None else v) for k, v in REF[ref].items()})
            json.dump(res, open(OUT / 'nse.json', 'w'))
        json.dump({str(k): v for k, v in has_copy.items()}, open(OUT / f'has_copy_{seed}.json', 'w'))
    print('ALL DONE', flush=True)
