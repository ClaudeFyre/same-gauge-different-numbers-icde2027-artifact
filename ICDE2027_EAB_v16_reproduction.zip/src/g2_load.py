"""Worker for g2_cache.py: load one node's streamflow onto the common daily grid (fast netCDF4 path)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import zipfile, numpy as np, pandas as pd, netCDF4
from pathlib import Path
CAR = ROOT / 'data/Caravan/extracted/Caravan-nc'
GZIP = ROOT / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip'
LAMAH = ROOT / 'icde_probe/raw/lamah'
T0 = pd.Timestamp('1950-01-01'); IDX = pd.date_range(T0, '2024-12-31'); ND = len(IDX)
_gz = None
def to_arr(idx, vals):
    a = np.full(ND, np.nan, np.float32)
    idx = pd.DatetimeIndex(idx); keep = (idx >= T0) & (idx <= IDX[-1])
    a[(idx[keep] - T0).days.values] = np.asarray(vals, float)[keep].astype(np.float32)
    return a
def load_node(node):
    global _gz
    kind, x = node
    try:
        if kind == 'car':
            s = x.split('_')[0]
            with netCDF4.Dataset(CAR / 'timeseries/netcdf' / s / f'{x}.nc') as d:
                v = np.ma.filled(d['streamflow'][:].astype(float), np.nan)
                t = netCDF4.num2date(d['date'][:], d['date'].units, only_use_cftime_datetimes=False, only_use_python_datetimes=True)
            return node, to_arr(pd.to_datetime([str(z) for z in t]), v)
        if kind == 'grdc':
            if _gz is None: _gz = zipfile.ZipFile(GZIP)
            d = pd.read_csv(_gz.open(f'GRDC_Caravan_extension_csv/timeseries/csv/grdc/{x}.csv'), usecols=['date', 'streamflow'], parse_dates=['date'])
            return node, to_arr(d.date, d.streamflow)
        d = pd.read_csv(LAMAH / f'D_gauges/2_timeseries/daily/ID_{x}.csv', sep=';')
        q = d.qobs.values.astype(float); q[q < 0] = np.nan
        return node, to_arr(pd.to_datetime(dict(year=d.YYYY, month=d.MM, day=d.DD)), q)
    except Exception:
        return node, None
