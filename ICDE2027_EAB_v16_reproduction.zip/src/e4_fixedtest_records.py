"""Per-record differences of the E4 fixed-test-set experiment (descriptive export for Fig. 6; no training).
Rebuilds the pool, lineage classes and splits exactly as e4_fixedtest.py / e4_splits.py and writes, for every
(seed, test basin), NSE_W - NSE_M and NSE_W - NSE_U and whether the basin has a copy in R_train. Re-derives the
summary medians as a consistency check against out/e4fixed/summary.json."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import json
from pathlib import Path
import numpy as np, pandas as pd
P = ART
SPL = P / 'out/e4splits'; OUT = P / 'out/e4fixed'
valid = set(json.load(open(SPL / 'valid.json')))
g1 = pd.read_csv(P / 'out/g1/g1_pairs.csv'); g1 = g1[g1.pair.str.startswith(('P1', 'P2'))]
par = {}
def find(x):
    par.setdefault(x, x)
    while par[x] != x: par[x] = par[par[x]]; x = par[x]
    return x
for a, b in zip(g1.a, g1.b): par[find(a)] = find(b)
cls = {}
for g in sorted(valid): cls.setdefault(find(g), []).append(g)
classes = sorted(cls.values(), key=lambda m: m[0])
pick = [classes[i] for i in sorted(np.random.default_rng(0).choice(len(classes), 2500, replace=False))]
basins = sorted(g for m in pick for g in m); cls_of = {g: i for i, m in enumerate(pick) for g in m}
assert len(basins) == 3060
W = json.load(open(SPL / 'nse.json')); F = json.load(open(OUT / 'nse.json'))
rows = []
for seed in range(1, 6):
    rb = np.random.default_rng(seed).permutation(basins); nte = int(round(0.2 * len(basins)))
    R_test, R_train = sorted(rb[:nte]), set(rb[nte:])
    for g in R_test:
        hc = any(h in R_train for h in pick[cls_of[g]] if h != g)
        w, m, u = W[f'R{seed}'].get(g), F[f'M{seed}'].get(g), F[f'U{seed}'].get(g)
        rows.append(dict(seed=seed, basin=g, has_copy=hc, d_M=(w - m) if None not in (w, m) else np.nan,
                         d_U=(w - u) if None not in (w, u) else np.nan))
R = pd.DataFrame(rows); R.to_csv(OUT / 'records.csv', index=False)
S = json.load(open(OUT / 'summary.json'))
chk = dict(M_aff=float(R[R.has_copy].d_M.median()), M_neg=float(R[~R.has_copy].d_M.median()), n_aff=int(R[R.has_copy].d_M.notna().sum()))
print(chk, 'summary:', S['M']['per_basin_median'], S['M']['negative_control_median'], S['M']['n_records'])
assert abs(chk['M_aff'] - S['M']['per_basin_median']) < 1e-12 and abs(chk['M_neg'] - S['M']['negative_control_median']) < 1e-12
