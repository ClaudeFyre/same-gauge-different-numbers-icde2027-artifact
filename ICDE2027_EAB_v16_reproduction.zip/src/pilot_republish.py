import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, ART  # data root (REPUB_ROOT) and artifact root
import sys, zipfile, numpy as np, pandas as pd
from _stream import stream_array
v = pd.read_parquet(ROOT / 'icde_probe/raw/nwis_states/vt_nh_long.parquet')
v['date'] = pd.to_datetime(v['date']); sites = set(v.site.astype(str))
z = zipfile.ZipFile(ROOT / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip')
rows = []
for r in stream_array(z.open('Result datasets/Validation dataset/globe_gauge_discharge_data_8y.json')):
    if str(r['agency']) != 'USGS' or str(r['id']) not in sites: continue
    g = pd.Series(np.asarray(r['discharge'], float), index=pd.to_datetime(r['time']))
    n = v[v.site == str(r['id'])].set_index('date')
    j = pd.concat([g.rename('g'), n.Q.rename('q'), n.est.rename('est')], axis=1).dropna(subset=['g','q'])
    j = j[j.q > 0]
    if len(j) < 100: continue
    ratio = j.g / j.q
    k = ratio.median()
    back = j.g / 0.0283168466  # m3/s -> cfs
    exact = (np.abs(back - j.q) <= np.maximum(0.5*10**(np.floor(np.log10(j.q))-2), 0.005)).mean()
    rows.append(dict(site=r['id'], n=len(j), med_ratio=k, ratio_iqr=ratio.quantile(.75)-ratio.quantile(.25),
                     exact_after_unit=exact, frac_mismatch_est=(np.abs(back-j.q)>0.02*j.q)[j.est.astype(bool)].mean() if j.est.any() else np.nan,
                     frac_mismatch_nonest=(np.abs(back-j.q)>0.02*j.q)[~j.est.astype(bool)].mean()))
d = pd.DataFrame(rows); pd.set_option('display.width', 200)
print(len(d)); print(d.describe().T); print(d.sort_values('exact_after_unit').head(8))
