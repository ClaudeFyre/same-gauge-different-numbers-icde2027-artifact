"""PLAN_E4_FIXEDTEST.md (frozen 2026-10-26, md5 b8103dd1...): fixed test set; W (with copies, reused from e4splits R models),
M (copies replaced by matched non-copy basins), U (copies replaced by random non-copy basins). Training/eval code identical to e4_splits.py."""
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from _paths import ROOT, ART
import sys, json, time, zipfile
from pathlib import Path
import numpy as np, pandas as pd, torch
from concurrent.futures import ProcessPoolExecutor
from scipy import stats
from scipy.spatial import cKDTree
sys.path.insert(0, str(ART / 'src'))
import e4s_load as L

CAR = L.CAR; GZ = zipfile.ZipFile(L.GZP)
SPL = ART / 'out/e4splits'
OUT = ART / 'out/e4fixed'; OUT.mkdir(parents=True, exist_ok=True)
SUBS = ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']
FORC = L.FORC; ND = len(L.DAYS); dev = torch.device('cuda')

if __name__ == '__main__':
    t0 = time.time()
    stat = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_caravan_{s}.csv') for s in SUBS] +
                     [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_caravan_grdc.csv'))]).drop_duplicates('gauge_id').set_index('gauge_id')
    SCOLS = list(stat.columns)
    oth = pd.concat([pd.read_csv(CAR / f'attributes/{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon', 'area']] for s in SUBS] +
                    [pd.read_csv(GZ.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon', 'area']]]).drop_duplicates('gauge_id').set_index('gauge_id')
    valid = set(json.load(open(SPL / 'valid.json')))
    # ---- identical lineage classes, class sample and splits as PLAN_E4_SPLITS
    g1 = pd.read_csv(ART / 'out/g1/g1_pairs.csv'); g1 = g1[g1.pair.str.startswith(('P1', 'P2'))]
    par = {}
    def find(x):
        par.setdefault(x, x)
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b in zip(g1.a, g1.b): par[find(a)] = find(b)
    cls = {}
    for g in sorted(valid): cls.setdefault(find(g), []).append(g)
    classes = sorted(cls.values(), key=lambda m: m[0])
    rng = np.random.default_rng(0)
    pick = [classes[i] for i in sorted(rng.choice(len(classes), 2500, replace=False))]
    basins = sorted(g for m in pick for g in m); cls_of = {g: i for i, m in enumerate(pick) for g in m}; pool = set(basins)
    assert len(basins) == 3060, len(basins)
    # all-keyed class sizes (copies anywhere, valid or not)
    allsize = {}
    for x in list(par): allsize[find(x)] = allsize.get(find(x), 0) + 1
    single = lambda g: (g not in par) or allsize[find(g)] == 1
    cand_all = sorted(g for g in valid if g not in pool and single(g) and g in oth.index and g in stat.index)
    subset = lambda g: 'GRDC' if g.startswith('GRDC_') else g.split('_')[0]
    feat = pd.DataFrame(stat.loc[list(pool) + cand_all, SCOLS]); feat['logarea'] = np.log10(oth.loc[feat.index, 'area'].clip(lower=1e-3))
    feat = (feat - feat.mean()) / (feat.std() + 1e-9); feat = feat.fillna(0)
    def xyz(ids):
        la = np.radians(oth.loc[ids, 'gauge_lat'].values); lo = np.radians(oth.loc[ids, 'gauge_lon'].values)
        return np.c_[np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]
    print('pool', len(basins), 'candidates', len(cand_all), round(time.time() - t0), 's', flush=True)

    DATA = {}
    def ensure(ids):
        need = [g for g in ids if g not in DATA]
        if need:
            with ProcessPoolExecutor(12) as ex:
                for g, X, y in ex.map(L.load, need, chunksize=20): DATA[g] = (X, y)
    ensure(basins); print('pool loaded', round(time.time() - t0), 's', flush=True)

    class Net(torch.nn.Module):
        def __init__(s, nin):
            super().__init__(); s.lstm = torch.nn.LSTM(nin, 64, num_layers=2, batch_first=True); s.drop = torch.nn.Dropout(0.4); s.head = torch.nn.Linear(64, 1)
        def forward(s, x):
            o, _ = s.lstm(x); return s.head(s.drop(o[:, -1])).squeeze(-1)
    def build(ids):
        return np.stack([DATA[g][0] for g in ids]), np.stack([DATA[g][1] for g in ids]), stat.loc[ids, SCOLS].values.astype(np.float32)
    def run(train_ids, test_ids, seed, tag):
        torch.manual_seed(seed); r = np.random.default_rng(seed)
        X, Y, St = build(train_ids)
        xm, xs = np.nanmean(X, (0, 1)), np.nanstd(X, (0, 1)) + 1e-6
        sm, ss = np.nanmean(St, 0), np.nanstd(St, 0) + 1e-6
        ym, ysd = np.nanmean(Y), np.nanstd(Y); qstd = np.nanstd(Y, 1)
        Xn = np.nan_to_num((X - xm) / xs); Sn = np.nan_to_num((St - sm) / ss); Yn = (Y - ym) / ysd
        valid_w = np.array([(i, t) for i in range(len(train_ids)) for t in np.where(np.isfinite(Yn[i, 364:]))[0] + 364])
        Xg = torch.tensor(Xn, device=dev); Sg = torch.tensor(Sn, device=dev); Yg = torch.tensor(np.nan_to_num(Yn), device=dev)
        wg = torch.tensor(1 / (qstd / ysd + 0.1) ** 2, device=dev, dtype=torch.float32)
        net = Net(len(FORC) + len(SCOLS)).to(dev); opt = torch.optim.Adam(net.parameters(), 1e-3)
        ar = torch.arange(-364, 1, device=dev)
        for ep in range(15):
            net.train(); tl = 0
            for _ in range(800):
                b = valid_w[r.integers(0, len(valid_w), 256)]
                bi = torch.tensor(b[:, 0], device=dev); bt = torch.tensor(b[:, 1], device=dev)
                idx = bt[:, None] + ar[None, :]
                x = torch.cat([Xg[bi[:, None], idx], Sg[bi][:, None, :].expand(-1, 365, -1)], -1)
                loss = (wg[bi] * (net(x) - Yg[bi, bt]) ** 2).mean()
                opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); tl += loss.item()
        print(tag, 'trained', round(tl / 800, 4), round(time.time() - t0), 's', flush=True)
        del Xg, Yg; torch.cuda.empty_cache()
        net.eval(); out = {}
        Xt, Yt, Stt = build(test_ids)
        Xtn = torch.tensor(np.nan_to_num((Xt - xm) / xs), device=dev); Stn = torch.tensor(np.nan_to_num((Stt - sm) / ss), device=dev)
        with torch.no_grad():
            for i, g in enumerate(test_ids):
                ts = torch.arange(365, ND, device=dev); preds = []
                for c in range(0, len(ts), 2048):
                    tt = ts[c:c + 2048]; idx = tt[:, None] + ar[None, :]
                    x = torch.cat([Xtn[i][idx], Stn[i][None, None, :].expand(len(tt), 365, -1)], -1)
                    preds.append(net(x).cpu().numpy())
                p = np.concatenate(preds) * ysd + ym; o = Yt[i, 365:]; m = np.isfinite(o)
                out[g] = float(1 - ((p[m] - o[m]) ** 2).sum() / ((o[m] - o[m].mean()) ** 2).sum()) if m.sum() > 365 else np.nan
        return out

    W = json.load(open(SPL / 'nse.json'))
    res = json.load(open(OUT / 'nse.json')) if (OUT / 'nse.json').exists() else {}
    info = {}
    for seed in range(1, 6):
        rb = np.random.default_rng(seed).permutation(basins); nte = int(round(0.2 * len(basins)))
        R_test, R_train = sorted(rb[:nte]), sorted(rb[nte:])
        test_cls = {cls_of[g] for g in R_test}
        leak = sorted(g for g in R_train if cls_of[g] in test_cls)
        trainR = set(R_train)
        has_copy = {g: any(h in trainR for h in pick[cls_of[g]] if h != g) for g in R_test}
        dmin, _ = cKDTree(xyz(R_test)).query(xyz(cand_all), k=1)
        cands = [g for g, d in zip(cand_all, dmin) if d * 6371 > 5]
        # matched replacements (nearest neighbour in standardised attributes, same subset, without replacement)
        used, M_rep, cross = set(), [], 0
        for g in leak:
            same = [c for c in cands if subset(c) == subset(g) and c not in used]
            pool_c = same if same else [c for c in cands if c not in used]
            if not same: cross += 1
            d = ((feat.loc[pool_c].values - feat.loc[g].values) ** 2).sum(1)
            best = pool_c[int(np.argmin(d))]; used.add(best); M_rep.append(best)
        U_rep = list(np.random.default_rng(seed).choice(cands, len(leak), replace=False))
        ensure(M_rep + U_rep)
        base = [g for g in R_train if g not in set(leak)]
        info[seed] = dict(n_test=len(R_test), n_with_copy=int(sum(has_copy.values())), n_leak_removed=len(leak), cross_subset_matches=cross,
                          has_copy=has_copy)
        for tag, tr in [(f'M{seed}', sorted(base + M_rep)), (f'U{seed}', sorted(base + U_rep))]:
            if tag in res: continue
            res[tag] = run(tr, R_test, seed, tag); json.dump(res, open(OUT / 'nse.json', 'w'))
    json.dump({k: {kk: vv for kk, vv in v.items() if kk != 'has_copy'} for k, v in info.items()}, open(OUT / 'meta.json', 'w'), indent=1)

    def summarise(ctrl):
        recs, neg, pooled = [], [], []
        for seed in range(1, 6):
            w = pd.Series(W[f'R{seed}']); c = pd.Series(res[f'{ctrl}{seed}']); hc = pd.Series(info[seed]['has_copy'])
            d = (w - c).dropna()
            recs += [(g, d[g]) for g in hc[hc].index if g in d.index]
            neg += [d[g] for g in hc[~hc].index if g in d.index]
            pooled.append(w[c.index].median() - c.median())
        R = pd.DataFrame(recs, columns=['basin', 'delta']); groups = {b: g.delta.values for b, g in R.groupby('basin')}
        keys = list(groups); rr = np.random.default_rng(0); boot = []
        for _ in range(10000):
            pickb = rr.integers(0, len(keys), len(keys)); boot.append(np.median(np.concatenate([groups[keys[i]] for i in pickb])))
        p = np.array(pooled); h = stats.t.ppf(0.975, 4) * p.std(ddof=1) / np.sqrt(5)
        return dict(per_basin_median=float(R.delta.median()), per_basin_ci=[float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))],
                    n_records=len(R), n_basins=len(keys), negative_control_median=float(np.median(neg)), n_negative=len(neg),
                    pooled_per_seed=list(map(float, p)), pooled_mean=float(p.mean()), pooled_ci=[float(p.mean() - h), float(p.mean() + h)])
    S = {c: summarise(c) for c in ['M', 'U']}
    m = S['M']
    S['readout'] = dict(primary1='material per-basin leakage' if (m['per_basin_median'] >= 0.05 and m['per_basin_ci'][0] > 0) else 'no material per-basin leakage',
                        primary2='detectable pooled inflation' if m['pooled_ci'][0] > 0 else 'no detectable pooled inflation')
    S['cross_subset_matches'] = {s: info[s]['cross_subset_matches'] for s in info}; S['leak_removed'] = {s: info[s]['n_leak_removed'] for s in info}
    json.dump(S, open(OUT / 'summary.json', 'w'), indent=1)
    print(json.dumps(S, indent=1))
