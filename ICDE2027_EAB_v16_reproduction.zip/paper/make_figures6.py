"""make_figures6.py: refined figures for paper v15 (2026-11-07): map, worked examples, E3 (with the X1 learned matcher), E4.
Same data and selections as make_figures3.py; only presentation changes. Does not write numbers3.tex or tables
(the selected example gauge/station are asserted equal to the ones numbers3.tex already cites)."""
import json, warnings, re
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import matplotlib.dates as mdates
warnings.filterwarnings('ignore')
import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT as R, ART as P
O = P / 'paper'; OUT = P / 'out'
plt.rcParams.update({'font.size': 7, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.6,
                     'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'legend.frameon': False, 'pdf.fonttype': 42})
BLUE, LBLUE, GREY, RED, ORANGE = '#1f5fa8', '#7fa7d6', '#9a9a9a', '#c0392b', '#e08214'
N3 = dict(re.findall(r'\\newcommand\{\\num(\w+)\}\{([^}]*)\}', (O / 'numbers3.tex').read_text(encoding='utf-8')))
def save(fig, name):
    fig.savefig(O / f'fig/{name}.pdf', bbox_inches='tight', pad_inches=0.02)
    fig.savefig(O / f'fig/{name}.png', dpi=200, bbox_inches='tight', pad_inches=0.02); plt.close(fig)

# ------------------------------------------------------------------ map, with a central-European inset
import zipfile
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
# HydroBASINS level 1 land outline: optional input (README); without it the map has no background.
HB = [R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip' for reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']]
land = None
if all(z.exists() for z in HB):
    import geopandas as gpd
    land = pd.concat([gpd.read_file(f'zip://{z}!' + z.name.replace('_lev01-12_v1c.zip', '_lev01_v1c.shp')) for z in HB]).geometry
else:
    print('HydroBASINS not found under REPUB_ROOT/data/HydroBASINS: map drawn without land outline')
CAR = R / 'data/Caravan/extracted/Caravan-nc/attributes'
coords = pd.concat([pd.read_csv(CAR / f'{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon']]
                    for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']])
gz = zipfile.ZipFile(R / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip')
coords = pd.concat([coords, pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon']]]).drop_duplicates('gauge_id').set_index('gauge_id')
g1 = pd.read_csv(OUT / 'g1/g1_pairs.csv'); st = g1[g1.stable].copy(); st['rate'] = st.real / st.n
st['gid'] = [r.a if r.pair.startswith('P3') else r.b for r in st.itertuples()]
st = st[st.gid.isin(coords.index)]
st['lat'] = coords.loc[st.gid, 'gauge_lat'].values; st['lon'] = coords.loc[st.gid, 'gauge_lon'].values
assert f'{len(st):,}' == N3['mapGauges'], (len(st), N3['mapGauges'])
bins = [(-1, 0.001, '#c4c4c4', '< 0.1%', 1.6), (0.001, 0.01, LBLUE, '0.1–1%', 2.6), (0.01, 0.05, BLUE, '1–5%', 4.0), (0.05, 2, RED, '≥ 5%', 5.0)]
def draw(ax, scale=1.0):
    for z, (lo, hi, c, lab, s) in enumerate(bins):
        d = st[(st.rate > lo) & (st.rate <= hi)] if lo >= 0 else st[st.rate <= hi]
        ax.scatter(d.lon, d.lat, s=s * scale, c=c, label=f'{lab}  ({len(d):,})', linewidths=0, zorder=2 + z)
fig, ax = plt.subplots(figsize=(7.0, 2.55))
if land is not None: land.simplify(0.2).plot(ax=ax, color='#efefef', edgecolor='#d5d5d5', linewidth=0.2)
draw(ax)
ax.set_xlim(-168, 180); ax.set_ylim(-47, 72); ax.set_axis_off()
ax.legend(loc='lower left', bbox_to_anchor=(0.0, 0.02), fontsize=6.3, markerscale=1.8, handletextpad=0.3,
          title='divergence rate (pairs)', title_fontsize=6.3, alignment='left')
ins = ax.inset_axes([0.655, 0.40, 0.25, 0.56])
if land is not None: land.clip_by_rect(5, 43, 22, 52).simplify(0.01).plot(ax=ins, color='#efefef', edgecolor='#c8c8c8', linewidth=0.3)
draw(ins, scale=2.2)
ins.set_xlim(8.5, 18.5); ins.set_ylim(45.8, 49.6); ins.set_aspect(1 / np.cos(np.deg2rad(47.7)))
ins.set_xticks([]); ins.set_yticks([])
for s_ in ins.spines.values(): s_.set_visible(True); s_.set_color('#888888'); s_.set_linewidth(0.6)
ins.set_title('Austria and Bavaria (LamaH-CE)', fontsize=6, pad=2)
mark_inset(ax, ins, loc1=2, loc2=3, fc='none', ec='#888888', lw=0.5)
save(fig, 'fig_map')

# ------------------------------------------------------------------ worked examples (same selections as make_figures3)
g4src = open(P / 'src/g4.py', encoding='utf-8').read()
G = {'__file__': str(P / 'src/g4.py')}; exec(compile(g4src.split('rows, unstable = [], []')[0], 'g4', 'exec'), G)
exec(compile(g4src[g4src.index('def camelsbr_m3s'):g4src.index('br_status = []')], 'g4b', 'exec'), G)
days = pd.read_parquet(OUT / 'g4/g4_days.parquet'); days['day'] = pd.to_datetime(days['day'])
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.25), gridspec_kw={'width_ratios': [1, 1.25]})
l2 = days[(days.chain == 'LamaH-P3') & (days.cause == 'L2 aggregation/day-boundary')]
b_id = l2.b.value_counts().index[0]; a_id = l2[l2.b == b_id].a.iloc[0]
assert str(b_id) == N3['exLamahGauge']
a = G['caravan'](a_id); b = G['lamah'](int(b_id))[0]
j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna(); k = float((j[j.b > 0].a / j[j.b > 0].b).median())
dd = l2[l2.b == b_id].day
rel = ((j.a - k * j.b).abs() / (k * j.b)).reindex(dd)
d0 = rel.idxmax(); t0, t1 = d0 - pd.Timedelta(days=3), d0 + pd.Timedelta(days=4)
fs = list(Path(G['HOURLY'][0]).glob(f'ID_{b_id}.csv'))[0]
h = pd.read_csv(fs, sep=';'); q = pd.Series(h.qobs.values.astype(float), index=pd.to_datetime(dict(year=h.YYYY, month=h.MM, day=h.DD, hour=h.hh, minute=h.mm))); q[q < 0] = np.nan
shift = q.copy().set_axis(q.index + pd.Timedelta(hours=1)).resample('D').mean()
qq = q[(q.index >= t0) & (q.index < t1 + pd.Timedelta(days=1))]
ax[0].plot(qq.index, qq.values, color='#c8c8c8', lw=0.8, label='LamaH-CE hourly (UTC)')
rng = pd.date_range(t0, t1)
def steps(s, **kw):
    s = s.reindex(rng); x = np.r_[s.index.values, (s.index[-1] + pd.Timedelta(days=1)).to_datetime64()]
    ax[0].step(x, np.r_[s.values, s.values[-1]], where='post', **kw)
steps(b, color='#555555', lw=1.5, label='LamaH-CE daily (UTC day)')
steps(a / k, color=BLUE, lw=1.5, ls='--', label='Caravan, rescaled')
steps(shift, color=RED, lw=1.0, ls=':', label='hourly mean, day shifted by 1 h')
ax[0].set_ylabel('discharge (m$^3$ s$^{-1}$)'); ax[0].legend(fontsize=5.8, loc='upper left', handlelength=2.2)
ax[0].xaxis.set_major_locator(mdates.DayLocator()); ax[0].xaxis.set_major_formatter(mdates.DateFormatter('%d')); ax[0].set_xlabel(f"{d0.strftime('%B %Y')} (day)")
ax[0].tick_params(axis='x', labelsize=6)
ax[0].set_title(f'(a) LamaH gauge {b_id}, {d0.year}: one-hour window', fontsize=7, loc='left')
b5 = days[(days.chain == 'BR') & (days.cause == 'B5 edge into Caravan/CAMELS-BR branch')]
code_b = b5.b.value_counts().index[0]; ga = b5[b5.b == code_b].a.iloc[0]; code = code_b.split('_', 1)[1]
assert code == N3['exBrStation']
r1, r2, _ = G['ana'](code); c, _ = G['camelsbr_m3s'](code); g = G['grdc'](ga)
yr = b5[b5.b == code_b].day.dt.year.value_counts().index[0]
w0, w1 = pd.Timestamp(f'{yr}-01-01'), pd.Timestamp(f'{yr}-12-31')
jj = pd.concat([g.rename('g'), r2.rename('r')], axis=1).dropna(); kg = float((jj[jj.r > 0].g / jj[jj.r > 0].r).median())
for s, lab, col, ls, lw in [(c, 'CAMELS-BR 2020 (copied by Caravan)', RED, '-', 0.9), (r2, "ANA today", '#222222', '-', 0.9),
                            (g / kg, 'GRDC-Caravan, rescaled', LBLUE, '--', 1.0)]:
    s = s[(s.index >= w0) & (s.index <= w1)]; ax[1].plot(s.index, s.values, ls=ls, color=col, lw=lw, label=lab)
mk = b5[(b5.b == code_b) & (b5.day >= w0) & (b5.day <= w1)].day
assert f'{len(mk):,}' == N3['exBrDays']
y0 = ax[1].get_ylim()[0]
ax[1].scatter(mk, np.full(len(mk), y0), marker='|', s=14, color=RED, lw=0.6, label='divergent day on ANA$\\to$CAMELS-BR edge', clip_on=False)
ax[1].set_ylabel('discharge (m$^3$ s$^{-1}$)'); ax[1].legend(fontsize=5.8, loc='upper left', ncol=1, handlelength=2.0)
ax[1].set_ylim(top=ax[1].get_ylim()[1] * 1.28)
ax[1].xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1, 3, 5, 7, 9, 11])); ax[1].xaxis.set_major_formatter(mdates.DateFormatter('%b'))
ax[1].tick_params(axis='x', labelsize=6); ax[1].set_xlabel(str(yr))
ax[1].set_title(f'(b) ANA station {code}, {yr}: older vintage in CAMELS-BR', fontsize=7, loc='left')
fig.tight_layout(w_pad=1.5); save(fig, 'fig_examples')

# ------------------------------------------------------------------ E3: rules + learned matcher, precision axis zoomed
g2 = json.load(open(OUT / 'g2/g2_summary.json')); x1 = json.load(open(OUT / 'x1/x1_summary.json'))
cls = [('c1', 'c1 scaling\nonly'), ('c2', 'c2 coarse\nre-rounding'), ('c3', 'c3 40%\nwindow'), ('c4', 'c4 divergent\n(≥5% of days)'), ('c5', 'c5 metadata\ndegraded')]
meth = [('M0', 'M0 coords+area', '#bdbdbd'), ('M1', 'M1 $R^2$', LBLUE), ('M2', 'M2 GSIM', '#6b6b6b'),
        ('M3', 'M3 exact', '#e0b0a8'), ('M4', 'M4 tolerance', BLUE), ('ML', 'ML learned', ORANGE)]
def val(c, m):
    s = x1['per_class'][c]['original'] if m == 'ML' else g2['pooled'][c][m]
    n = s['tp'] + s.get('fp', 0)
    return s['recall'], (s['precision'] if n > 0 else np.nan)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.25))
wdt = 0.135; PLO = 0.85
for i, (m, lab, col) in enumerate(meth):
    x = np.arange(len(cls)) + (i - 2.5) * wdt
    rc, pr = zip(*[val(c, m) for c, _ in cls])
    ax[0].bar(x, rc, wdt, color=col, label=lab, edgecolor='white', linewidth=0.2)
    ax[1].bar(x, [p if p == p else 0 for p in pr], wdt, color=col, edgecolor='white', linewidth=0.2)
    for xi, p in zip(x, pr):
        if p != p: ax[1].text(xi, PLO + 0.003, 'n/a', rotation=90, fontsize=4.6, ha='center', va='bottom', color='#555555')
        elif p < PLO: ax[1].text(xi, PLO + 0.003, f'{p:.2f}', rotation=90, fontsize=4.6, ha='center', va='bottom', color='#333333')
for a_, t in zip(ax, ['recall', 'precision']):
    a_.set_xticks(np.arange(len(cls))); a_.set_xticklabels([l for _, l in cls], fontsize=5.8); a_.set_ylabel(t)
    a_.tick_params(axis='x', length=0)
ax[0].set_ylim(0, 1.05); ax[1].set_ylim(PLO, 1.005)
ax[1].axhline(0.99, color=RED, lw=0.8, ls='--', zorder=0); ax[1].text(4.62, 0.9915, 'target 0.99', color=RED, fontsize=5.8, va='bottom', ha='right')
h_, l_ = ax[0].get_legend_handles_labels()
fig.tight_layout(rect=(0, 0.09, 1, 1), w_pad=2.0); fig.legend(h_, l_, loc='lower center', ncol=6, fontsize=6.2, handlelength=1.2, columnspacing=1.2)
save(fig, 'fig_e3')

# ------------------------------------------------------------------ E4
nse = pd.DataFrame(json.load(open(OUT / 'g3_lstm/g3_lstm_nse.json')))
A = nse.filter(like='A_').mean(1); B = nse.filter(like='B_').mean(1); D = (A - B).dropna()
L = pd.read_csv(OUT / 'g3/g3_leakage_rows.csv')
fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.15))
ax[0].scatter(L.nse_neigh.clip(-1, 1), L.nse_copy.clip(-1, 1), s=1.6, color=BLUE, alpha=0.25, linewidths=0, rasterized=True)
ax[0].plot([-1, 1], [-1, 1], color=GREY, lw=0.6)
mx, my = L.nse_neigh.median(), L.nse_copy.median()
ax[0].scatter([mx], [my], s=28, marker='D', color=RED, edgecolor='white', linewidth=0.6, zorder=5)
ax[0].annotate(f'medians\n({mx:.2f}, {my:.2f})', (mx, my), xytext=(-0.95, 0.45), fontsize=6, color=RED,
               arrowprops=dict(arrowstyle='-', color=RED, lw=0.5))
ax[0].set_xlabel('NSE, nearest non-copy neighbour'); ax[0].set_ylabel('NSE, copy as predictor')
ax[0].set_title('(a) what a leaked copy is worth', fontsize=7, loc='left')
ax[1].scatter(B.clip(-1, 1), A.clip(-1, 1), s=4, color=BLUE, alpha=0.8, linewidths=0)
ax[1].plot([-1, 1], [-1, 1], color=GREY, lw=0.6)
ax[1].set_xlabel('LSTM NSE, B (other basins)'); ax[1].set_ylabel('LSTM NSE, A (copies added)')
ax[1].set_title('(b) controlled injection', fontsize=7, loc='left')
FX = pd.read_csv(OUT / 'e4fixed/records.csv')
curves = [(D, BLUE, '-', 'injection'),
          (FX[FX.has_copy].d_M.dropna(), RED, '-', 'fixed, copy'),
          (FX[~FX.has_copy].d_M.dropna(), GREY, ':', 'fixed, control')]
for v, c, ls, lab in curves:
    x = np.sort(v.clip(-0.5, 1.0).values); ax[2].step(x, np.arange(1, len(x) + 1) / len(x), color=c, lw=1.1, ls=ls, where='post', label=f'{lab} {v.median():+.3f}'.replace('-0.', '−0.'))
ax[2].axvline(0, color=GREY, lw=0.5); ax[2].axvline(0.05, color='#444444', lw=0.6, ls='--')

ax[2].set_xlim(-0.5, 1.0)
ax[2].set_xlabel(r'paired $\Delta$NSE per test basin'); ax[2].set_ylabel('ECDF')
ax[2].set_title('(c) copy-specific gain', fontsize=7, loc='left')
ax[2].legend(fontsize=5.5, loc='lower right', bbox_to_anchor=(1.04, 0.03), handlelength=1.2, title='median paired ΔNSE', title_fontsize=5.5)
fig.tight_layout(w_pad=1.2); save(fig, 'fig_e4')
print('figures written')
