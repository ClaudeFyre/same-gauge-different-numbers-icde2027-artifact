"""Generate E2-E4 tables, figure and number macros from gate outputs (no hand-copied numbers)."""
import json, math, pickle
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

import sys, os; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT as R, ART as P
O = P / 'paper'; OUT = P / 'out'
fmt = lambda x: f'{x:,}'
pc = lambda x, d=1: f'{x * 100:.{d}f}'
NUM = {}

# ======================= E2 =======================
g4 = json.load(open(OUT / 'g4/g4_summary.json')); chk = json.load(open(OUT / 'g4/g4x_checks.json'))
un = pd.read_csv(OUT / 'g4/g4_unstable_pairs.csv')
chains = [('LamaH-P3', 'Caravan-LamaH vs LamaH-CE'), ('LamaH-P2', 'GRDC-Caravan vs Caravan-LamaH'), ('BR', 'GRDC-Caravan vs CAMELS-BR')]
t = [r'\begin{table*}[t]\centering\small',
     r"\caption{E2: attribution of every divergent day. Tests are applied in a pre-registered order and the first test that applies assigns the cause. ``Explained'' = a named transformation of an upstream series reproduces the copy; ``localized'' = the divergence is placed on one edge of the lineage graph without a named transformation.}",
     r'\label{tab:e2}', r'\begin{tabular}{@{}lrrrl>{\raggedright\arraybackslash}p{6.0cm}@{}}\toprule',
     r'Chain & Div.\ days & Explained & Localized & Verdict & Causes (days)\\\midrule']
short = {'L2 aggregation/day-boundary': 'aggregation window', 'L1 interpolation': 'LamaH gap interpolation', 'L3 scale segment': 'scale change',
         'L4 edge LamaH-CE->Caravan': r'edge LamaH-CE$\to$Caravan', 'L4 edge agency->LamaH-CE': r'edge agency$\to$LamaH-CE',
         'L4 GRDC differs from both LamaH products': 'GRDC differs from both LamaH copies', 'unresolved': 'unresolved',
         'B5 edge into Caravan/CAMELS-BR branch': r'edge ANA$\to$CAMELS-BR branch', 'B5 edge into GRDC branch': r'edge into GRDC branch',
         'unattributed (consistent with revision; not verifiable)': 'unattributed', 'B1 edge CAMELS-BR->Caravan': r'edge CAMELS-BR$\to$Caravan',
         'B2 raw-vs-consistido': 'raw vs.\\ checked level', 'B4 scale segment': 'scale change'}
EXPL = ('L1', 'L2', 'L3', 'B2', 'B4'); LOC = ('L4', 'B1', 'B5')
def shares(k):
    cz = g4[k]['causes']; n = sum(cz.values())
    return sum(v for c, v in cz.items() if c[:2] in EXPL) / n, sum(v for c, v in cz.items() if c[:2] in LOC) / n
for k in g4:
    if k in ('LamaH-P3', 'LamaH-P2', 'BR'): g4[k]['explained'], g4[k]['localized'] = shares(k)
for k, lab in chains:
    s = g4[k]; cs = sorted(s['causes'].items(), key=lambda x: -x[1])
    causes = '; '.join(f"{short.get(c, c)} {fmt(n)}" for c, n in cs)
    t.append(f"{lab} & {fmt(s['divergent_days'])} & {pc(s['explained'])}\\% & {pc(s['localized'])}\\% & \\textsc{{{s['verdict'].lower()}}} & {causes}" + r'\\')
t += [r'\bottomrule\end{tabular}\end{table*}']
# v4 layout (review): one column per standard cause category, as % of divergent days
CAT = {'L2 aggregation/day-boundary': 'win', 'L1 interpolation': 'interp', 'L3 scale segment': 'scale', 'B4 scale segment': 'scale',
       'B2 raw-vs-consistido': 'raw', 'L4 edge agency->LamaH-CE': 'src', 'B5 edge into Caravan/CAMELS-BR branch': 'src',
       'L4 edge LamaH-CE->Caravan': 'copy', 'B1 edge CAMELS-BR->Caravan': 'copy', 'L4 GRDC differs from both LamaH products': 'other',
       'B5 edge into GRDC branch': 'other', 'unresolved': 'unres', 'unattributed (consistent with revision; not verifiable)': 'unres'}
cols = [('win', 'Time\\\\window'), ('interp', 'Gap\\\\interp.'), ('scale', 'Scale\\\\change'), ('raw', 'Raw vs.\\\\checked'),
        ('src', 'Edge: source\\\\$\\to$ dataset'), ('copy', 'Edge: dataset\\\\$\\to$ copy'), ('other', 'Edge: other\\\\branch'), ('unres', 'Unre-\\\\solved')]
t = [r'\begin{table*}[t]\centering\small\setlength{\tabcolsep}{2.6pt}',
     r"\caption{E2: attribution of every divergent day, as \% of the chain's divergent days. Tests run in a pre-registered order and the first applicable test assigns the cause. The first four columns are \emph{explained} (a named transformation reproduces the copy), the three edge columns are \emph{localised} (the difference is placed on one lineage edge).}",
     r'\label{tab:e2}', r'\begin{tabular}{@{}lr' + 'c' * len(cols) + r'l@{}}\toprule',
     'Chain & Div.\\ days & ' + ' & '.join(r'\shortstack{' + h + '}' for _, h in cols) + r' & Verdict\\\midrule']
for k, lab in chains:
    s = g4[k]; n = sum(s['causes'].values()); agg = {c: 0 for c, _ in cols}
    for c, v in s['causes'].items(): agg[CAT.get(c, 'unres')] += v
    cells = [('--' if agg[c] == 0 else (f'{agg[c] / n * 100:.1f}' if agg[c] / n >= 0.001 else '$<$0.1')) for c, _ in cols]
    lab = {'LamaH-P3': 'Car.-LamaH / LamaH-CE', 'LamaH-P2': 'GRDC-C. / Car.-LamaH', 'BR': 'GRDC-C. / CAMELS-BR'}[k]
    t.append(f"{lab} & {fmt(s['divergent_days'])} & " + ' & '.join(cells) + f" & \\textsc{{{s['verdict'].lower()}}}" + r'\\')
t += [r'\bottomrule\end{tabular}\end{table*}']
(O / 'tables/tab_e2.tex').write_text('\n'.join(t), encoding='utf-8')
for k, m in [('LamaH-P3', 'LaC'), ('LamaH-P2', 'LaG'), ('BR', 'BR')]:
    NUM[f'expl{m}'] = pc(g4[k]['explained']); NUM[f'loc{m}'] = pc(g4[k]['localized']); NUM[f'div{m}'] = fmt(g4[k]['divergent_days'])
c = g4['BR']['causes']; n = g4['BR']['divergent_days']
NUM['brBfiveCar'] = pc(c['B5 edge into Caravan/CAMELS-BR branch'] / n, 0); NUM['brBfiveGRDC'] = pc(c['B5 edge into GRDC branch'] / n, 0)
NUM['brUnattr'] = pc(c['unattributed (consistent with revision; not verifiable)'] / n, 0)
NUM['brBone'] = fmt(c.get('B1 edge CAMELS-BR->Caravan', 0)); NUM['brBtwo'] = fmt(c.get('B2 raw-vs-consistido', 0))
c = g4['LamaH-P2']['causes']; NUM['laGgrdcBoth'] = pc(c['L4 GRDC differs from both LamaH products'] / g4['LamaH-P2']['divergent_days'], 0)
NUM['laInterp'] = fmt(g4['LamaH-P3']['causes'].get('L1 interpolation', 0) + g4['LamaH-P2']['causes'].get('L1 interpolation', 0))
w = chk['P3_share_matched_by_window']; NUM['winSample'] = fmt(chk['P3_sample_divergent_days'])
NUM.update(winShift=pc(w['shift-1h']), winCal=pc(w['calendar 00-24']), winSeven=pc(w['07-07']), winPrevSeven=pc(w['prev07-07']),
           winPlaceboLo=pc(min(w['PLACEBO +12h'], w['PLACEBO +3d'], w['PLACEBO -3d'])), winPlaceboHi=pc(max(w['PLACEBO +12h'], w['PLACEBO +3d'], w['PLACEBO -3d'])))
qc = chk['BR_cause_by_camelsbr_qc']
NUM['brQcBfive'] = pc(qc["('B5 edge into Caravan/CAMELS-BR branch', 1.0)"], 0); NUM['brQcAll'] = pc(chk['CAMELSBR_qc_share_all_days_same_gauges']['1.0'], 0)
per = chk['BR_cause_by_period']
NUM['brPreTwoK'] = pc(per['<2000']['B5 edge into Caravan/CAMELS-BR branch'], 0); NUM['brNoughties'] = pc(per['2000-09']['B5 edge into Caravan/CAMELS-BR branch'], 0)
NUM['brLateLo'] = pc(min(per['2010-14']['B5 edge into Caravan/CAMELS-BR branch'], per['>=2015']['B5 edge into Caravan/CAMELS-BR branch']), 0)
NUM['brLateHi'] = pc(max(per['2010-14']['B5 edge into Caravan/CAMELS-BR branch'], per['>=2015']['B5 edge into Caravan/CAMELS-BR branch']), 0)
NUM['brUnattrLateLo'] = pc(min(per['2010-14']['unattributed (consistent with revision; not verifiable)'], per['>=2015']['unattributed (consistent with revision; not verifiable)']), 0)
NUM['brUnattrLateHi'] = pc(max(per['2010-14']['unattributed (consistent with revision; not verifiable)'], per['>=2015']['unattributed (consistent with revision; not verifiable)']), 0)
for ch, m in [('LamaH-P3', 'LaC'), ('BR', 'BR'), ('LamaH-P2', 'LaG')]:
    u = un[un.chain == ch]
    NUM[f'unN{m}'] = fmt(len(u)); NUM[f'unRk{m}'] = f"{u.rolling_k_max_over_min.median():.3f}"
    NUM[f'unRkNinety{m}'] = f"{u.rolling_k_max_over_min.quantile(.9):.2f}"; NUM[f'unCp{m}'] = fmt(int(u.single_changepoint.sum()))
st = chk['BR_ana_status_raw_on_divergent_days']
NUM['anaStOne'] = fmt(int(st.get('1.0', 0))); NUM['anaStTwo'] = fmt(int(st.get('2.0', 0)))

# Figure 2: window/placebo bars + BR cause by period
fig, ax = plt.subplots(2, 1, figsize=(3.45, 4.1), gridspec_kw=dict(height_ratios=[1.1, 1]))
order = [('calendar 00-24', 'calendar day'), ('shift-1h', 'shifted −1 h'), ('07-07', '07–07 h'), ('prev07-07', 'prev. 07–07 h'),
         ('PLACEBO +12h', '+12 h*'), ('PLACEBO +3d', '+3 d*'), ('PLACEBO -3d', '−3 d*')]
vals = [w[k] * 100 for k, _ in order]; cols = ['#1f5fa8'] * 4 + ['#b0b0b0'] * 3
ax[0].barh(range(len(order))[::-1], vals, color=cols); ax[0].set_yticks(range(len(order))[::-1]); ax[0].set_yticklabels([l for _, l in order], fontsize=7)
ax[0].set_xlabel('divergent days reproduced (%)', fontsize=7.5); ax[0].set_title('(a) daily windows of LamaH hourly data', fontsize=7.5, loc='left')
for i, v in zip(range(len(order))[::-1], vals): ax[0].text(v + 1.2, i, f'{v:.1f}', va='center', fontsize=7)
ax[0].set_xlim(0, 95)
per_df = pd.DataFrame(per)[['<2000', '2000-09', '2010-14', '>=2015']]
groups = [('B5 edge into Caravan/CAMELS-BR branch', r'ANA$\to$CAMELS-BR edge', '#1f5fa8'), ('B5 edge into GRDC branch', 'GRDC edge', '#7fa7d6'),
          ('unattributed (consistent with revision; not verifiable)', 'unattributed', '#c8c8c8')]
bottom = np.zeros(per_df.shape[1])
for key, lab, colr in groups:
    v = per_df.loc[key].values * 100 if key in per_df.index else np.zeros(per_df.shape[1])
    ax[1].bar(range(per_df.shape[1]), v, bottom=bottom, color=colr, label=lab); bottom += v
ax[1].set_xticks(range(per_df.shape[1])); ax[1].set_xticklabels(['<2000', '2000–09', '2010–14', '≥2015'], fontsize=7)
ax[1].set_ylabel('share of divergent\ndays (%)', fontsize=7.5); ax[1].set_title('(b) Brazilian chain: attributed edge by period', fontsize=7.5, loc='left')
ax[1].legend(fontsize=6.5, frameon=False, loc='upper center', bbox_to_anchor=(0.42, -0.12), ncol=2)
for a in ax: a.spines[['top', 'right']].set_visible(False); a.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(O / 'fig/fig_e2.pdf'); fig.savefig(O / 'fig/fig_e2.png', dpi=150)

# ======================= E3 =======================
g2 = json.load(open(OUT / 'g2/g2_summary.json'))
cls = [('c1', 'scaling only'), ('c2', '+ coarser rounding'), ('c3', '+ 40\\% window'), ('c4', 'divergent ($\\ge$5\\%)'), ('c5', 'metadata degraded'), ('c6', 'scale-unstable$^\\dagger$')]
meth = ['M0', 'M1', 'M2', 'M3', 'M4']
t = [r'\begin{table*}[t]\centering\small',
     r"\caption{E3: existing rules for finding copies without identifiers, as precision / recall pooled over four regions. Only M3 reaches precision 0.99, in one class and at 1\% recall (48 matches, none false). Best recall per row in bold. $^\dagger$Reported only; not part of the pre-registered rule.}",
     r'\label{tab:e3}', r'\begin{tabular}{@{}lrccccc@{}}\toprule',
     r'Class & Positives & M0 coords+area & M1 $R^2{>}0.99$ & M2 GSIM rule & M3 exact hash & M4 quant.\ floor\\\midrule']
for cid, lab in cls:
    s = g2['pooled'][cid]; best = max(s[m]['recall'] for m in meth)
    cells = []
    for m in meth:
        pr, rc = s[m]['precision'], s[m]['recall']
        ptxt = '--' if (pr is None or (isinstance(pr, float) and math.isnan(pr))) else f'{pr:.2f}'
        rtxt = f'{rc:.2f}'; rtxt = r'\textbf{' + rtxt + '}' if rc == best else rtxt
        cells.append(f'{ptxt} / {rtxt}')
    t.append(f"{lab} & {fmt(s['M0']['P'])} & " + ' & '.join(cells) + r'\\')
t += [r'\bottomrule\end{tabular}\end{table*}']
(O / 'tables/tab_e3.tex').write_text('\n'.join(t), encoding='utf-8')
NUM.update(gtwoPos=fmt(g2['counts']['positives']), gtwoNeg=fmt(g2['counts']['negatives']), gtwoHard=fmt(g2['counts']['hard']))
c1 = g2['pooled']['c1']; c5 = g2['pooled']['c5']; c2 = g2['pooled']['c2']; c4 = g2['pooled']['c4']
NUM.update(mfourPrecOne=f"{c1['M4']['precision']:.3f}", mfourFpOne=fmt(c1['M4']['fp']), mzeroRecFive=f"{c5['M0']['recall']:.2f}",
           mtwoRecFive=f"{c5['M2']['recall']:.2f}", mthreeRecOne=f"{c1['M3']['recall']:.3f}", mfourRecTwo=f"{c2['M4']['recall']:.2f}",
           precFourLo=f"{min(c4[m]['precision'] for m in ['M0', 'M1', 'M2', 'M4']):.2f}", precFourHi=f"{max(c4[m]['precision'] for m in ['M0', 'M1', 'M2', 'M4']):.2f}")
sens = json.load(open(OUT / 'g2/g2x_sensitivity_excl_1km_negatives.json'))
NUM.update(sensMfour=f"{sens['c1']['M4'][0]:.3f}", sensMone=f"{sens['c1']['M1'][0]:.3f}", sensMtwo=f"{sens['c1']['M2'][0]:.3f}")
# false-positive diagnosis (recomputed from rows + cached metadata)
Rr = pd.read_parquet(OUT / 'g2/g2_rows.parquet'); meta = pickle.load(open(P / 'cache/g2_meta.pkl', 'rb'))['meta']
def hav(a, b):
    p = math.pi / 180; x = math.sin((b['lat'] - a['lat']) * p / 2) ** 2 + math.cos(a['lat'] * p) * math.cos(b['lat'] * p) * math.sin((b['lon'] - a['lon']) * p / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(x))
fp = Rr[(Rr.cls == 'c1') & (Rr.label == 0) & Rr.M4]
dist = [hav(meta[eval(a)], meta[eval(b)]) for a, b in zip(fp.a, fp.b)]
negs = Rr[Rr.label == 0][['a', 'b']].drop_duplicates()
near = sum(hav(meta[eval(a)], meta[eval(b)]) < 1 for a, b in zip(negs.a, negs.b))
NUM.update(fpN=fmt(len(fp)), fpHard=fmt(int((fp.kind == 'hard').sum())), fpMedKm=f"{np.median(dist):.1f}", negNearOneKm=fmt(near))

# ======================= E4 =======================
g3 = json.load(open(OUT / 'g3/g3_summary.json')); ls = json.load(open(OUT / 'g3_lstm/g3_lstm_summary.json'))
nse = pd.DataFrame(json.load(open(OUT / 'g3_lstm/g3_lstm_nse.json')))
A = nse.filter(like='A_').mean(1); B = nse.filter(like='B_').mean(1); dd = (A - B).dropna()
la, lp = g3['leakage_all'], g3['leakage_P2_only']
t = [r'\begin{table}[t]\centering\small',
     r"\caption{E4: what duplicates do (medians over test basins). Copy predictor: the training-side duplicate, rescaled; neighbour: the nearest non-copy training basin. LSTM A: duplicates in training; B: 200 other basins instead (3 seeds each).}",
     r'\label{tab:e4}', r'\begin{tabular}{@{}lr@{}}\toprule', r'Setting & Median NSE\\\midrule',
     r'\multicolumn{2}{@{}l}{\emph{Random 80/20 basin splits (10 seeds)}}\\',
     f"\\quad copy predictor & {la['median_nse_copy']:.4f}\\\\",
     f"\\quad nearest non-copy neighbour & {la['median_nse_neigh']:.3f}\\\\",
     r'\multicolumn{2}{@{}l}{\emph{Trained LSTM, 200 duplicated test basins}}\\',
     f"\\quad A: duplicates in training & {A.median():.3f}\\\\",
     f"\\quad B: no duplicates & {B.median():.3f}\\\\",
     f"\\quad paired difference A$-$B & +{dd.median():.3f}\\\\",
     r'\bottomrule\end{tabular}\end{table}']
(O / 'tables/tab_e4.tex').write_text('\n'.join(t), encoding='utf-8')
NUM.update(leakShare=pc(la['mean_affected_share']), leakShareP=pc(lp['mean_affected_share']), leakRows=fmt(la['affected_rows']),
           leakNseCopy=f"{la['median_nse_copy']:.4f}", leakNseNeigh=f"{la['median_nse_neigh']:.3f}", leakGain=f"{la['median_gain']:.2f}", leakGainP=f"{lp['median_gain']:.2f}",
           lstmA=f"{A.median():.3f}", lstmB=f"{B.median():.3f}", lstmD=f"{dd.median():.3f}", lstmDqOne=f"{dd.quantile(.25):.3f}", lstmDqThree=f"{dd.quantile(.75):.3f}",
           lstmPos=pc((dd > 0).mean()), lstmMin=f"{nse.min().min():,.0f}",
           valRecords=fmt(g3['validation']['vs_records']), valGauges=fmt(g3['validation']['gauges']), valShare=pc(g3['validation']['share_gt005']),
           valMed=f"{g3['validation']['median_dkge']:.4f}")
NUM['lstmP'] = f"{ls['wilcoxon_p']:.0e}".replace('e-', '\\times10^{-') + '}'

lines = ['% generated by make_tables2.py; do not edit'] + [f'\\newcommand{{\\num{k}}}{{{v}}}' for k, v in NUM.items()]
(O / 'numbers2.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps(NUM, indent=0))
