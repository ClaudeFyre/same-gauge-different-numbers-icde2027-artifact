"""Tables VI (tab_e3) and VIII (tab_e3bounds) with the learned matcher of X1 (PLAN_R3_EXTENSIONS) added as a column, and macros
for X1-X4. Run after make_tables2.py and make_tables7.py (it overwrites only these two tables; no figures)."""
import json, math
from pathlib import Path
import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT as _R, ART as _A
P = _A; O = P / 'paper'; OUT = P / 'out'
g2 = json.load(open(OUT / 'g2/g2_summary.json')); X1 = json.load(open(OUT / 'x1/x1_summary.json'))['per_class']
b = json.load(open(OUT / 'e3verify/summary.json'))['bounds']
fmt = lambda n: f'{n:,}'
cls = [('c1', 'scaling only'), ('c2', '+ coarser rounding'), ('c3', '+ 40\\% window'), ('c4', 'divergent ($\\ge$5\\%)'), ('c5', 'metadata degraded'), ('c6', 'scale-unstable$^\\dagger$')]
meth = ['M0', 'M1', 'M2', 'M3', 'M4']
t = [r'\begin{table*}[t]\centering\small',
     r"\caption{E3: rules for finding copies without identifiers, and a learned matcher (ML; gradient boosting, trained leave-one-region-out), as precision / recall pooled over four regions. Among the rules only M3 reaches precision 0.99, in one class and at 1\% recall; ML reaches it on clean and on metadata-degraded copies. Best recall per row in bold. $^\dagger$Reported only; not part of the pre-registered rule.}",
     r'\label{tab:e3}', r'\begin{tabular}{@{}lrcccccc@{}}\toprule',
     r'Class & Positives & M0 coords+area & M1 $R^2{>}0.99$ & M2 GSIM rule & M3 exact hash & M4 quant.\ floor & ML learned\\\midrule']
for cid, lab in cls:
    s = g2['pooled'][cid]; x = X1[cid]['original']
    allr = [s[m]['recall'] for m in meth] + [x['recall']]; best = max(allr)
    cells = []
    for pr, rc in [(s[m]['precision'], s[m]['recall']) for m in meth] + [(x['precision'], x['recall'])]:
        ptxt = '--' if (pr is None or (isinstance(pr, float) and math.isnan(pr))) else f'{pr:.2f}'
        rtxt = f'{rc:.2f}'; rtxt = r'\textbf{' + rtxt + '}' if rc == best else rtxt
        cells.append(f'{ptxt} / {rtxt}')
    t.append(f"{lab} & {fmt(s['M0']['P'])} & " + ' & '.join(cells) + r'\\')
t += [r'\bottomrule\end{tabular}\end{table*}']
(O / 'tables/tab_e3.tex').write_text('\n'.join(t), encoding='utf-8')
cls2 = [('c1', 'scaling only'), ('c2', '+ coarse rounding'), ('c3', '+ 40\\% window'), ('c4', 'divergent ($\\ge$5\\%)'), ('c5', 'metadata degraded')]
t = [r'\begin{table}[t]\centering\scriptsize\setlength{\tabcolsep}{1.5pt}',
     r"\caption{E3 precision after metadata-only verification of the 581 questionable negatives (Table~\ref{tab:e3}): lower bound (unresolved pairs stay negatives) -- upper bound (unresolved pairs count as copies). Bold: reaches the pre-registered 0.99 at the upper bound.}",
     r'\label{tab:e3bounds}', r'\begin{tabular}{@{}lccccc@{}}\toprule', r'Class & M0 & M1 & M2 & M4 & ML\\\midrule']
for c, lab in cls2:
    cells = []
    for lo, hi in [(b[c][m]['lower']['precision'], b[c][m]['upper']['precision']) for m in ['M0', 'M1', 'M2', 'M4']] + [(X1[c]['lower']['precision'], X1[c]['upper']['precision'])]:
        s = f'{lo:.3f}--{hi:.3f}' if lo is not None else '--'
        cells.append((r'\textbf{' + s + '}') if (hi or 0) >= 0.99 else s)
    t.append(lab + ' & ' + ' & '.join(cells) + r'\\')
t += [r'\bottomrule\end{tabular}\end{table}']
(O / 'tables/tab_e3bounds.tex').write_text('\n'.join(t), encoding='utf-8')
# ---- macros X1, X3, X4 (X2 added when its summary exists)
x1s = json.load(open(OUT / 'x1/x1_summary.json')); c1, c5 = X1['c1']['original'], X1['c5']['original']
x3 = json.load(open(OUT / 'x3/x3_summary.json')); v1, v2 = x3['V1'], x3['V2']
x4 = json.load(open(OUT / 'x4/x4_summary.json'))
NUM = dict(mlPrecOne=f"{c1['precision']:.3f}", mlRecOne=f"{c1['recall']:.2f}", mlPrecFive=f"{c5['precision']:.3f}", mlRecFive=f"{c5['recall']:.2f}",
           mlFpOne=str(c1['fp']), mlRecTwo=f"{X1['c2']['original']['recall']:.2f}", mlRecThree=f"{X1['c3']['original']['recall']:.2f}",
           mlFpOneCopy=str(x1s['errors']['ML']['false_matches_c1']['verified_copy']),
           mfourFpNear=str(x1s['errors']['M4']['false_matches_c1']['within_50km']), mfourFpNearCopy=str(x1s['errors']['M4']['false_matches_c1']['verified_copy']),
           mfourFpNearUnres=str(x1s['errors']['M4']['false_matches_c1']['unresolved']), mfourFpNearOther=str(x1s['errors']['M4']['false_matches_c1']['other_near']),
           mfourMissTwo=fmt(x1s['errors']['M4']['c2']['missed_positives']),
           vtwoDays=fmt(v2['div_days']), vtwoNewAgree=f"{v2['v12_agree_div'] * 100:.1f}", vtwoOldAgree=f"{v2['v11_agree_div'] * 100:.1f}",
           vtwoCtl=f"{v2['v12_agree_ctl'] * 100:.1f}", vtwoStations=str(v2['stations']),
           voneDiv=f"{v1['share_later_div'] * 100:.0f}", voneCtl=f"{v1['share_later_ctl'] * 100:.0f}",
           synChains=str(x4['chains']), synLoc=f"{x4['localisation_accuracy'] * 100:.0f}", synName=f"{x4['naming_precision'] * 100:.0f}",
           synFalse=f"{x4['false_divergence_T0'] * 100:.4f}")
import pandas as pd
Ch = pd.read_csv(OUT / 'x4/x4_chains.csv'); Ch['E'] = Ch.edges.apply(json.loads)
Ch['bu'] = [any(v is not None and not v['stable'] for k, v in e.items() if k != pl) for e, pl in zip(Ch.E, Ch.edge)]
pl_ = Ch[Ch.kind != 'T0']; ok = pl_.pred_edge == pl_.edge
NUM.update(synLocStable=f"{ok[~pl_.bu].mean() * 100:.0f}", synLocUnstable=f"{ok[pl_.bu].mean() * 100:.0f}", synNStable=str(int((~pl_.bu).sum())),
           synNUnstable=str(int(pl_.bu.sum())), synTzeroUnstable=f"{Ch[Ch.kind == 'T0'].bu.mean() * 100:.0f}")
x2p = OUT / 'e4extremes/x2_summary.json'
if x2p.exists():
    x2 = json.load(open(x2p)); m = x2['M']
    sg = lambda v: (f'{v:+.1f}' if abs(v) >= 0.05 else f'{v:+.2f}').replace('-', '$-$')
    NUM.update(xfhvMed=sg(m['fhv']['median']), xfhvLo=sg(m['fhv']['ci'][0]), xfhvHi=sg(m['fhv']['ci'][1]), xfhvNeg=sg(m['fhv']['negative_control']),
               xamaxMed=f"{m['amax']['median']:+.3f}".replace('-', '$-$'), xamaxLo=f"{m['amax']['ci'][0]:+.3f}".replace('-', '$-$'), xamaxHi=f"{m['amax']['ci'][1]:+.3f}".replace('-', '$-$'),
               xfhvPool=sg(m['pooled_fhv']['mean']), xfhvPoolLo=sg(m['pooled_fhv']['ci'][0]), xfhvPoolHi=sg(m['pooled_fhv']['ci'][1]),
               xfhvAbs=f"{sum(v for k, v in x2['median_abs_fhv'].items() if k.startswith('W')) / 5:.0f}")
(O / 'numbers16.tex').write_text('% generated by make_tables9.py\n' + '\n'.join(f'\\newcommand{{\\num{k}}}{{{v}}}' for k, v in NUM.items()) + '\n', encoding='utf-8')
print(NUM)
