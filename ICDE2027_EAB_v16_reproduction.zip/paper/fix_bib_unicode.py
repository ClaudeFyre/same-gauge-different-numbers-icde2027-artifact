"""Replace characters pdflatex cannot typeset in refs.bib (primes/curly apostrophes, G-breve)."""
from pathlib import Path
p = Path(__file__).with_name('refs.bib')
s = p.read_text(encoding='utf-8')
rep = {chr(0x2032): "'", chr(0x2019): "'", chr(0x2018): "'", chr(0x011E): r'{\u{G}}', chr(0x201C): '``', chr(0x201D): "''"}
for a, b in rep.items():
    s = s.replace(a, b)
p.write_text(s, encoding='utf-8')
print('remaining non-ascii:', sorted({c for c in s if ord(c) > 127}, key=ord).__len__())
