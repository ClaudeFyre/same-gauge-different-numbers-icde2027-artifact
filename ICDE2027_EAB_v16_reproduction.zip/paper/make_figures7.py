"""make_figures7.py: unified visual style for paper v16 (2026-11-08): map, E2, worked examples, E3, E4.
Same data, selections and assertions as make_figures6.py / make_tables2.py; only presentation changes.
One palette across all figures (validated for colour-vision deficiency):
  blue = faithful / reference series, red = diverging copy or edge, amber = learned matcher, grey = neutral / control.
Run last in README step 8, after make_figures3.py, make_tables2.py and make_figures6.py (it overwrites their figure files)."""
import json, warnings, re
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Rectangle
warnings.filterwarnings('ignore')
import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT as R, ART as P
O = P / 'paper'; OUT = P / 'out'

INK, MUTED, GRID = '#1F2A33', '#5F6B75', '#D9DEE2'
BLUE, LBLUE, RED, LRED, AMBER, GREY, LGREY = '#2E6DA4', '#9CC0E0', '#C8553D', '#EDB09E', '#D9952A', '#8E979F', '#D3D8DC'
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Times New Roman', 'STIXGeneral'], 'mathtext.fontset': 'stix',
    'font.size': 8, 'axes.titlesize': 8, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7,
    'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.6, 'axes.edgecolor': '#6E7880',
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'xtick.major.size': 2.5, 'ytick.major.size': 2.5,
    'xtick.color': MUTED, 'ytick.color': MUTED, 'xtick.labelcolor': INK, 'ytick.labelcolor': INK,
    'text.color': INK, 'axes.labelcolor': INK, 'axes.titleweight': 'bold', 'axes.titlelocation': 'left', 'axes.titlepad': 4,
    'legend.frameon': False, 'pdf.fonttype': 42, 'savefig.dpi': 300})
N3 = dict(re.findall(r'\\newcommand\{\\num(\w+)\}\{([^}]*)\}', (O / 'numbers3.tex').read_text(encoding='utf-8')))
def save(fig, name):
    fig.savefig(O / f'fig/{name}.pdf', bbox_inches='tight', pad_inches=0.02)
    fig.savefig(O / f'fig/{name}.png', dpi=200, bbox_inches='tight', pad_inches=0.02); plt.close(fig)
def hgrid(ax, axis='y'):
    ax.grid(axis=axis, color=GRID, lw=0.5); ax.set_axisbelow(True)

# ------------------------------------------------------------------ map
import zipfile
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
# HydroBASINS level 1 land outline: optional input (README); without it the map has no background.
HB = [R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip' for reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']]
land = None
if all(z.exists() for z in HB):
    import geopandas as gpd
    land = pd.concat([gpd.read_file(f'zip://{z}!' + z.name.replace('_lev01-12_v1c.zip', '_lev01_v1c.shp')) for z in HB]).geometry
else:
    print('HydroBASINS not found under REPUB_ROOT/data/HydroBASINS: map drawn without land outline')
CAR = R / 'data/Caravan/extracted/Caravan-nc/attributes'
coords = pd.concat([pd.read_csv(CAR / f'{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon']]
                    for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']])
gz = zipfile.ZipFile(R / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip')
coords = pd.concat([coords, pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon']]]).drop_duplicates('gauge_id').set_index('gauge_id')
g1 = pd.read_csv(OUT / 'g1/g1_pairs.csv'); st = g1[g1.stable].copy(); st['rate'] = st.real / st.n
st['gid'] = [r.a if r.pair.startswith('P3') else r.b for r in st.itertuples()]
st = st[st.gid.isin(coords.index)]
st['lat'] = coords.loc[st.gid, 'gauge_lat'].values; st['lon'] = coords.loc[st.gid, 'gauge_lon'].values
assert f'{len(st):,}' == N3['mapGauges'], (len(st), N3['mapGauges'])
# diverging around the 1% line that separates faithful (blue) from diverging (red) chains in E1
bins = [(-1, 0.001, '#A9C6E2', '< 0.1%', 1.4), (0.001, 0.01, BLUE, '0.1–1%', 2.6),
        (0.01, 0.05, '#E39079', '1–5%', 4.0), (0.05, 2, '#A3301E', '≥ 5%', 5.2)]
def draw(ax, scale=1.0):
    for z, (lo, hi, c, lab, s) in enumerate(bins):
        d = st[(st.rate > lo) & (st.rate <= hi)] if lo >= 0 else st[st.rate <= hi]
        ax.scatter(d.lon, d.lat, s=s * scale, c=c, label=f'{lab}  ({len(d):,})', linewidths=0, zorder=2 + z)
fig, ax = plt.subplots(figsize=(7.0, 2.55))
if land is not None: land.simplify(0.2).plot(ax=ax, color='#F1F2F3', edgecolor='#DADDE0', linewidth=0.25)
draw(ax)
ax.set_xlim(-168, 180); ax.set_ylim(-47, 72); ax.set_axis_off()
ax.legend(loc='lower left', bbox_to_anchor=(0.0, 0.03), markerscale=1.8, handletextpad=0.3, labelspacing=0.35,
          title='E1 divergence rate (pairs)', title_fontsize=7, alignment='left')
ins = ax.inset_axes([0.655, 0.40, 0.25, 0.56])
if land is not None: land.clip_by_rect(5, 43, 22, 52).simplify(0.01).plot(ax=ins, color='#F1F2F3', edgecolor='#C9CED2', linewidth=0.3)
draw(ins, scale=2.2)
ins.set_xlim(8.5, 18.5); ins.set_ylim(45.8, 49.6); ins.set_aspect(1 / np.cos(np.deg2rad(47.7)))
ins.set_xticks([]); ins.set_yticks([])
for s_ in ins.spines.values(): s_.set_visible(True); s_.set_color(MUTED); s_.set_linewidth(0.6)
ins.set_title('Austria and Bavaria (LamaH-CE)', fontsize=7, pad=2, weight='normal')
mark_inset(ax, ins, loc1=2, loc2=3, fc='none', ec=MUTED, lw=0.5)
save(fig, 'fig_map')

# ------------------------------------------------------------------ E2 (column figure): windows + Brazilian edge by period
chk = json.load(open(OUT / 'g4/g4x_checks.json'))
w = chk['P3_share_matched_by_window']
fig, ax = plt.subplots(2, 1, figsize=(3.45, 3.55), gridspec_kw=dict(height_ratios=[1.15, 1], hspace=0.62))
order = [('shift-1h', 'day shifted by −1 h', 'pre'), ('prev07-07', 'previous 07–07 h', 'pre'), ('calendar 00-24', 'calendar day (UTC)', 'pre'),
         ('07-07', '07–07 h', 'pre'), ('PLACEBO +3d', '+3 d (placebo)', 'pl'), ('PLACEBO -3d', '−3 d (placebo)', 'pl'), ('PLACEBO +12h', '+12 h (placebo)', 'pl')]
y = np.arange(len(order))[::-1]
for yi, (k, lab, kind) in zip(y, order):
    v = w[k] * 100
    col = RED if k == 'shift-1h' else (BLUE if kind == 'pre' else GREY)
    ax[0].barh(yi, v, height=0.62, color=col, hatch='////' if kind == 'pl' else None, edgecolor='white', lw=0)
    ax[0].text(v + 1.5, yi, f'{v:.1f}%', va='center', fontsize=7, color=INK, weight='bold' if k == 'shift-1h' else 'normal')
ax[0].axhline(y[3] - 0.5, color=GRID, lw=0.6, ls='-')
ax[0].text(97, y[3] - 0.5 + 0.12, 'pre-registered', ha='right', va='bottom', fontsize=6.3, color=MUTED, style='italic')
ax[0].text(97, y[3] - 0.5 - 0.12, 'placebo', ha='right', va='top', fontsize=6.3, color=MUTED, style='italic')
ax[0].set_yticks(y); ax[0].set_yticklabels([l for _, l, _ in order]); ax[0].tick_params(axis='y', length=0)
ax[0].set_xlim(0, 97); ax[0].set_xlabel('sampled divergent days reproduced (%)'); hgrid(ax[0], 'x')
ax[0].set_title('(a) Which daily window of LamaH hourly data?')
per = pd.DataFrame(chk['BR_cause_by_period'])[['<2000', '2000-09', '2010-14', '>=2015']]
groups = [('B5 edge into Caravan/CAMELS-BR branch', r'ANA$\to$CAMELS-BR edge', RED), ('B5 edge into GRDC branch', 'GRDC edge', LRED),
          ('unattributed (consistent with revision; not verifiable)', 'unattributed', LGREY)]
bottom = np.zeros(per.shape[1]); x = np.arange(per.shape[1])
for key, lab, colr in groups:
    v = per.loc[key].values * 100 if key in per.index else np.zeros(per.shape[1])
    ax[1].bar(x, v, 0.64, bottom=bottom, color=colr, label=lab, edgecolor='white', lw=0.8)
    for xi, vi, bi in zip(x, v, bottom):
        if vi >= 9: ax[1].text(xi, bi + vi / 2, f'{vi:.0f}', ha='center', va='center', fontsize=6.5,
                               color='white' if colr == RED else INK)
    bottom += v
ax[1].set_xticks(x); ax[1].set_xticklabels(['<2000', '2000–09', '2010–14', '≥2015']); ax[1].tick_params(axis='x', length=0)
ax[1].set_ylim(0, 100); ax[1].set_yticks([0, 50, 100]); ax[1].set_ylabel('divergent days (%)')
ax[1].set_title('(b) Brazil: attributed edge by period')
ax[1].legend(loc='upper left', bbox_to_anchor=(1.0, 1.0), handlelength=1.0, labelspacing=0.5, borderaxespad=0.2)
fig.subplots_adjust(right=0.70)
pos = ax[1].get_position(); ax[1].set_position([pos.x0, pos.y0, pos.width * 0.98, pos.height])
pos0 = ax[0].get_position(); ax[0].set_position([pos0.x0, pos0.y0, 0.95 - pos0.x0, pos0.height])
save(fig, 'fig_e2')

# ------------------------------------------------------------------ worked examples (same selections as make_figures6)
g4src = open(P / 'src/g4.py', encoding='utf-8').read()
G = {'__file__': str(P / 'src/g4.py')}; exec(compile(g4src.split('rows, unstable = [], []')[0], 'g4', 'exec'), G)
exec(compile(g4src[g4src.index('def camelsbr_m3s'):g4src.index('br_status = []')], 'g4b', 'exec'), G)
days = pd.read_parquet(OUT / 'g4/g4_days.parquet'); days['day'] = pd.to_datetime(days['day'])
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.2), gridspec_kw={'width_ratios': [1, 1.25]})
l2 = days[(days.chain == 'LamaH-P3') & (days.cause == 'L2 aggregation/day-boundary')]
b_id = l2.b.value_counts().index[0]; a_id = l2[l2.b == b_id].a.iloc[0]
assert str(b_id) == N3['exLamahGauge']
a = G['caravan'](a_id); b = G['lamah'](int(b_id))[0]
j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna(); k = float((j[j.b > 0].a / j[j.b > 0].b).median())
dd = l2[l2.b == b_id].day
rel = ((j.a - k * j.b).abs() / (k * j.b)).reindex(dd)
d0 = rel.idxmax(); t0, t1 = d0 - pd.Timedelta(days=3), d0 + pd.Timedelta(days=4)
fs = list(Path(G['HOURLY'][0]).glob(f'ID_{b_id}.csv'))[0]
h = pd.read_csv(fs, sep=';'); q = pd.Series(h.qobs.values.astype(float), index=pd.to_datetime(dict(year=h.YYYY, month=h.MM, day=h.DD, hour=h.hh, minute=h.mm))); q[q < 0] = np.nan
shift = q.copy().set_axis(q.index + pd.Timedelta(hours=1)).resample('D').mean()
qq = q[(q.index >= t0) & (q.index < t1 + pd.Timedelta(days=1))]
ax[0].fill_between(qq.index, 0, qq.values, color='#EEF1F3', lw=0)
ax[0].plot(qq.index, qq.values, color='#B5BDC4', lw=0.7, label='LamaH-CE hourly (UTC)')
rng = pd.date_range(t0, t1)
def steps(s, **kw):
    s = s.reindex(rng); x = np.r_[s.index.values, (s.index[-1] + pd.Timedelta(days=1)).to_datetime64()]
    ax[0].step(x, np.r_[s.values, s.values[-1]], where='post', **kw)
steps(b, color=INK, lw=1.4, label='LamaH-CE daily (UTC day)')
steps(a / k, color=RED, lw=1.4, ls=(0, (3.5, 1.5)), label='Caravan, rescaled')
steps(shift, color=BLUE, lw=1.0, ls=(0, (1, 1)), label='hourly mean, day shifted 1 h')
ax[0].set_ylim(bottom=0); ax[0].set_ylabel('discharge (m$^3$ s$^{-1}$)'); ax[0].legend(loc='upper left', handlelength=2.2, labelspacing=0.3)
ax[0].xaxis.set_major_locator(mdates.DayLocator()); ax[0].xaxis.set_major_formatter(mdates.DateFormatter('%d')); ax[0].set_xlabel(f"{d0.strftime('%B %Y')} (day)")
hgrid(ax[0])
ax[0].set_title(f'(a) LamaH gauge {b_id}: a one-hour window')
b5 = days[(days.chain == 'BR') & (days.cause == 'B5 edge into Caravan/CAMELS-BR branch')]
code_b = b5.b.value_counts().index[0]; ga = b5[b5.b == code_b].a.iloc[0]; code = code_b.split('_', 1)[1]
assert code == N3['exBrStation']
r1, r2, _ = G['ana'](code); c, _ = G['camelsbr_m3s'](code); g = G['grdc'](ga)
yr = b5[b5.b == code_b].day.dt.year.value_counts().index[0]
w0, w1 = pd.Timestamp(f'{yr}-01-01'), pd.Timestamp(f'{yr}-12-31')
jj = pd.concat([g.rename('g'), r2.rename('r')], axis=1).dropna(); kg = float((jj[jj.r > 0].g / jj[jj.r > 0].r).median())
for s, lab, col, ls, lw in [(c, 'CAMELS-BR 2020 (copied by Caravan)', RED, '-', 0.9), (r2, "ANA today", INK, '-', 0.8),
                            (g / kg, 'GRDC-Caravan, rescaled', BLUE, (0, (3, 1.5)), 0.9)]:
    s = s[(s.index >= w0) & (s.index <= w1)]; ax[1].plot(s.index, s.values, ls=ls, color=col, lw=lw, label=lab)
mk = b5[(b5.b == code_b) & (b5.day >= w0) & (b5.day <= w1)].day
assert f'{len(mk):,}' == N3['exBrDays']
ytop = ax[1].get_ylim()[1] * 1.30; yb = -0.06 * ytop
ax[1].scatter(mk, np.full(len(mk), yb), marker='|', s=16, color=RED, lw=0.6, label='divergent day on ANA$\\to$CAMELS-BR edge', clip_on=False)
ax[1].set_ylim(1.6 * yb, ytop); ax[1].axhline(0, color=GRID, lw=0.5)
ax[1].set_ylabel('discharge (m$^3$ s$^{-1}$)'); ax[1].legend(loc='upper left', handlelength=2.0, labelspacing=0.3)
ax[1].xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1, 3, 5, 7, 9, 11])); ax[1].xaxis.set_major_formatter(mdates.DateFormatter('%b'))
ax[1].set_xlabel(str(yr)); hgrid(ax[1])
ax[1].set_title(f'(b) ANA station {code}, {yr}: older vintage in CAMELS-BR')
fig.tight_layout(w_pad=1.8); save(fig, 'fig_examples')

# ------------------------------------------------------------------ E3: recall and precision as annotated grids
g2 = json.load(open(OUT / 'g2/g2_summary.json')); x1 = json.load(open(OUT / 'x1/x1_summary.json'))
cls = [('c1', 'c1\nscaling'), ('c2', 'c2\nre-rounding'), ('c3', 'c3\n40% window'), ('c4', 'c4\ndivergent'), ('c5', 'c5\nmeta. degr.')]
meth = [('M0', 'M0 coords + area'), ('M1', 'M1 $R^2>0.99$'), ('M2', 'M2 GSIM rule'), ('M3', 'M3 exact'), ('M4', 'M4 tolerance'), ('ML', 'ML learned')]
def val(c, m):
    s = x1['per_class'][c]['original'] if m == 'ML' else g2['pooled'][c][m]
    n = s['tp'] + s.get('fp', 0)
    return s['recall'], (s['precision'] if n > 0 else np.nan)
RC = np.array([[val(c, m)[0] for c, _ in cls] for m, _ in meth]); PR = np.array([[val(c, m)[1] for c, _ in cls] for m, _ in meth])
cm_r = LinearSegmentedColormap.from_list('r', ['#F4F7FA', '#9CC0E0', '#2E6DA4', '#163E66'])
cm_p = LinearSegmentedColormap.from_list('p', ['#FBF7F1', '#F3DFC0', '#E6B470', '#C5822A'])
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.05))
def grid(a, M, cmap, norm, fmt, title, target=None):
    nr, nc = M.shape
    for i in range(nr):
        for j_ in range(nc):
            v = M[i, j_]; y0 = nr - 1 - i + (0.0 if i < nr - 1 else -0.18)
            if v != v:
                a.add_patch(Rectangle((j_, y0), 1, 1, fc='white', ec=GRID, lw=0.5, hatch='////'))
                a.text(j_ + 0.5, y0 + 0.5, 'n/a', ha='center', va='center', fontsize=6.5, color=MUTED); continue
            col = cmap(norm(v)); a.add_patch(Rectangle((j_, y0), 1, 1, fc=col, ec='white', lw=1.0))
            lum = 0.299 * col[0] + 0.587 * col[1] + 0.114 * col[2]
            hit = target is not None and v >= target
            a.text(j_ + 0.5, y0 + 0.5, fmt(v), ha='center', va='center', fontsize=7,
                   color='white' if lum < 0.55 else INK, weight='bold' if hit else 'normal')
            if hit: a.add_patch(Rectangle((j_ + 0.06, y0 + 0.06), 0.88, 0.88, fc='none', ec=INK, lw=1.1))
    a.set_xlim(0, nc); a.set_ylim(-0.2, nr); a.set_aspect('auto')
    a.set_xticks(np.arange(nc) + 0.5); a.set_xticklabels([l for _, l in cls], fontsize=6.8); a.xaxis.tick_top()
    a.set_yticks([nr - 1 - i + 0.5 + (0 if i < nr - 1 else -0.18) for i in range(nr)]); a.set_yticklabels([l for _, l in meth])
    a.tick_params(length=0); [s.set_visible(False) for s in a.spines.values()]
    a.set_title(title, pad=22)
grid(ax[0], RC, cm_r, Normalize(0, 1), lambda v: f'{v:.2f}', '(a) recall')
grid(ax[1], PR, cm_p, Normalize(0.5, 1.0, clip=True), lambda v: f'{v:.3f}' if v >= 0.985 else f'{v:.2f}', '(b) precision', target=0.99)
ax[1].set_yticklabels([])
ax[1].text(5.0, -0.55, 'boxed: precision ≥ 0.99 (target)', ha='right', va='top', fontsize=6.5, color=MUTED, transform=ax[1].transData)
fig.tight_layout(w_pad=1.0)
save(fig, 'fig_e3')

# ------------------------------------------------------------------ E4
nse = pd.DataFrame(json.load(open(OUT / 'g3_lstm/g3_lstm_nse.json')))
A = nse.filter(like='A_').mean(1); B = nse.filter(like='B_').mean(1); D = (A - B).dropna()
L = pd.read_csv(OUT / 'g3/g3_leakage_rows.csv')
fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.15), gridspec_kw={'width_ratios': [1, 1, 1.3]})
cm_d = LinearSegmentedColormap.from_list('d', ['#DCE8F3', '#7FA9D3', '#2E6DA4', '#163E66'])
ax[0].hexbin(L.nse_neigh.clip(-1, 1), L.nse_copy.clip(-1, 1), gridsize=34, extent=(-1, 1, -1, 1.02), bins='log', mincnt=1, cmap=cm_d, lw=0.1, edgecolors='white')
ax[0].plot([-1, 1], [-1, 1], color=GREY, lw=0.6, ls='--')
mx, my = L.nse_neigh.median(), L.nse_copy.median()
ax[0].scatter([mx], [my], s=34, marker='D', color=RED, edgecolor='white', linewidth=0.8, zorder=5)
ax[0].annotate(f'medians ({mx:.2f}, {my:.2f})', (mx, my), xytext=(-0.95, 0.25), fontsize=6.8, color=RED,
               arrowprops=dict(arrowstyle='-', color=RED, lw=0.6))
ax[0].text(0.55, -0.62, 'equal skill', rotation=45, fontsize=6.3, color=MUTED, ha='center', va='center')
ax[0].set_xlabel('NSE, nearest non-copy neighbour'); ax[0].set_ylabel('NSE, copy as predictor')
ax[0].set_title('(a) What a leaked copy is worth')
ax[1].scatter(B.clip(-1, 1), A.clip(-1, 1), s=7, color=BLUE, alpha=0.75, linewidths=0.3, edgecolors='white')
ax[1].plot([-1, 1], [-1, 1], color=GREY, lw=0.6, ls='--')
up = float((D > 0).mean() * 100)
ax[1].text(-0.95, 0.92, f'{up:.0f}% of basins above\nthe diagonal', fontsize=6.8, color=INK, va='top')
ax[1].set_xlabel('LSTM NSE, B (other basins)'); ax[1].set_ylabel('LSTM NSE, A (copies added)')
ax[1].set_title('(b) Controlled injection')
for a_ in ax[:2]: a_.set_xlim(-1.05, 1.05); a_.set_ylim(-1.05, 1.07); a_.set_aspect('equal', adjustable='box'); a_.set_xticks([-1, 0, 1]); a_.set_yticks([-1, 0, 1])
FX = pd.read_csv(OUT / 'e4fixed/records.csv')
curves = [(D, BLUE, '-', 1.3, 'injection'),
          (FX[FX.has_copy].d_M.dropna(), RED, '-', 1.3, 'fixed, copy'),
          (FX[~FX.has_copy].d_M.dropna(), GREY, (0, (2, 1.2)), 1.1, 'fixed, control')]
ax[2].axvspan(-0.5, 0.05, color='#F3F4F5', lw=0, zorder=0)
for v, c_, ls, lw, lab in curves:
    x = np.sort(v.clip(-0.5, 1.0).values); ax[2].step(x, np.arange(1, len(x) + 1) / len(x), color=c_, lw=lw, ls=ls, where='post',
                                                      label=f'{lab}  {v.median():+.3f}'.replace('-0.', '−0.'))
ax[2].axvline(0, color=GREY, lw=0.5); ax[2].axvline(0.05, color=INK, lw=0.7, ls='--')
ax[2].set_xlim(-0.5, 1.0); ax[2].set_ylim(0, 1.02)
ax[2].set_xlabel(r'paired $\Delta$NSE per test basin'); ax[2].set_ylabel('cumulative share of basins')
ax[2].set_title('(c) Copy-specific gain')
ax[2].legend(loc='lower right', bbox_to_anchor=(1.04, 0.0), handlelength=1.1, handletextpad=0.4, labelspacing=0.25, title='median paired ΔNSE', title_fontsize=6.8, fontsize=6.6)
fig.tight_layout(w_pad=1.4); save(fig, 'fig_e4')
print('figures written')
