"""Generate paper tables/figures from gate outputs (no hand-copied numbers)."""
import json, zipfile, glob
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

import sys, os; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT as R, ART as P
O = P / 'paper'
g1 = json.load(open(P / 'out/g1/g1_summary.json')); pairs = pd.read_csv(P / 'out/g1/g1_pairs.csv')
mag = pd.read_csv(P / 'out/g1/g1x_magnitude.csv', index_col=0)
fmt = lambda x: f'{x:,}'
NUM = {}  # numbers quoted in text -> written to numbers.tex as macros

# ---------- Table 1: corpus
CAR = R / 'data/Caravan/extracted/Caravan-nc/attributes'
car = {s: len(pd.read_csv(CAR / f'{s}/attributes_other_{s}.csv')) for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']}
gz = zipfile.ZipFile(R / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip')
n_grdc = len(pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_additional_grdc.csv')))
n_lamah = len(pd.read_csv(R / 'icde_probe/raw/lamah/D_gauges/1_attributes/Gauge_attributes.csv', sep=';'))
n_lamah_h = len(glob.glob(str(R / 'data/LamaH-CE/extracted_hourly/D_gauges/2_timeseries/hourly/ID_*.csv')))
def gwse_station_count():
    """Unique (agency, id) over the archive's 8y and 30y discharge files; cached in out/ because streaming takes minutes."""
    cache = P / 'out/gwse_station_count.json'
    if cache.exists(): return json.load(open(cache))['n']
    from _stream import stream_array
    z = zipfile.ZipFile(R / 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396/Result datasets.zip'); keys = set()
    for w in ('8y', '30y'):
        for r in stream_array(z.open(f'Result datasets/Validation dataset/globe_gauge_discharge_data_{w}.json')):
            keys.add((str(r['agency']), str(r['id'])))
    json.dump(dict(n=len(keys)), open(cache, 'w')); return len(keys)
n_gw = gwse_station_count()
n_cbr = len([n for n in zipfile.ZipFile(R / 'data/Expansion_2026-10-19/CAMELS_BR/02_CAMELS_BR_streamflow_m3s.zip').namelist() if n.endswith('.txt')])
n_ana = len(json.load(open(R / 'data/Expansion_2026-10-19/ANA/manifest.json'))['items'])
rows = [
    ('Caravan v1.6 core', 'benchmark copy', fmt(sum(car.values())),
     r'\texttt{camels\_}/\texttt{hysets\_}: USGS or WSC no.; \texttt{lamah\_}: agency no.; \texttt{camelsbr\_}: ANA code; \texttt{camelsaus\_}: BoM id', r'mm\,d$^{-1}$'),
    ('GRDC-Caravan', 'benchmark copy', fmt(n_grdc), r'GRDC no.; \texttt{nat\_id} (national code)', r'mm\,d$^{-1}$'),
    ('LamaH-CE (daily / hourly)', 'source copy', f'{fmt(n_lamah)} / {fmt(n_lamah_h)}', r'agency no. (\texttt{govnr}); interpolated-gap records', r'm$^3$\,s$^{-1}$'),
    ('GlobalRiverWSE Q archive', 'validation copy', fmt(n_gw), 'provider + station no. (USGS, GRDC)', r'm$^3$\,s$^{-1}$'),
    ('CAMELS-BR v1.1', 'intermediate copy', fmt(n_cbr), 'ANA code; per-day ANA consistency flag', r'm$^3$\,s$^{-1}$'),
    ('ANA HidroSerieHistorica', 'root, re-fetched', fmt(n_ana), 'ANA code; level 1 (raw) / 2 (checked); per-day status', r'm$^3$\,s$^{-1}$'),
    ('USGS NWIS daily (VT, NH)', 'root, re-fetched', fmt(96), 'USGS no.; approval and estimate codes', r'ft$^3$\,s$^{-1}$'),
]
t = [r'\begin{table*}[t]\centering\small',
     r'\caption{Corpus. Counts are series held locally. Lineage keys serve as ground truth for copy identity and are never given to the matching rules of E3.}',
     r'\label{tab:corpus}', r'\begin{tabular}{@{}llrp{7.4cm}l@{}}\toprule', r'Repository & Role & Series & Lineage key(s) & Unit\\\midrule']
t += [' & '.join(r) + r'\\' for r in rows]
t += [r'\bottomrule\end{tabular}\end{table*}']
(O / 'tables/tab_corpus.tex').write_text('\n'.join(t), encoding='utf-8')

# ---------- Table 2: E1 per pair
name = {'P1_hysets_vs_camels': ('HYSETS', 'CAMELS-US', 'USGS no.'),
        'P2_grdc_vs_camels': ('GRDC-Caravan', 'CAMELS-US', r'\texttt{nat\_id}'),
        'P2_grdc_vs_hysets': ('GRDC-Caravan', 'HYSETS', r'\texttt{nat\_id}'),
        'P2_grdc_vs_camelsaus': ('GRDC-Caravan', 'CAMELS-AUS', r'\texttt{nat\_id}'),
        'P2_grdc_vs_camelsbr': ('GRDC-Caravan', 'CAMELS-BR', r'\texttt{nat\_id}'),
        'P2_grdc_vs_lamah': ('GRDC-Caravan', 'Caravan-LamaH', r'\texttt{nat\_id}'),
        'P3_caravanlamah_vs_lamah': ('Caravan-LamaH', 'LamaH-CE', 'agency no.'),
        'P4_gwse_vs_grdccaravan': ('GWSE (GRDC)', 'GRDC-Caravan', 'GRDC no.'),
        'P5_gwse_vs_caravanUS': ('GWSE (USGS)', 'Caravan US', 'USGS no.')}
st = pairs[pairs.stable].copy(); st['rate'] = st.real / st.n
t = [r'\begin{table*}[t]\centering\small',
     r"\caption{E1: divergence between copies of the same gauge under the rounding-aware tolerance $\tau$ (Sec.~\ref{sec:defs}). Rates are pooled over scale-stable pairs. ``Shift'' is the share of divergent days that a $\pm1$-day offset explains; these days are excluded from the rate. ``Top-10\%'' is the share of divergent days held by the 10\% most divergent gauges. Rates $\ge$1\% in bold.}",
     r'\label{tab:e1}', r'\begin{tabular}{@{}lllrrrrrrr@{}}\toprule',
     r'Copy $a$ & Copy $b$ & Key & Pairs & Stable & Overlap & Rate & Shift & Gauges & Top-10\%\\',
     r' & & & & & days & & & $\ge$1\% & \\\midrule']
for p, (a, b, k) in name.items():
    s = g1[p]; x = st[st.pair == p]
    xs = x.sort_values('real', ascending=False); top = xs.head(max(1, len(xs) // 10)).real.sum() / max(1, xs.real.sum())
    rate = s['divergence_rate'] * 100
    rs = (r'\textbf{' + f'{rate:.2f}' + '}') if rate >= 1 else f'{rate:.2f}'
    t.append(f"{a} & {b} & {k} & {fmt(s['compared'])} & {fmt(s['compared'] - s['unstable'])} & {s['overlap'] / 1e6:.2f}M & {rs}\\% & "
             f"{s['shift_explained_share_of_div'] * 100:.0f}\\% & {(x.rate >= 0.01).mean() * 100:.0f}\\% & {top * 100:.0f}\\%" + r'\\')
t += [r'\bottomrule\end{tabular}\end{table*}']
(O / 'tables/tab_e1.tex').write_text('\n'.join(t), encoding='utf-8')

# ---------- Table 3: magnitude
lab = {'P2_grdc_vs_camelsbr': 'GRDC-C.\\ vs CAMELS-BR', 'P2_grdc_vs_lamah': 'GRDC-C.\\ vs Car.-LamaH',
       'P3_caravanlamah_vs_lamah': 'Car.-LamaH vs LamaH-CE'}
t = [r'\begin{table}[t]\centering\small\setlength{\tabcolsep}{4pt}',
     r"\caption{Magnitude of divergent days in the three chains above 1\%: relative difference $|a_t-kb_t|/kb_t$, and the share of divergent days in the pair's lowest flow decile (``Low'').}",
     r'\label{tab:mag}', r'\begin{tabular}{@{}lrrrr@{}}\toprule', r'Chain & Median & $>$10\% & $>$50\% & Low\\\midrule']
for p, l in lab.items():
    m = mag.loc[p]
    t.append(f"{l} & {m.rel_median * 100:.1f}\\% & {m.share_gt10pct * 100:.0f}\\% & {m.share_gt50pct * 100:.1f}\\% & {m.share_in_lowest_decile_flow * 100:.0f}\\%" + r'\\')
t += [r'\bottomrule\end{tabular}\end{table}']
(O / 'tables/tab_mag.tex').write_text('\n'.join(t), encoding='utf-8')

# ---------- Figure: per-gauge ECDF + by-year
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.6))
sel = [('P5_gwse_vs_caravanUS', 'GWSE vs Caravan US'), ('P1_hysets_vs_camels', 'HYSETS vs CAMELS-US'),
       ('P4_gwse_vs_grdccaravan', 'GWSE vs GRDC-Caravan'), ('P2_grdc_vs_camelsbr', 'GRDC-Car. vs CAMELS-BR'),
       ('P2_grdc_vs_lamah', 'GRDC-Car. vs Car.-LamaH'), ('P3_caravanlamah_vs_lamah', 'Car.-LamaH vs LamaH-CE')]
sty = ['-', '--', ':', '-', '--', ':']; col = ['#8a8a8a'] * 3 + ['#1f5fa8'] * 3
for (p, l), ls, c in zip(sel, sty, col):
    r = np.sort(st[st.pair == p].rate.values * 100)
    ax[0].step(np.r_[0, r], np.r_[0, np.arange(1, len(r) + 1) / len(r)], ls=ls, c=c, lw=1.2, label=l, where='post')
    y = pd.Series(g1[p]['by_year']); y.index = y.index.astype(int); y = y[(y.index >= 1981) & (y.index <= 2017)]
    ax[1].plot(y.index, y.values * 100, ls=ls, c=c, lw=1.2)
ax[0].set_xscale('symlog', linthresh=0.1); ax[0].set_xlim(0, 60)
ax[0].set_xlabel('per-gauge divergence rate (%)', fontsize=8); ax[0].set_ylabel('ECDF of gauges', fontsize=8)
ax[1].set_yscale('symlog', linthresh=1); ax[1].set_xlabel('year', fontsize=8); ax[1].set_ylabel('divergence rate (%)', fontsize=8)
h, l = ax[0].get_legend_handles_labels()
for a in ax: a.spines[['top', 'right']].set_visible(False); a.tick_params(labelsize=7)
fig.tight_layout(rect=(0, 0.13, 1, 1)); fig.legend(h, l, loc='lower center', ncol=3, fontsize=6.5, frameon=False); fig.savefig(O / 'fig/fig_e1.pdf'); fig.savefig(O / 'fig/fig_e1.png', dpi=150)

# ---------- numbers used in prose (macros)
d = g1['duplicate_share']
NUM.update(nCore=fmt(d['core']), nGRDC=fmt(d['grdc']), nDupGRDC=fmt(d['grdc_with_core_duplicate']),
           dupShare=f"{d['share_of_combined'] * 100:.1f}", nCombined=fmt(d['core'] + d['grdc']))
for p, m in [('P2_grdc_vs_camelsbr', 'BR'), ('P2_grdc_vs_lamah', 'LaG'), ('P3_caravanlamah_vs_lamah', 'LaC'), ('P1_hysets_vs_camels', 'HyCa'),
             ('P4_gwse_vs_grdccaravan', 'GwG'), ('P5_gwse_vs_caravanUS', 'GwU'), ('P2_grdc_vs_hysets', 'GHy'), ('P2_grdc_vs_camels', 'GCa'), ('P2_grdc_vs_camelsaus', 'GAu')]:
    s = g1[p]; x = st[st.pair == p]
    NUM[f'rate{m}'] = f"{s['divergence_rate'] * 100:.2f}"
    NUM[f'gauges{m}'] = f"{(x.rate >= 0.01).mean() * 100:.0f}"
    NUM[f'unst{m}'] = f"{s['unstable'] / s['compared'] * 100:.0f}"
    NUM[f'stable{m}'] = fmt(s['compared'] - s['unstable'])
by = lambda p, yr: g1[p]['by_year'].get(str(yr))
NUM.update(brNinety=f"{by('P2_grdc_vs_camelsbr', 1990) * 100:.1f}", brFifteen=f"{by('P2_grdc_vs_camelsbr', 2015) * 100:.1f}",
           brEighteen=f"{by('P2_grdc_vs_camelsbr', 2018) * 100:.1f}")
NUM.update(lamahCkhsZero=f"{g1['P3_caravanlamah_vs_lamah']['by_lamah_ckhs']['0']['mean'] * 100:.1f}",
           lamahCkhsOne=f"{g1['P3_caravanlamah_vs_lamah']['by_lamah_ckhs']['1']['mean'] * 100:.1f}")
NUM.update(nCarAUS=fmt(car['camelsaus']), nPairsKeyed=fmt(sum(g1[p]['copy_pairs_keyed'] for p in name)),
           nOverlap=f"{sum(g1[p]['overlap'] for p in name) / 1e6:.1f}")
lines = ['% generated by make_tables.py; do not edit'] + [f'\\newcommand{{\\num{k}}}{{{v}}}' for k, v in NUM.items()]
(O / 'numbers.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps(NUM, indent=0))
print('corpus', car, n_grdc, n_lamah, n_lamah_h, n_gw, n_cbr, n_ana)
