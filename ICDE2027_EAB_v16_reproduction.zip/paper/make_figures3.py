"""Additional figures/tables for the expanded paper. All from existing gate outputs or raw inputs (descriptive only)."""
import json, zipfile, pickle, math, warnings
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT as R, ART as P
O = P / 'paper'; OUT = P / 'out'
plt.rcParams.update({'font.size': 7, 'axes.spines.top': False, 'axes.spines.right': False})
BLUE, LBLUE, GREY, RED = '#1f5fa8', '#7fa7d6', '#9a9a9a', '#c0392b'
NUM = {}

# ------------------------------------------------------------------ map of copy pairs
# Land outline from HydroBASINS level 1 (optional input, see README); without it the map is drawn without background.
HB = [R / f'data/HydroBASINS/hybas_{reg}_lev01-12_v1c.zip' for reg in ['af', 'ar', 'as', 'au', 'eu', 'gr', 'na', 'sa', 'si']]
land = None
if all(z.exists() for z in HB):
    import geopandas as gpd
    land = pd.concat([gpd.read_file(f'zip://{z}!' + z.name.replace('_lev01-12_v1c.zip', '_lev01_v1c.shp')) for z in HB]).geometry.simplify(0.2)
else:
    print('HydroBASINS not found under REPUB_ROOT/data/HydroBASINS: map drawn without land outline')
CAR = R / 'data/Caravan/extracted/Caravan-nc/attributes'
coords = pd.concat([pd.read_csv(CAR / f'{s}/attributes_other_{s}.csv')[['gauge_id', 'gauge_lat', 'gauge_lon']]
                    for s in ['camels', 'camelsaus', 'camelsbr', 'camelscl', 'camelsgb', 'hysets', 'lamah']])
gz = zipfile.ZipFile(R / 'data/GRDC-Caravan/GRDC_Caravan_extension_csv.zip')
coords = pd.concat([coords, pd.read_csv(gz.open('GRDC_Caravan_extension_csv/attributes/grdc/attributes_other_grdc.csv'))[['gauge_id', 'gauge_lat', 'gauge_lon']]]).drop_duplicates('gauge_id').set_index('gauge_id')
g1 = pd.read_csv(OUT / 'g1/g1_pairs.csv'); st = g1[g1.stable].copy(); st['rate'] = st.real / st.n
def anchor(r):
    if r.pair.startswith('P3'): return r.a
    if r.pair.startswith('P4'): return r.b
    return r.b
st['gid'] = st.apply(anchor, axis=1)
st = st[st.gid.isin(coords.index)]
st['lat'] = coords.loc[st.gid, 'gauge_lat'].values; st['lon'] = coords.loc[st.gid, 'gauge_lon'].values
fig, ax = plt.subplots(figsize=(7.0, 3.0))
if land is not None: land.plot(ax=ax, color='#eeeeee', edgecolor='#d0d0d0', linewidth=0.2)
bins = [(-1, 0.001, '#bdbdbd', '< 0.1%'), (0.001, 0.01, LBLUE, '0.1–1%'), (0.01, 0.05, BLUE, '1–5%'), (0.05, 2, RED, '≥ 5%')]
for lo, hi, c, lab in bins:
    s = st[(st.rate > lo) & (st.rate <= hi)] if lo >= 0 else st[st.rate <= hi]
    ax.scatter(s.lon, s.lat, s=2.5 if lo < 0.01 else 4, c=c, label=f'{lab} ({len(s):,})', linewidths=0, zorder=3 if lo >= 0.01 else 2)
ax.set_xlim(-170, 180); ax.set_ylim(-48, 72); ax.set_xticks([]); ax.set_yticks([])
for s_ in ['left', 'bottom']: ax.spines[s_].set_visible(False)
ax.legend(loc='lower left', fontsize=6.5, frameon=False, markerscale=2.5, title='per-gauge divergence rate', title_fontsize=6.5)
fig.tight_layout(); fig.savefig(O / 'fig/fig_map.pdf'); fig.savefig(O / 'fig/fig_map.png', dpi=150); plt.close(fig)
NUM['mapGauges'] = f'{len(st):,}'

# ------------------------------------------------------------------ worked examples (LamaH window, BR source divergence)
g4src = open(P / 'src/g4.py', encoding='utf-8').read()
G = {'__file__': str(P / 'src/g4.py')}; exec(compile(g4src.split('rows, unstable = [], []')[0], 'g4', 'exec'), G)
exec(compile(g4src[g4src.index('def camelsbr_m3s'):g4src.index('br_status = []')], 'g4b', 'exec'), G)
days = pd.read_parquet(OUT / 'g4/g4_days.parquet'); days['day'] = pd.to_datetime(days['day'])
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.3))
# (a) LamaH: gauge with most L2 days; window around its largest relative divergence
l2 = days[(days.chain == 'LamaH-P3') & (days.cause == 'L2 aggregation/day-boundary')]
b_id = l2.b.value_counts().index[0]; a_id = l2[l2.b == b_id].a.iloc[0]
a = G['caravan'](a_id); b = G['lamah'](int(b_id))[0]
j = pd.concat([a.rename('a'), b.rename('b')], axis=1).dropna(); k = float((j[j.b > 0].a / j[j.b > 0].b).median())
dd = l2[l2.b == b_id].day
rel = ((j.a - k * j.b).abs() / (k * j.b)).reindex(dd)
d0 = rel.idxmax(); t0, t1 = d0 - pd.Timedelta(days=3), d0 + pd.Timedelta(days=4)
fs = list(Path(G['HOURLY'][0]).glob(f'ID_{b_id}.csv'))[0]
h = pd.read_csv(fs, sep=';'); q = pd.Series(h.qobs.values.astype(float), index=pd.to_datetime(dict(year=h.YYYY, month=h.MM, day=h.DD, hour=h.hh, minute=h.mm))); q[q < 0] = np.nan
shift = q.copy().set_axis(q.index + pd.Timedelta(hours=1)).resample('D').mean()
qq = q[(q.index >= t0) & (q.index < t1 + pd.Timedelta(days=1))]
ax[0].plot(qq.index, qq.values, color='#cfcfcf', lw=0.8, label='LamaH-CE hourly')
rng = pd.date_range(t0, t1)
def steps(s, **kw):
    s = s.reindex(rng); x = np.r_[s.index.values, (s.index[-1] + pd.Timedelta(days=1)).to_datetime64()]
    ax[0].step(x, np.r_[s.values, s.values[-1]], where='post', **kw)
steps(b, color=GREY, lw=1.4, label='LamaH-CE daily')
steps(a / k, color=BLUE, lw=1.4, ls='--', label='Caravan (rescaled)')
steps(shift, color=RED, lw=0.9, ls=':', label='hourly mean, window −1 h')
ax[0].set_ylabel('discharge (m$^3$ s$^{-1}$)'); ax[0].legend(fontsize=5.8, frameon=False, loc='upper left')
ax[0].tick_params(axis='x', labelsize=6, rotation=25); ax[0].set_title(f'(a) LamaH gauge {b_id}', fontsize=7, loc='left')
NUM.update(exLamahGauge=str(b_id), exLamahDate=d0.strftime('%Y-%m-%d'))
# (b) BR: station with most B5 (CAMELS-BR branch) days; 1-year window of densest divergence
b5 = days[(days.chain == 'BR') & (days.cause == 'B5 edge into Caravan/CAMELS-BR branch')]
code_b = b5.b.value_counts().index[0]; ga = b5[b5.b == code_b].a.iloc[0]; code = code_b.split('_', 1)[1]
r1, r2, _ = G['ana'](code); c, _ = G['camelsbr_m3s'](code); g = G['grdc'](ga)
yr = b5[b5.b == code_b].day.dt.year.value_counts().index[0]
w0, w1 = pd.Timestamp(f'{yr}-01-01'), pd.Timestamp(f'{yr}-12-31')
jj = pd.concat([g.rename('g'), r2.rename('r')], axis=1).dropna(); kg = float((jj[jj.r > 0].g / jj[jj.r > 0].r).median())
for s, lab, col, ls, lw in [(r2, 'ANA today (level 2)', '#222222', '-', 1.0), (g / kg, 'GRDC-Caravan (rescaled)', LBLUE, '--', 1.2), (c, 'CAMELS-BR', RED, ':', 1.2)]:
    s = s[(s.index >= w0) & (s.index <= w1)]; ax[1].plot(s.index, s.values, ls=ls, color=col, lw=lw, label=lab)
mk = b5[(b5.b == code_b) & (b5.day >= w0) & (b5.day <= w1)].day
ax[1].scatter(mk, np.full(len(mk), ax[1].get_ylim()[0]), marker='|', s=12, color=RED, lw=0.6, label='divergent day (CAMELS-BR edge)')
ax[1].set_ylabel('discharge (m$^3$ s$^{-1}$)'); ax[1].legend(fontsize=5.8, frameon=False, loc='upper right')
ax[1].tick_params(axis='x', labelsize=6, rotation=25); ax[1].set_title(f'(b) ANA station {code}, {yr}', fontsize=7, loc='left')
fig.tight_layout(); fig.savefig(O / 'fig/fig_examples.pdf'); fig.savefig(O / 'fig/fig_examples.png', dpi=150); plt.close(fig)
NUM.update(exBrStation=code, exBrYear=str(yr), exBrDays=f'{len(mk):,}')

# ------------------------------------------------------------------ E3 figure + per-region table
g2 = json.load(open(OUT / 'g2/g2_summary.json'))
cls = [('c1', 'scaling\nonly'), ('c2', '+coarse\nrounding'), ('c3', '+40%\nwindow'), ('c4', 'divergent\n(>=5%)'), ('c5', 'metadata\ndegraded')]
meth = [('M0', 'M0 coords+area', '#bdbdbd'), ('M1', 'M1 $R^2$', LBLUE), ('M2', 'M2 GSIM', '#6b6b6b'), ('M3', 'M3 exact', '#e0b0a8'), ('M4', 'M4 quant. floor', BLUE)]
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.2))
wdt = 0.16
for i, (m, lab, col) in enumerate(meth):
    x = np.arange(len(cls)) + (i - 2) * wdt
    ax[0].bar(x, [g2['pooled'][c][m]['recall'] for c, _ in cls], wdt, color=col, label=lab)
    pr = [g2['pooled'][c][m]['precision'] for c, _ in cls]
    ax[1].bar(x, [p if p == p else 0 for p in pr], wdt, color=col, label=lab)
for a_, t in zip(ax, ['recall', 'precision']):
    a_.set_xticks(np.arange(len(cls))); a_.set_xticklabels([l for _, l in cls], fontsize=6); a_.set_ylabel(t); a_.set_ylim(0, 1.05)
ax[1].axhline(0.99, color=RED, lw=0.8, ls='--'); ax[1].text(4.45, 0.995, '0.99', color=RED, fontsize=6, va='bottom', ha='right')
h_, l_ = ax[0].get_legend_handles_labels()
fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.legend(h_, l_, loc='lower center', ncol=5, fontsize=6.2, frameon=False); fig.savefig(O / 'fig/fig_e3.pdf'); fig.savefig(O / 'fig/fig_e3.png', dpi=150); plt.close(fig)
reg_name = {"US": "US", "EU": "C. Europe", "BR": "Brazil", "AU": "Australia"}
lab = pd.read_csv(P / 'labels/discovery_pairs.csv', low_memory=False)
neg = lab[lab.label == 0]
t = [r'\begin{table}[t]\centering\footnotesize\setlength{\tabcolsep}{2.5pt}',
     r"\caption{E3 on clean copies (class c1) by region: precision / recall of the three strongest rules (M1 $R^2$, M2 GSIM, M4 quantisation floor), and the number of M4 false positives that are sub-kilometre pairs with unmatched keys (``sub-km'') out of all M4 false positives.}",
     r'\label{tab:e3region}', r'\begin{tabular}{@{}lrcccr@{}}\toprule', r'Region & Pos. & M1 & M2 & M4 & FP sub-km\\\midrule']
for rg in ['US', 'EU', 'BR', 'AU']:
    s = g2['by_region'].get(f'c1_{rg}')
    if not s: continue
    g_ = neg[neg.region == rg]; fp = int(g_.rule_M4_unperturbed.sum()); fps = int((g_.rule_M4_unperturbed & g_.flag_subkm_unmatched_key).sum())
    NUM[f'fpAll{rg}'] = str(fp); NUM[f'fpSub{rg}'] = str(fps)
    t.append(f"{reg_name[rg]} & {s['M1']['P']:,} & " + ' & '.join(f"{s[m]['precision']:.2f} / {s[m]['recall']:.2f}" for m in ['M1', 'M2', 'M4']) + f" & {fps}/{fp}" + r'\\')
t += [r'\bottomrule\end{tabular}\end{table}']
(O / 'tables/tab_e3region.tex').write_text('\n'.join(t), encoding='utf-8')

# ------------------------------------------------------------------ E4 figure
nse = pd.DataFrame(json.load(open(OUT / 'g3_lstm/g3_lstm_nse.json')))
A = nse.filter(like='A_').mean(1); B = nse.filter(like='B_').mean(1); D = (A - B).dropna()
L = pd.read_csv(OUT / 'g3/g3_leakage_rows.csv')
fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.1))
ax[0].scatter(L.nse_neigh.clip(-1, 1), L.nse_copy.clip(-1, 1), s=1.5, color=BLUE, alpha=0.3, linewidths=0)
ax[0].plot([-1, 1], [-1, 1], color=GREY, lw=0.6); ax[0].set_xlabel('NSE, nearest non-copy neighbour'); ax[0].set_ylabel('NSE, copy predictor')
ax[0].set_title('(a) split leakage bound', fontsize=7, loc='left')
ax[1].scatter(B.clip(-1, 1), A.clip(-1, 1), s=4, color=BLUE, linewidths=0)
ax[1].plot([-1, 1], [-1, 1], color=GREY, lw=0.6); ax[1].set_xlabel('LSTM NSE, B (no duplicates)'); ax[1].set_ylabel('LSTM NSE, A (duplicates)')
ax[1].set_title('(b) trained LSTM, per basin', fontsize=7, loc='left')
FX = pd.read_csv(OUT / 'e4fixed/records.csv')
curves = [(D, BLUE, '-', 'injection (A$-$B)'),
          (FX[FX.has_copy].d_M.dropna(), RED, '-', 'fixed test, copy'),
          (FX[~FX.has_copy].d_M.dropna(), GREY, ':', 'fixed test, no copy')]
for v, c, ls, lab in curves:
    x = np.sort(v.clip(-0.5, 1.5).values); ax[2].step(x, np.arange(1, len(x) + 1) / len(x), color=c, lw=1.1, ls=ls, where='post', label=lab)
    ax[2].axvline(v.median(), color=c, lw=0.7, ls='--')
ax[2].axvline(0, color=GREY, lw=0.5)
ax[2].set_xlabel(r'paired $\Delta$NSE'); ax[2].set_ylabel('ECDF of test basins'); ax[2].set_title('(c) paired difference', fontsize=7, loc='left')
ax[2].legend(fontsize=5.5, frameon=False, loc='lower right', bbox_to_anchor=(1.03, 0.02), handlelength=1.4)
fig.tight_layout(); fig.savefig(O / 'fig/fig_e4.pdf'); fig.savefig(O / 'fig/fig_e4.png', dpi=150); plt.close(fig)

lines = ['% generated by make_figures3.py; do not edit'] + [f'\\newcommand{{\\num{k}}}{{{v}}}' for k, v in NUM.items()]
(O / 'numbers3.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps(NUM, indent=0))
