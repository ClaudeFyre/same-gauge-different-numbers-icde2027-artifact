# Licence for the label files in this folder

The files in `labels/` (copy_pairs.csv, discovery_pairs.csv, divergent_day_causes.csv.gz, LABELS.md) and the derived
result files in `out/` are licensed under the **Creative Commons Attribution 4.0 International licence (CC BY 4.0)**:
https://creativecommons.org/licenses/by/4.0/ (full legal code: https://creativecommons.org/licenses/by/4.0/legalcode).

Copyright (c) 2026 The authors of "Same Gauge, Different Numbers". Please cite the paper when reusing them.

The labels contain identifiers and derived statistics only. Station identifiers, names and coordinates originate from
Caravan, GRDC-Caravan, LamaH-CE, CAMELS-BR, GlobalRiverWSE, USGS and ANA, whose own licences continue to apply to
those source datasets. No discharge values are redistributed.
