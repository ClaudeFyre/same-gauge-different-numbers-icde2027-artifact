# Released labels

All files contain identifiers and derived labels only. No discharge values from any repository are redistributed.

## copy_pairs.csv (9,844 rows)
E1 copy pairs identified by lineage keys (never by geography or values) that have at least 365 overlapping days (keyed pairs without enough overlap are omitted).
- `scale_k`: median of a/b on days with both values finite and b > 0.
- `ratio_iqr`: IQR of a/(k b).
- `scale_stable`: ratio_iqr <= 0.01.
- `divergent_days`: days outside the rounding-aware tolerance and not explained by a +-1-day shift.
- `shift_explained_days`: divergent days that a +-1-day offset explains; excluded from the rate.
- `divergence_rate`: divergent_days / overlap_days; only defined for scale-stable pairs.

## discovery_pairs.csv (224,253 rows)
The E3 benchmark.
- `label = 1`: a keyed copy pair (7,706 rows), with `positive_class` c1 (stable, < 5% divergent), c4 (stable, >= 5%) or c6 (scale-unstable).
- `label = 0`: a pair with *different* lineage keys (216,547 rows), with `negative_kind` hard (< 50 km and Pearson r >= 0.9, or LamaH upstream/downstream neighbours) or easy (random).
- `rule_*_unperturbed`: decisions of rules M0-M4 on the unperturbed series (paper, Sec. VII).

**Ground-truth caveat flags (negatives only).** A negative label means "different lineage key", which is not proof of "not a copy".
- `flag_subkm_unmatched_key` (187 rows): the two gauges lie less than 1 km apart. Inspected cases are identifier-format mismatches (GRDC nat_id vs CAMELS-AUS codes, Austrian agency numbers vs LamaH numbering, archive GRDC stations duplicating USGS gauges). **Likely unlabelled copies; treat as uncertain.**
- `flag_near_identical_series` (173 rows; 64 also sub-km; 109 at least 1 km apart): the quantisation-floor rule M4 matches, i.e. at least 90% of days agree within the tolerance. Beyond 1 km these are typically distinct gauges with near-identical records (possible derived or transferred records). **Not verified case by case.**

We recommend excluding flagged negatives from precision computations, or reporting results with and without them, as in the paper's sensitivity analysis.

## divergent_day_causes.csv.gz (244,441 rows)
E2 attribution, one row per divergent day of the three diverging chains (columns: chain, a, b, day, cause).
Cause codes, in the order applied:
- L1: LamaH gap interpolation
- L2: aggregation window / day boundary
- L3, B4: scale segment
- L4, B1, B5: edge localisation
- B2: raw vs consistency-checked ANA level
- unresolved / unattributed

See plans/PLAN_G4_AMENDMENT.md for the frozen definitions.

## e3_verification.csv (581 rows) and e3_spotcheck_sample.csv (90 rows)
Metadata-only verification of every questionable E3 negative (flagged, or called a copy by any rule), per the frozen
`plans/PLAN_E3_VERIFY.md`: rule R1/R2 = confirmed copy (same station), R3 = confirmed non-copy, R4 = unresolved, with the
evidence (names, areas, distance, identifiers) for each decision. The spot-check sample (30 per group, seed 0) is provided
for independent review of the mechanical decisions.
