"""Fetch USGS NWIS daily discharge for Vermont and New Hampshire, 2009-2023 (anonymous dv service), used only by the
excluded pilot (Sec. III) and to exclude these gauges elsewhere. Writes icde_probe/raw/nwis_states/{VT,NH}_dv_2009_2023.rdb
and vt_nh_long.parquet (columns site, date, Q [cfs], cd, state, est).

NWIS serves *current* values; provisional data may be revised after our download (2026-10-16). Our RDB files had
MD5 VT b47ea86d3cc7499062946f042e62040a (8,297,114 bytes) and NH 053a857ddf625ca43c990a98ee99d6ae (9,000,055 bytes).
A different MD5 today is expected if USGS revised values; the script reports it but does not stop.
Size ~17 MB. Pass --yes to download.
"""
import argparse, hashlib, sys, urllib.parse, urllib.request
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT

RAW = ROOT / 'icde_probe/raw/nwis_states'
OURS = {'VT': 'b47ea86d3cc7499062946f042e62040a', 'NH': '053a857ddf625ca43c990a98ee99d6ae'}

def fetch(state):
    f = RAW / f'{state}_dv_2009_2023.rdb'
    if not f.exists():
        q = urllib.parse.urlencode(dict(format='rdb', stateCd=state, parameterCd='00060', statCd='00003',
                                         startDT='2009-01-01', endDT='2023-12-31', siteStatus='all'))
        f.write_bytes(urllib.request.urlopen('https://waterservices.usgs.gov/nwis/dv/?' + q, timeout=600).read())
    h = hashlib.md5(f.read_bytes()).hexdigest()
    print(state, f.stat().st_size, 'bytes', 'md5', h, '(matches paper)' if h == OURS[state] else '(differs from paper download)')
    return f

def parse(f):
    rows, cols = [], None
    for line in open(f, encoding='utf-8', errors='replace'):
        if line.startswith('#'):
            cols = None; continue
        parts = line.rstrip('\n').split('\t')
        if cols is None:
            cols = parts; skip = True; continue
        if skip:
            skip = False; continue
        rec = dict(zip(cols, parts)); vcol = [c for c in cols if c.endswith('_00060_00003')]
        if not vcol: continue
        try: q = float(rec.get(vcol[0], ''))
        except ValueError: continue
        rows.append((rec['site_no'], rec['datetime'], q, rec.get(vcol[0] + '_cd', '')))
    return pd.DataFrame(rows, columns=['site', 'date', 'Q', 'cd'])

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--yes', action='store_true'); a = ap.parse_args()
    if not a.yes: sys.exit('dry run: ~17 MB from waterservices.usgs.gov; pass --yes')
    RAW.mkdir(parents=True, exist_ok=True)
    frames = []
    for st in ('VT', 'NH'):
        d = parse(fetch(st)); d['state'] = st; frames.append(d)
    L = pd.concat(frames); L['date'] = pd.to_datetime(L.date); L['est'] = L.cd.str.contains('e')
    L.to_parquet(RAW / 'vt_nh_long.parquet'); print('rows', len(L), 'sites', L.site.nunique())
