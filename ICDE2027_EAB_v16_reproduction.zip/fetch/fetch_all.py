"""Download and lay out all third-party inputs under REPUB_ROOT (see README "Data layout").

Default is a dry run that lists what would be downloaded and its size. Pass --yes to download.
Every Zenodo file is verified against the MD5 that Zenodo publishes; the expected values below are the ones of the
versions used in the paper (checked 2026-10-19). A mismatch stops the script.

Total download ~51 GB; extracted size ~80 GB (Caravan 67 GB without shapefiles, LamaH hourly runoff 6.2 GB).
"""
import argparse, hashlib, os, sys, tarfile, urllib.request, json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT

ZENODO = [  # (record, file, md5, destination relative to ROOT)
    ('15529786', 'Caravan-nc.tar.gz', 'ad3a7767db059f218380e9cce5f72452', 'data/Caravan'),
    ('15349031', 'GRDC_Caravan_extension_csv.zip', '2689c2bff8807f53c3de127827a3cd16', 'data/GRDC-Caravan'),
    ('5153305', '2_LamaH-CE_daily.tar.gz', '69fd2733e969513403f923ecc5eaa3dc', 'data/LamaH-CE'),
    ('5153305', '1_LamaH-CE_daily_hourly.tar.gz', '121b2292b288ef1c2ef4d96250be77ac', 'data/LamaH-CE'),
    ('17130396', 'Result datasets.zip', '7052ea54f5f150b636596a5a50194adb', 'data/Expansion_2026-10-16/GlobalRiverWSE_17130396'),
    ('3964745', '02_CAMELS_BR_streamflow_m3s.zip', '599b96f48ec78e25751cf1cc691a22bb', 'data/Expansion_2026-10-19/CAMELS_BR'),
]

def md5(p, chunk=1 << 24):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(chunk), b''): h.update(b)
    return h.hexdigest()

def size_of(rec, name):
    d = json.load(urllib.request.urlopen(f'https://zenodo.org/api/records/{rec}', timeout=60))
    return next(f['size'] for f in d['files'] if f['key'] == name)

def download(rec, name, dest):
    url = f'https://zenodo.org/api/records/{rec}/files/{urllib.request.quote(name)}/content'
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + '.part')
    with urllib.request.urlopen(url, timeout=600) as r, open(tmp, 'wb') as f:
        while True:
            b = r.read(1 << 24)
            if not b: break
            f.write(b)
    tmp.replace(dest)

def extract_tar(tar, out, members):
    out.mkdir(parents=True, exist_ok=True)
    with tarfile.open(tar, 'r:gz') as t:
        sel = [m for m in t if members(m.name)]
        t.extractall(out, members=sel, filter='data')

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--yes', action='store_true', help='actually download and extract')
    a = ap.parse_args()
    print('REPUB_ROOT =', ROOT)
    total = 0
    for rec, name, h, rel in ZENODO:
        dest = ROOT / rel / name
        s = size_of(rec, name); total += s
        state = 'present' if dest.exists() else 'missing'
        print(f'{name:40s} {s / 1e9:7.2f} GB  zenodo {rec}  [{state}]')
        if a.yes and not dest.exists():
            download(rec, name, dest)
        if dest.exists() and a.yes:
            got = md5(dest)
            if got != h: sys.exit(f'MD5 mismatch for {name}: {got} != {h}')
            print('  md5 ok')
    print(f'total {total / 1e9:.1f} GB')
    if not a.yes:
        print('dry run: pass --yes to download and extract'); return
    # layout used by the scripts
    extract_tar(ROOT / 'data/Caravan/Caravan-nc.tar.gz', ROOT / 'data/Caravan/extracted', lambda n: '/shapefiles/' not in n)
    extract_tar(ROOT / 'data/LamaH-CE/2_LamaH-CE_daily.tar.gz', ROOT / 'icde_probe/raw/lamah', lambda n: True)
    extract_tar(ROOT / 'data/LamaH-CE/1_LamaH-CE_daily_hourly.tar.gz', ROOT / 'data/LamaH-CE/extracted_hourly',
                lambda n: 'D_gauges/2_timeseries/hourly/' in n or 'D_gauges/2_timeseries/gaps' in n or 'D_gauges/1_attributes/' in n)
    print('done. Next: python fetch/fetch_nwis_vtnh.py --yes ; after G1: python fetch/fetch_ana.py --yes')

if __name__ == '__main__':
    main()
