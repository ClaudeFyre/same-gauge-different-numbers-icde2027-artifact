"""Fetch ANA HidroSerieHistorica daily discharge (all consistency levels) for the 105 Brazilian stations of E2
(ana_stations.txt = CAMELS-BR codes of the scale-stable GRDC-Caravan/CAMELS-BR copy pairs from G1).
Anonymous ANA web service; ~210 MB in our run (2026-10-19). Sequential, 1 s pause; stops above 220 MB.
ANA serves current values, which may change; results of E2 refer to our download date. Pass --yes to download.
"""
import argparse, json, sys, time, urllib.request
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT

OUT = ROOT / 'data/Expansion_2026-10-19/ANA'
CAP = 220e6
ST = [s.strip() for s in open(Path(__file__).with_name('ana_stations.txt')) if s.strip()]

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--yes', action='store_true'); a = ap.parse_args()
    if not a.yes: sys.exit(f'dry run: {len(ST)} stations, ~210 MB from telemetriaws1.ana.gov.br; pass --yes')
    OUT.mkdir(parents=True, exist_ok=True)
    man, total = [], 0
    for i, s in enumerate(ST):
        f = OUT / f'{s}.xml'
        if f.exists() and f.stat().st_size > 0:
            total += f.stat().st_size; man.append(dict(station=s, bytes=f.stat().st_size, status='cached')); continue
        url = ('https://telemetriaws1.ana.gov.br/ServiceANA.asmx/HidroSerieHistorica?codEstacao=' + s +
               '&dataInicio=01/01/1950&dataFim=31/12/2024&tipoDados=3&nivelConsistencia=')
        try:
            b = urllib.request.urlopen(url, timeout=180).read(); f.write_bytes(b); total += len(b)
            man.append(dict(station=s, bytes=len(b), status='ok'))
        except Exception as e:
            man.append(dict(station=s, bytes=0, status=f'error: {e}'))
        print(i + 1, len(ST), s, man[-1]['status'], round(total / 1e6, 1), 'MB', flush=True)
        if total > CAP: print('STOP: cap reached'); break
        time.sleep(1)
    (OUT / 'manifest.json').write_text(json.dumps(dict(stations=len(ST), total_bytes=total, items=man), indent=1))
