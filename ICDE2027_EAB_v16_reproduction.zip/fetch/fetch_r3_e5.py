"""Fetch the small inputs of E5 (weather-station lake) and of extension X3 that are not on Zenodo's main records.

E5 metadata (selection uses metadata only; ~40 MB): GHCN-Daily station list and source ("mingle") list, ECA&D
non-blended info and blended source tables per element, DWD kl station description, DWD CLIMAT station list.
X3: CAMELS-BR v1.2 streamflow (Zenodo 15025488, 153 MB, MD5 checked) and the DWD CDC change/error logs (110 KB).

The station series of E5 are then fetched by src/e5_fetch.py (frozen 350 MB budget, see plans/PLAN_E5_WEATHER.md).
Metadata and logs are live files; MD5s of our downloads (2026-11-06/07) are listed and differences are reported, not fatal.
ECA&D data are licensed for non-commercial research only; this artifact ships only identifiers and derived statistics.
Dry run by default; pass --yes to download.
"""
import argparse, hashlib, sys, urllib.request
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from _paths import ROOT

META = ROOT / 'data/Expansion_2026-11-06/weather/meta'
ECA = 'https://knmi-ecad-assets-prd.s3.amazonaws.com/download/'
FILES = [
    ('https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt', META, 'd0c8daa5b38119c08d48b30c11fb90a0'),
    ('https://www.ncei.noaa.gov/pub/data/ghcn/daily/mingle-list.txt', META, '690bc4dcf48c1bd54ea8724583cf6839'),
    ('https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/daily/kl/historical/KL_Tageswerte_Beschreibung_Stationen.txt', META, '74a38a08f3f81a10d62a7a3f1b29ca4f'),
    ('https://opendata.dwd.de/climate_environment/CDC/help/stations_list_CLIMAT_data.txt', META, '5994aed37c6adeb382d4d2813446c116'),
] + [(ECA + f'ECA_nonblend_info_{e}.txt', META, m) for e, m in
     [('rr', '7d3ede49cd271b1909709a8a27838837'), ('tx', 'c08951fde40c287c7da3c67d04d7080c'),
      ('tn', 'c660f0e1509c30ae67e07eb94e3b8bdd'), ('tg', 'edd94480772d7866da67ba0f8d25befe')]] \
  + [(ECA + f'ECA_blend_source_{e}.txt', META, m) for e, m in
     [('rr', '4a63dfc392caff9f468711ac16f4effe'), ('tx', 'ba44c17b680c05e5aec3a10979e3723a'),
      ('tn', '7f26cdfdd9ba189cabae88d85acb8777'), ('tg', 'b977e881ef34c245eaa7c56c9cedbc6d')]] + [
    ('https://zenodo.org/records/15025488/files/02_CAMELS_BR_streamflow_all_catchments.zip?download=1',
     ROOT / 'data/Expansion_2026-11-07/camelsbr_v12', '01ac209ad3ca9a36f7f2510a6601a0a2'),
    ('https://opendata.dwd.de/climate_environment/CDC/Change_log_CDC_ftp.txt', ROOT / 'data/Expansion_2026-11-07/dwd_logs', '6bc0ff7c8b54826ff4a36843606f8101'),
    ('https://opendata.dwd.de/climate_environment/CDC/Error_log_CDC_ftp.txt', ROOT / 'data/Expansion_2026-11-07/dwd_logs', '7e003334e885643b5bd918659a7d6128'),
]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--yes', action='store_true'); a = ap.parse_args()
    for url, d, ours in FILES:
        name = url.split('/')[-1].split('?')[0]; f = d / name
        if not a.yes and not f.exists():
            print('would fetch', url, '->', f); continue
        if not f.exists():
            d.mkdir(parents=True, exist_ok=True)
            with urllib.request.urlopen(url, timeout=600) as r, open(f, 'wb') as o:
                while True:
                    b = r.read(1 << 20)
                    if not b: break
                    o.write(b)
        h = hashlib.md5(f.read_bytes()).hexdigest()
        print(name, f.stat().st_size, 'bytes', 'md5 matches our download' if h == ours else f'md5 {h} differs from ours ({ours})')

if __name__ == '__main__':
    main()
